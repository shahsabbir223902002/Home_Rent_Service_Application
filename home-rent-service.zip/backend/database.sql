-- ========================================================
-- Home Rent Service — Mogoltoli, Cumilla, Bangladesh
-- MySQL Database Schema
-- ========================================================

CREATE DATABASE IF NOT EXISTS `homerent_db` DEFAULT CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;
USE `homerent_db`;

-- Drop existing tables in reverse dependency order
DROP TABLE IF EXISTS `admin_activity_logs`;
DROP TABLE IF EXISTS `reports`;
DROP TABLE IF EXISTS `inquiries`;
DROP TABLE IF EXISTS `favorites`;
DROP TABLE IF EXISTS `property_images`;
DROP TABLE IF EXISTS `properties`;
DROP TABLE IF EXISTS `users`;

-- 1. Users Table
CREATE TABLE `users` (
  `id` INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  `name` VARCHAR(120) NOT NULL,
  `email` VARCHAR(150) NOT NULL UNIQUE,
  `phone` VARCHAR(25) NOT NULL,
  `password_hash` VARCHAR(255) NOT NULL,
  `role` ENUM('user', 'admin') NOT NULL DEFAULT 'user',
  `status` ENUM('active', 'suspended') NOT NULL DEFAULT 'active',
  `created_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  `updated_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  INDEX `idx_users_email` (`email`),
  INDEX `idx_users_role` (`role`)
) ENGINE=InnoDB;

-- 2. Properties Table
-- Geofenced to Mogoltoli, Cumilla (Lat: 23.4560 - 23.4680, Lon: 91.1800 - 91.1960)
CREATE TABLE `properties` (
  `id` INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  `owner_id` INT UNSIGNED NOT NULL,
  `category` ENUM('house', 'store', 'car_parking') NOT NULL,
  `title` VARCHAR(200) NOT NULL,
  `description` TEXT NOT NULL,
  `rent_monthly` DECIMAL(10, 2) NOT NULL,
  `address` VARCHAR(255) NOT NULL,
  `latitude` DECIMAL(10, 7) NOT NULL,
  `longitude` DECIMAL(10, 7) NOT NULL,
  `approval_status` ENUM('Pending', 'Approved', 'Rejected') NOT NULL DEFAULT 'Pending',
  `availability_status` ENUM('Available', 'Rented', 'Unavailable') NOT NULL DEFAULT 'Available',
  `rejection_reason` VARCHAR(255) NULL,
  -- House specific attributes
  `bedrooms` INT UNSIGNED NULL DEFAULT 0,
  `bathrooms` INT UNSIGNED NULL DEFAULT 0,
  `house_rules` VARCHAR(255) NULL,
  -- Store specific attributes
  `floor_area_sqft` INT UNSIGNED NULL DEFAULT 0,
  `commercial_details` VARCHAR(255) NULL,
  -- Car Parking specific attributes
  `vehicle_type` VARCHAR(60) NULL,
  `capacity` INT UNSIGNED NULL DEFAULT 1,
  `is_covered` TINYINT(1) NULL DEFAULT 1,
  -- Facilities JSON or comma-separated list
  `facilities` TEXT NULL,
  `created_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  `updated_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  FOREIGN KEY (`owner_id`) REFERENCES `users`(`id`) ON DELETE CASCADE,
  INDEX `idx_props_cat` (`category`),
  INDEX `idx_props_approval` (`approval_status`),
  INDEX `idx_props_avail` (`availability_status`),
  INDEX `idx_props_coords` (`latitude`, `longitude`)
) ENGINE=InnoDB;

-- 3. Property Images Table
CREATE TABLE `property_images` (
  `id` INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  `property_id` INT UNSIGNED NOT NULL,
  `image_url` VARCHAR(500) NOT NULL,
  `is_primary` TINYINT(1) NOT NULL DEFAULT 0,
  `created_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  FOREIGN KEY (`property_id`) REFERENCES `properties`(`id`) ON DELETE CASCADE
) ENGINE=InnoDB;

-- 4. Favorites Table
CREATE TABLE `favorites` (
  `id` INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  `user_id` INT UNSIGNED NOT NULL,
  `property_id` INT UNSIGNED NOT NULL,
  `created_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  UNIQUE KEY `unique_user_fav` (`user_id`, `property_id`),
  FOREIGN KEY (`user_id`) REFERENCES `users`(`id`) ON DELETE CASCADE,
  FOREIGN KEY (`property_id`) REFERENCES `properties`(`id`) ON DELETE CASCADE
) ENGINE=InnoDB;

-- 5. Inquiries Table
CREATE TABLE `inquiries` (
  `id` INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  `property_id` INT UNSIGNED NOT NULL,
  `sender_id` INT UNSIGNED NOT NULL,
  `sender_name` VARCHAR(120) NOT NULL,
  `sender_phone` VARCHAR(25) NOT NULL,
  `message` TEXT NOT NULL,
  `created_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  FOREIGN KEY (`property_id`) REFERENCES `properties`(`id`) ON DELETE CASCADE,
  FOREIGN KEY (`sender_id`) REFERENCES `users`(`id`) ON DELETE CASCADE
) ENGINE=InnoDB;

-- 6. Reports Table
CREATE TABLE `reports` (
  `id` INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  `property_id` INT UNSIGNED NOT NULL,
  `reporter_id` INT UNSIGNED NOT NULL,
  `reporter_name` VARCHAR(120) NOT NULL,
  `reason` VARCHAR(100) NOT NULL,
  `details` TEXT NOT NULL,
  `status` ENUM('pending', 'reviewed', 'resolved') NOT NULL DEFAULT 'pending',
  `created_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  FOREIGN KEY (`property_id`) REFERENCES `properties`(`id`) ON DELETE CASCADE,
  FOREIGN KEY (`reporter_id`) REFERENCES `users`(`id`) ON DELETE CASCADE
) ENGINE=InnoDB;

-- 7. Admin Activity Logs Table
CREATE TABLE `admin_activity_logs` (
  `id` INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  `admin_id` INT UNSIGNED NOT NULL,
  `admin_name` VARCHAR(120) NOT NULL,
  `action` VARCHAR(100) NOT NULL,
  `target_type` VARCHAR(50) NOT NULL,
  `target_id` INT UNSIGNED NOT NULL,
  `details` VARCHAR(255) NOT NULL,
  `created_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  FOREIGN KEY (`admin_id`) REFERENCES `users`(`id`) ON DELETE CASCADE
) ENGINE=InnoDB;

-- ========================================================
-- Seed Initial Data
-- Admin password hash corresponds to 'admin123' using bcrypt
-- User password hash corresponds to 'user123' using bcrypt
-- ========================================================

-- Insert Initial Admin & Users
INSERT INTO `users` (`id`, `name`, `email`, `phone`, `password_hash`, `role`, `status`) VALUES
(1, 'System Administrator', 'admin@homerent.com', '+8801711000111', '$2y$10$wT0E8K.Y8oJ19iG53B2gVeiFhD9VvP2Xq2z4lW4Fsqp5O3o1E5J6m', 'admin', 'active'),
(2, 'Abdur Rahim', 'rahim@example.com', '+8801812345678', '$2y$10$wT0E8K.Y8oJ19iG53B2gVeiFhD9VvP2Xq2z4lW4Fsqp5O3o1E5J6m', 'user', 'active'),
(3, 'Tanvir Hossain', 'tanvir@example.com', '+8801919876543', '$2y$10$wT0E8K.Y8oJ19iG53B2gVeiFhD9VvP2Xq2z4lW4Fsqp5O3o1E5J6m', 'user', 'active'),
(4, 'Nasrin Akter', 'nasrin@example.com', '+8801614567890', '$2y$10$wT0E8K.Y8oJ19iG53B2gVeiFhD9VvP2Xq2z4lW4Fsqp5O3o1E5J6m', 'user', 'active');

-- Insert Sample Properties (All located strictly within Mogoltoli, Cumilla)
INSERT INTO `properties` 
(`id`, `owner_id`, `category`, `title`, `description`, `rent_monthly`, `address`, `latitude`, `longitude`, `approval_status`, `availability_status`, `bedrooms`, `bathrooms`, `floor_area_sqft`, `vehicle_type`, `capacity`, `is_covered`, `house_rules`, `commercial_details`, `facilities`)
VALUES
(1, 2, 'house', 'Spacious 3-BHK Family Flat near Rajganj Road', 
 'Well-ventilated 3 bedroom flat on 4th floor with lift and standby generator. Located 2 minutes walking distance from Rajganj intersection in Mogoltoli.', 
 18500.00, 'Holding #42, Rajganj Road, Mogoltoli, Cumilla', 23.4612000, 91.1853000, 'Approved', 'Available', 3, 2, 1350, NULL, 0, 1, 'Family only, no pets, gate closes at 11 PM', NULL, 'Lift,Generator Backup,Gas Cylinder,Balcony,24/7 Security'),

(2, 2, 'store', 'Prime Corner Commercial Store at Mogoltoli Bazaar', 
 'Ground floor commercial shop suitable for pharmacy, grocery, or telecom store. High pedestrian footfall on main Mogoltoli bazaar road.', 
 22000.00, 'Shop #12, Mogoltoli Main Road, Cumilla', 23.4635000, 91.1878000, 'Approved', 'Available', 0, 0, 320, NULL, 0, 1, NULL, 'Commercial trade license required, 2 months advance security deposit', 'Rolling Shutter,Commercial Meter,Water Supply,Front Road 20ft,Tiled Floor'),

(3, 3, 'car_parking', 'Secure Covered Car Parking Space near Town Hall Link', 
 'Gated, covered dedicated parking slot with 24-hour CCTV surveillance and security guard. Ideal for Sedans, SUVs, or private cars.', 
 3500.00, 'Green Heritage, Mogoltoli Road, Cumilla', 23.4594000, 91.1831000, 'Approved', 'Available', 0, 0, 0, 'Sedan / SUV / Private Car', 1, 1, 'Gate access badge provided', NULL, 'CCTV Surveillance,Covered Roof,Security Guard,Automatic Light,Car Wash Space'),

(4, 4, 'house', 'Modern 2-BHK Apartment with Lake Breeze', 
 'South-facing 2 bedroom flat with open balcony and natural light. Quiet residential pocket of Mogoltoli near Gomti embankment link.', 
 14000.00, 'House #18, Lane 3, South Mogoltoli, Cumilla', 23.4578000, 91.1895000, 'Approved', 'Available', 2, 2, 980, NULL, 0, 1, 'Small family or female bachelors', NULL, 'Gas Connection,Balcony,Water Pump,Tile Floor'),

(5, 3, 'house', 'Affordable 1-Bed Studio Flat for Small Family', 
 'Cozy 1-bed flat with attached bath and kitchenette. Clean, secure premises in central Mogoltoli.', 
 8500.00, 'Holding #7, Shahi Lane, Mogoltoli, Cumilla', 23.4648000, 91.1842000, 'Pending', 'Available', 1, 1, 550, NULL, 0, 1, 'Strictly non-smokers, electricity prepaid meter', NULL, 'Prepaid Electric Meter,Water Supply,Roof Access'),

(6, 4, 'store', 'Spacious Showroom / Office Space on 1st Floor', 
 'Well-decorated open space ideal for IT office, coaching center, or showroom near Cumilla Chawkbazar connector.', 
 30000.00, 'Al-Noor Tower, 1st Floor, Mogoltoli, Cumilla', 23.4665000, 91.1882000, 'Approved', 'Available', 0, 1, 850, NULL, 0, 1, NULL, 'Ideal for IT, financial services, or diagnostic agency', 'Lift,3-Phase Electric,Separate Washroom,Wide Glass Frontage'),

(7, 2, 'car_parking', 'Dual Covered Motorcycle / Microbus Parking Spot', 
 'Safe multi-vehicle parking slot inside modern apartment building basement.', 
 2500.00, 'Lotus Tower Basement, Mogoltoli, Cumilla', 23.4605000, 91.1865000, 'Approved', 'Available', 0, 0, 0, 'Microbus / Motorcycle', 2, 1, 'Night parking available', NULL, 'CCTV,Basement Shade,Fire Extinguisher');

-- Initial Activity Logs
INSERT INTO `admin_activity_logs` (`admin_id`, `admin_name`, `action`, `target_type`, `target_id`, `details`) VALUES
(1, 'System Administrator', 'APPROVE_PROPERTY', 'property', 1, 'Approved listing: Spacious 3-BHK Family Flat'),
(1, 'System Administrator', 'APPROVE_PROPERTY', 'property', 2, 'Approved listing: Prime Corner Commercial Store'),
(1, 'System Administrator', 'APPROVE_PROPERTY', 'property', 3, 'Approved listing: Secure Covered Car Parking');
