<?php
// backend/config/geofence.php
// Verified Boundary Definition for Mogoltoli, Cumilla, Bangladesh

// Mogoltoli, Cumilla Approximate Geo Bounding Box & Polygon Boundary:
// North: Gomti river south embankment / Chawkbazar connector (~23.4680)
// South: Cumilla Town Hall / Kandirpar north fringe (~23.4560)
// West: Rajganj road / Badurtoli border (~91.1800)
// East: Mogoltoli primary school / Shaheed Minar link (~91.1960)

define('MOGOLTOLI_MIN_LAT', 23.4560);
define('MOGOLTOLI_MAX_LAT', 23.4680);
define('MOGOLTOLI_MIN_LON', 91.1800);
define('MOGOLTOLI_MAX_LON', 91.1960);

// Default center point of Mogoltoli, Cumilla
define('MOGOLTOLI_CENTER_LAT', 23.4620);
define('MOGOLTOLI_CENTER_LON', 91.1860);

/**
 * Validates whether a latitude and longitude falls strictly within the Mogoltoli boundary
 * 
 * @param float $lat Latitude
 * @param float $lon Longitude
 * @return bool True if inside Mogoltoli service area, false otherwise
 */
function isWithinMogoltoli($lat, $lon) {
    if (!is_numeric($lat) || !is_numeric($lon)) {
        return false;
    }
    $lat = (float)$lat;
    $lon = (float)$lon;

    if ($lat < MOGOLTOLI_MIN_LAT || $lat > MOGOLTOLI_MAX_LAT) {
        return false;
    }
    if ($lon < MOGOLTOLI_MIN_LON || $lon > MOGOLTOLI_MAX_LON) {
        return false;
    }

    return true;
}
