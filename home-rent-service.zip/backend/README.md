# Home Rent Service — Mogoltoli, Cumilla (Backend Setup)

This backend powers the **Home Rent Service** application for **Mogoltoli, Cumilla, Bangladesh**.

## 1. Requirements
- **PHP**: 7.4 or 8.x
- **MySQL / MariaDB**: 5.7+ or 10.x
- **XAMPP / WampServer / LAMP stack**
- **Apache** web server with `mod_rewrite` enabled

---

## 2. Quick Setup with XAMPP

1. **Copy Files to XAMPP `htdocs`**:
   Copy the `backend` folder into your XAMPP web root:
   ```bash
   # Windows XAMPP path:
   C:\xampp\htdocs\homerent\
   ```
   Or create a symbolic link / virtual host pointing `http://localhost/homerent/api` to `backend/api`.

2. **Create Database & Import Schema**:
   - Start **Apache** and **MySQL** in XAMPP Control Panel.
   - Open **phpMyAdmin** at `http://localhost/phpmyadmin`.
   - Create a database named `homerent_db`.
   - Click **Import** tab and select `backend/database.sql`, then click **Go**.

3. **Verify Database Connection**:
   Open `backend/config/db.php` and verify credentials:
   ```php
   $host = '127.0.0.1';
   $db   = 'homerent_db';
   $user = 'root';
   $pass = ''; // Default XAMPP password is empty
   ```

4. **Test in Browser**:
   Visit:
   `http://localhost/homerent/api/properties.php`
   You should see a JSON array of sample approved Mogoltoli rental properties.

---

## 3. Seeded Accounts & Credentials

| Role | Email | Password | Details |
| :--- | :--- | :--- | :--- |
| **Admin** | `admin@homerent.com` | `admin123` | Full administrative control, approvals, moderation |
| **User (Owner/Renter)** | `rahim@example.com` | `user123` | Can submit, edit listings, search, favorite |
| **User (Owner/Renter)** | `tanvir@example.com` | `user123` | Can submit, edit listings, search, favorite |

---

## 4. Android App Connection

In the Android application:
- When running in the Android Emulator, host `localhost` is accessible via `http://10.0.2.2/homerent/api/`.
- The Android app also includes a built-in offline repository with the same schema and seed data so you can test all features right in the streaming emulator without waiting for external server setup.
- You can change the API endpoint anytime in **Admin Settings > Server Endpoint**.

---

## 5. Mogoltoli, Cumilla Geofence Coordinates

The backend validates all property coordinates against the verified Mogoltoli neighborhood boundary:
- **Latitude Range**: `23.4560` to `23.4680` N
- **Longitude Range**: `91.1800` to `91.1960` E
- Center: `23.4620`, `91.1860` (Mogoltoli Road, near Cumilla Rajganj & Town Hall Link)
