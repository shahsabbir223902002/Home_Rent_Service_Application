<?php
// backend/api/inquiries.php
require_once __DIR__ . '/../config/db.php';

$method = $_SERVER['REQUEST_METHOD'];
$input = json_decode(file_get_contents('php://input'), true) ?: $_POST;

if ($method === 'POST') {
    $propId = (int)($input['property_id'] ?? 0);
    $senderId = (int)($input['sender_id'] ?? 0);
    $senderName = trim($input['sender_name'] ?? '');
    $senderPhone = trim($input['sender_phone'] ?? '');
    $message = trim($input['message'] ?? '');

    if (!$propId || !$senderId || empty($senderName) || empty($senderPhone) || empty($message)) {
        sendResponse('error', 'All inquiry fields are required.', null, 400);
    }

    $stmt = $pdo->prepare('INSERT INTO inquiries (property_id, sender_id, sender_name, sender_phone, message) VALUES (?, ?, ?, ?, ?)');
    $stmt->execute([$propId, $senderId, $senderName, $senderPhone, $message]);

    sendResponse('success', 'Inquiry sent to property owner.', ['id' => $pdo->lastInsertId()], 201);
}

if ($method === 'GET') {
    $userId = (int)($_GET['user_id'] ?? 0);
    $ownerId = (int)($_GET['owner_id'] ?? 0);

    if ($ownerId) {
        $stmt = $pdo->prepare('
            SELECT i.*, p.title as property_title 
            FROM inquiries i 
            JOIN properties p ON i.property_id = p.id 
            WHERE p.owner_id = ? 
            ORDER BY i.id DESC
        ');
        $stmt->execute([$ownerId]);
        sendResponse('success', 'Received inquiries retrieved.', $stmt->fetchAll());
    } else if ($userId) {
        $stmt = $pdo->prepare('
            SELECT i.*, p.title as property_title, u.phone as owner_phone, u.name as owner_name 
            FROM inquiries i 
            JOIN properties p ON i.property_id = p.id 
            JOIN users u ON p.owner_id = u.id 
            WHERE i.sender_id = ? 
            ORDER BY i.id DESC
        ');
        $stmt->execute([$userId]);
        sendResponse('success', 'Sent inquiries retrieved.', $stmt->fetchAll());
    } else {
        sendResponse('error', 'User ID or Owner ID required.', null, 400);
    }
}
