<?php
// backend/api/favorites.php
require_once __DIR__ . '/../config/db.php';

$method = $_SERVER['REQUEST_METHOD'];
$input = json_decode(file_get_contents('php://input'), true) ?: $_POST;

if ($method === 'POST') {
    $userId = (int)($input['user_id'] ?? 0);
    $propId = (int)($input['property_id'] ?? 0);

    if (!$userId || !$propId) {
        sendResponse('error', 'User ID and Property ID are required.', null, 400);
    }

    // Toggle favorite
    $check = $pdo->prepare('SELECT id FROM favorites WHERE user_id = ? AND property_id = ?');
    $check->execute([$userId, $propId]);
    if ($fav = $check->fetch()) {
        $del = $pdo->prepare('DELETE FROM favorites WHERE id = ?');
        $del->execute([$fav['id']]);
        sendResponse('success', 'Removed from favorites.', ['is_favorite' => false]);
    } else {
        $ins = $pdo->prepare('INSERT INTO favorites (user_id, property_id) VALUES (?, ?)');
        $ins->execute([$userId, $propId]);
        sendResponse('success', 'Added to favorites.', ['is_favorite' => true]);
    }
}

if ($method === 'GET') {
    $userId = (int)($_GET['user_id'] ?? 0);
    if (!$userId) {
        sendResponse('error', 'User ID is required.', null, 400);
    }

    $stmt = $pdo->prepare('
        SELECT p.*, u.name as owner_name, u.phone as owner_phone, 1 as is_favorite
        FROM favorites f
        JOIN properties p ON f.property_id = p.id
        JOIN users u ON p.owner_id = u.id
        WHERE f.user_id = ?
        ORDER BY f.id DESC
    ');
    $stmt->execute([$userId]);
    sendResponse('success', 'Favorites retrieved.', $stmt->fetchAll());
}
