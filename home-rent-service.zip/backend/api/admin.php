<?php
// backend/api/admin.php
require_once __DIR__ . '/../config/db.php';

$action = $_GET['action'] ?? '';
$input = json_decode(file_get_contents('php://input'), true) ?: $_POST;

// Server-side role check function
function verifyAdminRole($pdo, $adminId) {
    if (!$adminId) return false;
    $stmt = $pdo->prepare('SELECT role, status FROM users WHERE id = ?');
    $stmt->execute([(int)$adminId]);
    $u = $stmt->fetch();
    return ($u && $u['role'] === 'admin' && $u['status'] === 'active');
}

$adminId = (int)($_SERVER['HTTP_X_ADMIN_ID'] ?? ($input['admin_id'] ?? ($_GET['admin_id'] ?? 0)));

if (!verifyAdminRole($pdo, $adminId)) {
    sendResponse('error', 'Unauthorized: Admin role verification failed.', null, 403);
}

// 1. Dashboard summary stats
if ($action === 'stats') {
    $stats = [];
    $stats['total_users'] = (int)$pdo->query('SELECT COUNT(*) FROM users WHERE role = "user"')->fetchColumn();
    $stats['total_listings'] = (int)$pdo->query('SELECT COUNT(*) FROM properties')->fetchColumn();
    $stats['pending_listings'] = (int)$pdo->query('SELECT COUNT(*) FROM properties WHERE approval_status = "Pending"')->fetchColumn();
    $stats['approved_listings'] = (int)$pdo->query('SELECT COUNT(*) FROM properties WHERE approval_status = "Approved"')->fetchColumn();
    $stats['rejected_listings'] = (int)$pdo->query('SELECT COUNT(*) FROM properties WHERE approval_status = "Rejected"')->fetchColumn();
    $stats['rented_listings'] = (int)$pdo->query('SELECT COUNT(*) FROM properties WHERE availability_status IN ("Rented", "Unavailable")')->fetchColumn();

    sendResponse('success', 'Admin statistics retrieved.', $stats);
}

// 2. Approve listing
if ($action === 'approve') {
    $propId = (int)($input['property_id'] ?? 0);
    $stmt = $pdo->prepare('UPDATE properties SET approval_status = "Approved", rejection_reason = NULL WHERE id = ?');
    $stmt->execute([$propId]);

    // Log action
    $log = $pdo->prepare('INSERT INTO admin_activity_logs (admin_id, admin_name, action, target_type, target_id, details) VALUES (?, ?, ?, ?, ?, ?)');
    $log->execute([$adminId, 'Admin #'.$adminId, 'APPROVE_PROPERTY', 'property', $propId, 'Approved property ID #'.$propId]);

    sendResponse('success', 'Property listing approved successfully.');
}

// 3. Reject listing
if ($action === 'reject') {
    $propId = (int)($input['property_id'] ?? 0);
    $reason = trim($input['reason'] ?? 'Listing did not meet guidelines.');
    $stmt = $pdo->prepare('UPDATE properties SET approval_status = "Rejected", rejection_reason = ? WHERE id = ?');
    $stmt->execute([$reason, $propId]);

    // Log action
    $log = $pdo->prepare('INSERT INTO admin_activity_logs (admin_id, admin_name, action, target_type, target_id, details) VALUES (?, ?, ?, ?, ?, ?)');
    $log->execute([$adminId, 'Admin #'.$adminId, 'REJECT_PROPERTY', 'property', $propId, 'Rejected property ID #'.$propId.': '.$reason]);

    sendResponse('success', 'Property listing rejected.');
}

// 4. Mark rented or unavailable
if ($action === 'update_availability') {
    $propId = (int)($input['property_id'] ?? 0);
    $avail = $input['availability_status'] ?? 'Available';
    $stmt = $pdo->prepare('UPDATE properties SET availability_status = ? WHERE id = ?');
    $stmt->execute([$avail, $propId]);

    sendResponse('success', 'Property availability updated.');
}

// 5. Delete listing
if ($action === 'delete_property') {
    $propId = (int)($input['property_id'] ?? ($_GET['property_id'] ?? 0));
    $stmt = $pdo->prepare('DELETE FROM properties WHERE id = ?');
    $stmt->execute([$propId]);

    $log = $pdo->prepare('INSERT INTO admin_activity_logs (admin_id, admin_name, action, target_type, target_id, details) VALUES (?, ?, ?, ?, ?, ?)');
    $log->execute([$adminId, 'Admin #'.$adminId, 'DELETE_PROPERTY', 'property', $propId, 'Deleted property listing ID #'.$propId]);

    sendResponse('success', 'Listing deleted by admin.');
}

// 6. Manage users: list users
if ($action === 'users') {
    $stmt = $pdo->query('
        SELECT u.id, u.name, u.email, u.phone, u.role, u.status, u.created_at,
               COUNT(p.id) as properties_count
        FROM users u
        LEFT JOIN properties p ON u.id = p.owner_id
        GROUP BY u.id
        ORDER BY u.id DESC
    ');
    sendResponse('success', 'Users retrieved.', $stmt->fetchAll());
}

// 7. Toggle user suspension
if ($action === 'toggle_user_status') {
    $userId = (int)($input['user_id'] ?? 0);
    $newStatus = $input['status'] ?? 'suspended'; // active or suspended
    $stmt = $pdo->prepare('UPDATE users SET status = ? WHERE id = ? AND role != "admin"');
    $stmt->execute([$newStatus, $userId]);

    $log = $pdo->prepare('INSERT INTO admin_activity_logs (admin_id, admin_name, action, target_type, target_id, details) VALUES (?, ?, ?, ?, ?, ?)');
    $log->execute([$adminId, 'Admin #'.$adminId, 'TOGGLE_USER_STATUS', 'user', $userId, 'Changed user status to '.$newStatus]);

    sendResponse('success', 'User status updated to '.$newStatus);
}

// 8. Activity logs
if ($action === 'logs') {
    $stmt = $pdo->query('SELECT * FROM admin_activity_logs ORDER BY id DESC LIMIT 100');
    sendResponse('success', 'Activity logs retrieved.', $stmt->fetchAll());
}

// 9. View reports
if ($action === 'reports') {
    $stmt = $pdo->query('
        SELECT r.*, p.title as property_title, p.address as property_address, p.approval_status
        FROM reports r
        JOIN properties p ON r.property_id = p.id
        ORDER BY r.id DESC
    ');
    sendResponse('success', 'Reports retrieved.', $stmt->fetchAll());
}

sendResponse('error', 'Unknown admin action.', null, 400);
