<?php
// backend/api/auth.php
require_once __DIR__ . '/../config/db.php';

$action = $_GET['action'] ?? '';
$input = json_decode(file_get_contents('php://input'), true) ?: $_POST;

if ($action === 'register') {
    $name = trim($input['name'] ?? '');
    $email = strtolower(trim($input['email'] ?? ''));
    $phone = trim($input['phone'] ?? '');
    $password = $input['password'] ?? '';

    if (empty($name) || empty($email) || empty($phone) || empty($password)) {
        sendResponse('error', 'All fields (name, email, phone, password) are required.', null, 400);
    }

    if (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
        sendResponse('error', 'Invalid email address format.', null, 400);
    }

    // Check if email already registered
    $stmt = $pdo->prepare('SELECT id FROM users WHERE email = ?');
    $stmt->execute([$email]);
    if ($stmt->fetch()) {
        sendResponse('error', 'Email is already registered. Please log in.', null, 409);
    }

    // Secure password hashing with bcrypt
    $hash = password_hash($password, PASSWORD_BCRYPT);
    // Role is strictly 'user' for public registration
    $role = 'user';
    $status = 'active';

    $insertStmt = $pdo->prepare('INSERT INTO users (name, email, phone, password_hash, role, status) VALUES (?, ?, ?, ?, ?, ?)');
    $insertStmt->execute([$name, $email, $phone, $hash, $role, $status]);
    $userId = $pdo->lastInsertId();

    $userData = [
        'id' => (int)$userId,
        'name' => $name,
        'email' => $email,
        'phone' => $phone,
        'role' => $role,
        'status' => $status,
        'token' => bin2hex(random_bytes(24))
    ];

    sendResponse('success', 'User registered successfully.', $userData, 201);
}

if ($action === 'login') {
    $email = strtolower(trim($input['email'] ?? ''));
    $password = $input['password'] ?? '';

    if (empty($email) || empty($password)) {
        sendResponse('error', 'Email and password are required.', null, 400);
    }

    $stmt = $pdo->prepare('SELECT id, name, email, phone, password_hash, role, status FROM users WHERE email = ?');
    $stmt->execute([$email]);
    $user = $stmt->fetch();

    if (!$user || !password_verify($password, $user['password_hash'])) {
        sendResponse('error', 'Invalid email or password.', null, 401);
    }

    if ($user['status'] === 'suspended') {
        sendResponse('error', 'Your account has been suspended by the administrator.', null, 403);
    }

    unset($user['password_hash']);
    $user['id'] = (int)$user['id'];
    $user['token'] = bin2hex(random_bytes(24));

    sendResponse('success', 'Login successful.', $user, 200);
}

sendResponse('error', 'Invalid authentication action.', null, 400);
