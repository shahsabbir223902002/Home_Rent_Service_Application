<?php
// backend/api/reports.php
require_once __DIR__ . '/../config/db.php';

$method = $_SERVER['REQUEST_METHOD'];
$input = json_decode(file_get_contents('php://input'), true) ?: $_POST;

if ($method === 'POST') {
    $propId = (int)($input['property_id'] ?? 0);
    $reporterId = (int)($input['reporter_id'] ?? 0);
    $reporterName = trim($input['reporter_name'] ?? '');
    $reason = trim($input['reason'] ?? '');
    $details = trim($input['details'] ?? '');

    if (!$propId || !$reporterId || empty($reason)) {
        sendResponse('error', 'Property ID, reporter ID, and reason are required.', null, 400);
    }

    $stmt = $pdo->prepare('INSERT INTO reports (property_id, reporter_id, reporter_name, reason, details) VALUES (?, ?, ?, ?, ?)');
    $stmt->execute([$propId, $reporterId, $reporterName, $reason, $details]);

    sendResponse('success', 'Report submitted for admin review.', ['id' => $pdo->lastInsertId()], 201);
}
