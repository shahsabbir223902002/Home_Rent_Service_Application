<?php
// backend/api/properties.php
require_once __DIR__ . '/../config/db.php';
require_once __DIR__ . '/../config/geofence.php';

$method = $_SERVER['REQUEST_METHOD'];
$action = $_GET['action'] ?? '';
$input = json_decode(file_get_contents('php://input'), true) ?: $_POST;

// GET: Retrieve properties
if ($method === 'GET') {
    $id = $_GET['id'] ?? null;
    if ($id) {
        $stmt = $pdo->prepare('
            SELECT p.*, u.name as owner_name, u.phone as owner_phone, u.email as owner_email
            FROM properties p
            JOIN users u ON p.owner_id = u.id
            WHERE p.id = ?
        ');
        $stmt->execute([(int)$id]);
        $prop = $stmt->fetch();
        if (!$prop) {
            sendResponse('error', 'Property not found.', null, 404);
        }
        sendResponse('success', 'Property details retrieved.', $prop);
    }

    // Filter queries
    $category = $_GET['category'] ?? null;
    $status = $_GET['approval_status'] ?? 'Approved'; // Public default is Approved
    $availability = $_GET['availability_status'] ?? null;
    $minRent = $_GET['min_rent'] ?? null;
    $maxRent = $_GET['max_rent'] ?? null;
    $ownerId = $_GET['owner_id'] ?? null;
    $search = $_GET['search'] ?? null;

    $query = '
        SELECT p.*, u.name as owner_name, u.phone as owner_phone
        FROM properties p
        JOIN users u ON p.owner_id = u.id
        WHERE 1=1
    ';
    $params = [];

    if ($ownerId) {
        // Owner viewing their listings (can see all statuses)
        $query .= ' AND p.owner_id = ?';
        $params[] = (int)$ownerId;
    } else {
        // Public browse
        if ($status !== 'all') {
            $query .= ' AND p.approval_status = ?';
            $params[] = $status;
        }
    }

    if ($category && in_array($category, ['house', 'store', 'car_parking'])) {
        $query .= ' AND p.category = ?';
        $params[] = $category;
    }

    if ($availability) {
        $query .= ' AND p.availability_status = ?';
        $params[] = $availability;
    }

    if (is_numeric($minRent)) {
        $query .= ' AND p.rent_monthly >= ?';
        $params[] = (float)$minRent;
    }

    if (is_numeric($maxRent)) {
        $query .= ' AND p.rent_monthly <= ?';
        $params[] = (float)$maxRent;
    }

    if ($search) {
        $query .= ' AND (p.title LIKE ? OR p.address LIKE ? OR p.description LIKE ?)';
        $term = '%' . $search . '%';
        $params[] = $term;
        $params[] = $term;
        $params[] = $term;
    }

    $query .= ' ORDER BY p.id DESC';
    $stmt = $pdo->prepare($query);
    $stmt->execute($params);
    $properties = $stmt->fetchAll();

    sendResponse('success', 'Properties retrieved.', $properties);
}

// POST: Add new property listing
if ($method === 'POST') {
    $ownerId = (int)($input['owner_id'] ?? 0);
    $category = $input['category'] ?? '';
    $title = trim($input['title'] ?? '');
    $description = trim($input['description'] ?? '');
    $rent = (float)($input['rent_monthly'] ?? 0);
    $address = trim($input['address'] ?? '');
    $lat = (float)($input['latitude'] ?? 0);
    $lon = (float)($input['longitude'] ?? 0);

    if (!$ownerId || empty($category) || empty($title) || empty($description) || $rent <= 0 || empty($address)) {
        sendResponse('error', 'All core fields are required and rent must be greater than zero.', null, 400);
    }

    // MANDATORY GEOFENCE CHECK FOR MOGOLTOLI, CUMILLA
    if (!isWithinMogoltoli($lat, $lon)) {
        sendResponse('error', 'Invalid location! Property must be located strictly within Mogoltoli, Cumilla service boundary (Lat: 23.4560 - 23.4680, Lon: 91.1800 - 91.1960).', null, 422);
    }

    $bedrooms = isset($input['bedrooms']) ? (int)$input['bedrooms'] : 0;
    $bathrooms = isset($input['bathrooms']) ? (int)$input['bathrooms'] : 0;
    $houseRules = $input['house_rules'] ?? '';
    $floorArea = isset($input['floor_area_sqft']) ? (int)$input['floor_area_sqft'] : 0;
    $commercialDetails = $input['commercial_details'] ?? '';
    $vehicleType = $input['vehicle_type'] ?? '';
    $capacity = isset($input['capacity']) ? (int)$input['capacity'] : 1;
    $isCovered = isset($input['is_covered']) ? (int)$input['is_covered'] : 1;
    $facilities = $input['facilities'] ?? '';

    // Status MUST be 'Pending' initially
    $approvalStatus = 'Pending';
    $availabilityStatus = 'Available';

    $stmt = $pdo->prepare('
        INSERT INTO properties 
        (owner_id, category, title, description, rent_monthly, address, latitude, longitude, 
         approval_status, availability_status, bedrooms, bathrooms, floor_area_sqft, 
         vehicle_type, capacity, is_covered, house_rules, commercial_details, facilities)
        VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
    ');

    $stmt->execute([
        $ownerId, $category, $title, $description, $rent, $address, $lat, $lon,
        $approvalStatus, $availabilityStatus, $bedrooms, $bathrooms, $floorArea,
        $vehicleType, $capacity, $isCovered, $houseRules, $commercialDetails, $facilities
    ]);

    $newId = (int)$pdo->lastInsertId();

    sendResponse('success', 'Rental listing submitted for Mogoltoli, Cumilla. Initial status is Pending admin approval.', ['id' => $newId], 201);
}

// PUT: Update existing property listing
if ($method === 'PUT') {
    $propId = (int)($input['id'] ?? 0);
    $ownerId = (int)($input['owner_id'] ?? 0);

    if (!$propId || !$ownerId) {
        sendResponse('error', 'Property ID and Owner ID are required.', null, 400);
    }

    // Verify owner
    $check = $pdo->prepare('SELECT owner_id, approval_status FROM properties WHERE id = ?');
    $check->execute([$propId]);
    $existing = $check->fetch();
    if (!$existing) {
        sendResponse('error', 'Property not found.', null, 404);
    }
    if ((int)$existing['owner_id'] !== $ownerId) {
        sendResponse('error', 'Unauthorized. You can only edit your own listings.', null, 403);
    }

    // If changing location, re-verify Mogoltoli geofence
    $lat = isset($input['latitude']) ? (float)$input['latitude'] : null;
    $lon = isset($input['longitude']) ? (float)$input['longitude'] : null;
    if ($lat !== null && $lon !== null && !isWithinMogoltoli($lat, $lon)) {
        sendResponse('error', 'Updated location must be inside Mogoltoli, Cumilla service area.', null, 422);
    }

    // Material edits re-trigger Pending approval status
    $newApproval = 'Pending';
    $title = trim($input['title'] ?? '');
    $description = trim($input['description'] ?? '');
    $rent = (float)($input['rent_monthly'] ?? 0);
    $address = trim($input['address'] ?? '');
    $availability = $input['availability_status'] ?? 'Available';

    $update = $pdo->prepare('
        UPDATE properties SET 
            title = COALESCE(NULLIF(?, ""), title),
            description = COALESCE(NULLIF(?, ""), description),
            rent_monthly = CASE WHEN ? > 0 THEN ? ELSE rent_monthly END,
            address = COALESCE(NULLIF(?, ""), address),
            availability_status = ?,
            approval_status = ?
        WHERE id = ? AND owner_id = ?
    ');
    $update->execute([$title, $description, $rent, $rent, $address, $availability, $newApproval, $propId, $ownerId]);

    sendResponse('success', 'Listing updated. Pending admin review for updated changes.');
}

// DELETE: Remove property listing
if ($method === 'DELETE') {
    $propId = (int)($_GET['id'] ?? 0);
    $ownerId = (int)($_GET['owner_id'] ?? 0);

    $stmt = $pdo->prepare('DELETE FROM properties WHERE id = ? AND owner_id = ?');
    $stmt->execute([$propId, $ownerId]);

    if ($stmt->rowCount() === 0) {
        sendResponse('error', 'Listing could not be deleted or access denied.', null, 404);
    }

    sendResponse('success', 'Listing successfully deleted.');
}
