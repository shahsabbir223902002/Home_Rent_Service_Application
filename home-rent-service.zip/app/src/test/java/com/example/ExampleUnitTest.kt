package com.example

import com.example.data.model.*
import com.example.data.repository.HomeRentRepository
import com.example.data.util.MogoltoliGeofence
import kotlinx.coroutines.runBlocking
import org.junit.Assert.*
import org.junit.Test

class ExampleUnitTest {

    @Test
    fun mogoltoliGeofence_correctlyValidatesCoordinates() {
        // Valid Mogoltoli coordinates (Center of Mogoltoli, Cumilla)
        assertTrue(MogoltoliGeofence.isWithinMogoltoli(23.4620, 91.1860))
        assertTrue(MogoltoliGeofence.isWithinMogoltoli(23.4612, 91.1853)) // Rajganj Road
        assertTrue(MogoltoliGeofence.isWithinMogoltoli(23.4635, 91.1878)) // Mogoltoli Bazaar

        // Outside Mogoltoli coordinates
        assertFalse(MogoltoliGeofence.isWithinMogoltoli(23.8103, 90.4125)) // Dhaka
        assertFalse(MogoltoliGeofence.isWithinMogoltoli(23.4400, 91.1860)) // South of Mogoltoli
        assertFalse(MogoltoliGeofence.isWithinMogoltoli(23.4620, 91.2200)) // East of Mogoltoli
    }

    @Test
    fun newRentalSubmission_hasInitialPendingStatus() = runBlocking {
        val repo = HomeRentRepository()
        val user = repo.users.value.first { !it.isAdmin }
        repo.switchUser(user)

        val result = repo.addProperty(
            category = PropertyCategory.HOUSE,
            title = "Test House in Mogoltoli",
            description = "Spacious house near Rajganj",
            rentMonthly = 16000.0,
            address = "Holding #12, Mogoltoli, Cumilla",
            latitude = 23.4620,
            longitude = 91.1860
        )

        assertTrue(result.isSuccess)
        val newProperty = result.getOrNull()
        assertNotNull(newProperty)
        assertEquals(ApprovalStatus.PENDING, newProperty?.approvalStatus)
    }

    @Test
    fun submissionOutsideMogoltoli_isRejectedByRepository() = runBlocking {
        val repo = HomeRentRepository()
        val user = repo.users.value.first { !it.isAdmin }
        repo.switchUser(user)

        // Coordinates in Dhaka (outside Mogoltoli)
        val result = repo.addProperty(
            category = PropertyCategory.STORE,
            title = "Shop Outside Area",
            description = "Invalid location",
            rentMonthly = 20000.0,
            address = "Dhaka Road",
            latitude = 23.8103,
            longitude = 90.4125
        )

        assertTrue(result.isFailure)
        assertTrue(result.exceptionOrNull()?.message?.contains("Mogoltoli") == true)
    }

    @Test
    fun adminApprovalWorkflow_updatesStatusAndLogsAction() = runBlocking {
        val repo = HomeRentRepository()
        val admin = repo.users.value.first { it.isAdmin }

        // Property #5 is seeded as PENDING
        val pendingProp = repo.properties.value.find { it.id == 5 }
        assertNotNull(pendingProp)
        assertEquals(ApprovalStatus.PENDING, pendingProp?.approvalStatus)

        // Admin approves
        val approveResult = repo.adminApprove(5, admin)
        assertTrue(approveResult.isSuccess)

        val updatedProp = repo.properties.value.find { it.id == 5 }
        assertEquals(ApprovalStatus.APPROVED, updatedProp?.approvalStatus)

        // Admin activity log contains record
        val latestLog = repo.activityLogs.value.first()
        assertEquals("APPROVE_PROPERTY", latestLog.action)
    }

    @Test
    fun adminRejectionWorkflow_recordsReason() = runBlocking {
        val repo = HomeRentRepository()
        val admin = repo.users.value.first { it.isAdmin }

        val reason = "Incorrect documentation"
        val rejectResult = repo.adminReject(5, reason, admin)
        assertTrue(rejectResult.isSuccess)

        val updatedProp = repo.properties.value.find { it.id == 5 }
        assertEquals(ApprovalStatus.REJECTED, updatedProp?.approvalStatus)
        assertEquals(reason, updatedProp?.rejectionReason)
    }
}
