package com.example

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.viewModels
import androidx.compose.foundation.layout.*
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.ui.screens.*
import com.example.ui.theme.*
import com.example.ui.viewmodel.MainViewModel
import com.example.ui.viewmodel.Screen

class MainActivity : ComponentActivity() {

    private val viewModel: MainViewModel by viewModels()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContent {
            MyApplicationTheme {
                HomeRentApp(viewModel = viewModel)
            }
        }
    }
}

@Composable
fun HomeRentApp(viewModel: MainViewModel) {
    val currentScreen by viewModel.currentScreen.collectAsState()
    val userMessage by viewModel.userMessage.collectAsState()
    val snackbarHostState = remember { SnackbarHostState() }

    // Display user messages via Snackbar
    LaunchedEffect(userMessage) {
        userMessage?.let {
            snackbarHostState.showSnackbar(it)
            viewModel.clearUserMessage()
        }
    }

    // Determine whether to display User bottom navigation bar
    val isUserPortalScreen = when (currentScreen) {
        Screen.USER_HOME, Screen.PROPERTY_LIST, Screen.PROPERTY_MAP,
        Screen.MY_LISTINGS, Screen.USER_PROFILE, Screen.FAVORITES, Screen.INQUIRIES -> true
        else -> false
    }

    Scaffold(
        modifier = Modifier.fillMaxSize(),
        snackbarHost = { SnackbarHost(snackbarHostState) },
        bottomBar = {
            if (isUserPortalScreen) {
                NavigationBar(
                    containerColor = MaterialTheme.colorScheme.surface,
                    tonalElevation = 6.dp,
                    windowInsets = WindowInsets.navigationBars
                ) {
                    NavigationBarItem(
                        selected = currentScreen == Screen.USER_HOME,
                        onClick = { viewModel.navigateTo(Screen.USER_HOME) },
                        icon = { Icon(Icons.Default.Home, contentDescription = "Home") },
                        label = { Text("Home", fontSize = 11.sp) },
                        colors = NavigationBarItemDefaults.colors(
                            selectedIconColor = BrandTealDark,
                            indicatorColor = BrandMintLight
                        ),
                        modifier = Modifier.testTag("nav_home")
                    )

                    NavigationBarItem(
                        selected = currentScreen == Screen.PROPERTY_LIST,
                        onClick = { viewModel.navigateTo(Screen.PROPERTY_LIST) },
                        icon = { Icon(Icons.Default.Search, contentDescription = "Search") },
                        label = { Text("Explore", fontSize = 11.sp) },
                        colors = NavigationBarItemDefaults.colors(
                            selectedIconColor = BrandTealDark,
                            indicatorColor = BrandMintLight
                        ),
                        modifier = Modifier.testTag("nav_explore")
                    )

                    NavigationBarItem(
                        selected = currentScreen == Screen.PROPERTY_MAP,
                        onClick = { viewModel.navigateTo(Screen.PROPERTY_MAP) },
                        icon = { Icon(Icons.Default.Map, contentDescription = "Map") },
                        label = { Text("Map", fontSize = 11.sp) },
                        colors = NavigationBarItemDefaults.colors(
                            selectedIconColor = BrandTealDark,
                            indicatorColor = BrandMintLight
                        ),
                        modifier = Modifier.testTag("nav_map")
                    )

                    NavigationBarItem(
                        selected = currentScreen == Screen.MY_LISTINGS,
                        onClick = { viewModel.navigateTo(Screen.MY_LISTINGS) },
                        icon = { Icon(Icons.Default.Inventory2, contentDescription = "My Listings") },
                        label = { Text("My Rentals", fontSize = 11.sp) },
                        colors = NavigationBarItemDefaults.colors(
                            selectedIconColor = BrandTealDark,
                            indicatorColor = BrandMintLight
                        ),
                        modifier = Modifier.testTag("nav_my_listings")
                    )

                    NavigationBarItem(
                        selected = currentScreen == Screen.USER_PROFILE,
                        onClick = { viewModel.navigateTo(Screen.USER_PROFILE) },
                        icon = { Icon(Icons.Default.Person, contentDescription = "Profile") },
                        label = { Text("Profile", fontSize = 11.sp) },
                        colors = NavigationBarItemDefaults.colors(
                            selectedIconColor = BrandTealDark,
                            indicatorColor = BrandMintLight
                        ),
                        modifier = Modifier.testTag("nav_profile")
                    )
                }
            }
        }
    ) { innerPadding ->
        Box(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
        ) {
            when (currentScreen) {
                Screen.SPLASH, Screen.LOGIN -> LoginScreen(
                    viewModel = viewModel,
                    onNavigateToRegister = { viewModel.navigateTo(Screen.REGISTER) }
                )
                Screen.REGISTER -> RegisterScreen(
                    viewModel = viewModel,
                    onNavigateToLogin = { viewModel.navigateTo(Screen.LOGIN) }
                )
                Screen.USER_HOME -> UserHomeScreen(viewModel = viewModel)
                Screen.PROPERTY_LIST -> PropertyListScreen(viewModel = viewModel)
                Screen.PROPERTY_MAP -> PropertyMapScreen(viewModel = viewModel)
                Screen.PROPERTY_DETAIL -> PropertyDetailScreen(viewModel = viewModel)
                Screen.ADD_PROPERTY -> AddPropertyScreen(viewModel = viewModel)
                Screen.MY_LISTINGS -> MyListingsScreen(viewModel = viewModel)
                Screen.FAVORITES -> FavoritesScreen(viewModel = viewModel)
                Screen.INQUIRIES -> InquiriesScreen(viewModel = viewModel)
                Screen.USER_PROFILE -> UserProfileScreen(viewModel = viewModel)
                // Admin Interface
                Screen.ADMIN_DASHBOARD -> AdminDashboardScreen(viewModel = viewModel)
                Screen.ADMIN_LISTINGS -> AdminListingsScreen(viewModel = viewModel)
                Screen.ADMIN_MAP -> AdminMapScreen(viewModel = viewModel)
                Screen.ADMIN_USERS -> AdminUsersScreen(viewModel = viewModel)
                Screen.ADMIN_REPORTS -> AdminReportsScreen(viewModel = viewModel)
                Screen.ADMIN_LOGS -> AdminLogsScreen(viewModel = viewModel)
                Screen.ADMIN_SETTINGS -> AdminSettingsScreen(viewModel = viewModel)
            }
        }
    }
}
