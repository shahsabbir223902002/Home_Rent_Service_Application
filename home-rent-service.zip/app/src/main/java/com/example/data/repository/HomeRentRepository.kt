package com.example.data.repository

import com.example.data.model.*
import com.example.data.remote.ApiClient
import com.example.data.util.MogoltoliGeofence
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.update

class HomeRentRepository {

    // Default Seed Users
    private val seedUsers = listOf(
        User(1, "System Administrator", "admin@homerent.com", "+8801711000111", "admin", "active"),
        User(2, "Abdur Rahim", "rahim@example.com", "+8801812345678", "user", "active"),
        User(3, "Tanvir Hossain", "tanvir@example.com", "+8801919876543", "user", "active"),
        User(4, "Nasrin Akter", "nasrin@example.com", "+8801614567890", "user", "active")
    )

    // Default Seed Properties (Strictly Mogoltoli, Cumilla)
    private val seedProperties = listOf(
        Property(
            id = 1,
            ownerId = 2,
            ownerName = "Abdur Rahim",
            ownerPhone = "+8801812345678",
            category = PropertyCategory.HOUSE,
            title = "Spacious 3-BHK Family Flat near Rajganj Road",
            description = "Well-ventilated 3 bedroom flat on 4th floor with lift and standby generator. Located 2 minutes walking distance from Rajganj intersection in Mogoltoli.",
            rentMonthly = 18500.0,
            address = "Holding #42, Rajganj Road, Mogoltoli, Cumilla",
            latitude = 23.4612,
            longitude = 91.1853,
            approvalStatus = ApprovalStatus.APPROVED,
            availabilityStatus = AvailabilityStatus.AVAILABLE,
            bedrooms = 3,
            bathrooms = 2,
            floorAreaSqft = 1350,
            houseRules = "Family only, no pets, main gate closes at 11 PM",
            facilities = listOf("Lift", "Generator Backup", "Gas Line", "2 Open Balconies", "24/7 Security", "CCTV"),
            imageUrls = listOf("https://images.unsplash.com/photo-1502672260266-1c1ef2d93688?w=800&q=80", "https://images.unsplash.com/photo-1560448204-e02f11c3d0e2?w=800&q=80")
        ),
        Property(
            id = 2,
            ownerId = 2,
            ownerName = "Abdur Rahim",
            ownerPhone = "+8801812345678",
            category = PropertyCategory.STORE,
            title = "Prime Corner Commercial Store at Mogoltoli Bazaar",
            description = "Ground floor commercial shop suitable for pharmacy, grocery, departmental or telecom store. High pedestrian footfall on main Mogoltoli bazaar road.",
            rentMonthly = 22000.0,
            address = "Shop #12, Mogoltoli Main Road, Cumilla",
            latitude = 23.4635,
            longitude = 91.1878,
            approvalStatus = ApprovalStatus.APPROVED,
            availabilityStatus = AvailabilityStatus.AVAILABLE,
            floorAreaSqft = 320,
            commercialDetails = "Commercial trade license required, 2 months advance security deposit",
            facilities = listOf("Rolling Shutter", "Commercial Meter", "Water Line", "Front Road 20ft", "Tiled Floor"),
            imageUrls = listOf("https://images.unsplash.com/photo-1555396273-367ea4eb4db5?w=800&q=80")
        ),
        Property(
            id = 3,
            ownerId = 3,
            ownerName = "Tanvir Hossain",
            ownerPhone = "+8801919876543",
            category = PropertyCategory.CAR_PARKING,
            title = "Secure Covered Car Parking Space near Town Hall Link",
            description = "Gated, covered dedicated parking slot with 24-hour CCTV surveillance and security guard. Ideal for Sedans, SUVs, or private cars.",
            rentMonthly = 3500.0,
            address = "Green Heritage Building, Mogoltoli Road, Cumilla",
            latitude = 23.4594,
            longitude = 91.1831,
            approvalStatus = ApprovalStatus.APPROVED,
            availabilityStatus = AvailabilityStatus.AVAILABLE,
            vehicleType = "Sedan / SUV / Private Car",
            capacity = 1,
            isCovered = true,
            facilities = listOf("CCTV Surveillance", "Covered Roof", "Security Guard", "Automatic Sensor Light", "Car Wash Space"),
            imageUrls = listOf("https://images.unsplash.com/photo-1506521781263-d8422e82f27a?w=800&q=80")
        ),
        Property(
            id = 4,
            ownerId = 4,
            ownerName = "Nasrin Akter",
            ownerPhone = "+8801614567890",
            category = PropertyCategory.HOUSE,
            title = "Modern 2-BHK Apartment with Lake Breeze",
            description = "South-facing 2 bedroom flat with open balcony and natural light. Quiet residential pocket of Mogoltoli near Gomti embankment link.",
            rentMonthly = 14000.0,
            address = "House #18, Lane 3, South Mogoltoli, Cumilla",
            latitude = 23.4578,
            longitude = 91.1895,
            approvalStatus = ApprovalStatus.APPROVED,
            availabilityStatus = AvailabilityStatus.AVAILABLE,
            bedrooms = 2,
            bathrooms = 2,
            floorAreaSqft = 980,
            houseRules = "Small family or working female professionals",
            facilities = listOf("Gas Connection", "South Balcony", "Water Pump", "Tiled Floor", "Intercom"),
            imageUrls = listOf("https://images.unsplash.com/photo-1522708323590-d24dbb6b0267?w=800&q=80")
        ),
        Property(
            id = 5,
            ownerId = 3,
            ownerName = "Tanvir Hossain",
            ownerPhone = "+8801919876543",
            category = PropertyCategory.HOUSE,
            title = "Affordable 1-Bed Studio Flat for Small Family",
            description = "Cozy 1-bed flat with attached bath and kitchenette. Clean, secure premises in central Mogoltoli. Pending initial administrative review.",
            rentMonthly = 8500.0,
            address = "Holding #7, Shahi Lane, Mogoltoli, Cumilla",
            latitude = 23.4648,
            longitude = 91.1842,
            approvalStatus = ApprovalStatus.PENDING,
            availabilityStatus = AvailabilityStatus.AVAILABLE,
            bedrooms = 1,
            bathrooms = 1,
            floorAreaSqft = 550,
            houseRules = "Non-smokers, prepaid meter for electricity",
            facilities = listOf("Prepaid Electric Meter", "Water Supply", "Roof Access"),
            imageUrls = listOf("https://images.unsplash.com/photo-1493809842364-78817add7ffb?w=800&q=80")
        ),
        Property(
            id = 6,
            ownerId = 4,
            ownerName = "Nasrin Akter",
            ownerPhone = "+8801614567890",
            category = PropertyCategory.STORE,
            title = "Spacious Showroom / Office Space on 1st Floor",
            description = "Well-decorated open commercial space ideal for IT office, coaching center, or showroom near Cumilla Chawkbazar connector.",
            rentMonthly = 30000.0,
            address = "Al-Noor Tower, 1st Floor, Mogoltoli, Cumilla",
            latitude = 23.4665,
            longitude = 91.1882,
            approvalStatus = ApprovalStatus.APPROVED,
            availabilityStatus = AvailabilityStatus.AVAILABLE,
            floorAreaSqft = 850,
            commercialDetails = "Ideal for corporate branch, diagnostics, or IT consultancy",
            facilities = listOf("Lift", "3-Phase Commercial Electric", "Separate Washroom", "Wide Glass Frontage"),
            imageUrls = listOf("https://images.unsplash.com/photo-1497366216548-37526070297c?w=800&q=80")
        ),
        Property(
            id = 7,
            ownerId = 2,
            ownerName = "Abdur Rahim",
            ownerPhone = "+8801812345678",
            category = PropertyCategory.CAR_PARKING,
            title = "Dual Covered Motorcycle & Microbus Parking Spot",
            description = "Safe multi-vehicle parking slot inside modern apartment building basement with 24/7 night guard.",
            rentMonthly = 2500.0,
            address = "Lotus Tower Basement, Mogoltoli, Cumilla",
            latitude = 23.4605,
            longitude = 91.1865,
            approvalStatus = ApprovalStatus.APPROVED,
            availabilityStatus = AvailabilityStatus.AVAILABLE,
            vehicleType = "Microbus / Motorcycle",
            capacity = 2,
            isCovered = true,
            facilities = listOf("CCTV", "Basement Shade", "Fire Extinguisher", "24/7 Security"),
            imageUrls = listOf("https://images.unsplash.com/photo-1590674899484-d5640e854abe?w=800&q=80")
        )
    )

    // Reactive State Holders
    private val _users = MutableStateFlow(seedUsers)
    val users: StateFlow<List<User>> = _users.asStateFlow()

    private val _currentUser = MutableStateFlow<User?>(seedUsers[1]) // Default to Abdur Rahim for instant interactive preview
    val currentUser: StateFlow<User?> = _currentUser.asStateFlow()

    private val _properties = MutableStateFlow(seedProperties)
    val properties: StateFlow<List<Property>> = _properties.asStateFlow()

    private val _favorites = MutableStateFlow<Set<Int>>(setOf(1, 3))
    val favorites: StateFlow<Set<Int>> = _favorites.asStateFlow()

    private val _inquiries = MutableStateFlow<List<Inquiry>>(
        listOf(
            Inquiry(1, 1, "Spacious 3-BHK Family Flat", 3, "Tanvir Hossain", "+8801919876543", "Hello Rahim bhai, is this flat available from next month? Can we visit this Friday afternoon?"),
            Inquiry(2, 3, "Secure Covered Car Parking", 2, "Abdur Rahim", "+8801812345678", "I have a Toyota Corolla sedan. Is the parking height and turning radius comfortable?")
        )
    )
    val inquiries: StateFlow<List<Inquiry>> = _inquiries.asStateFlow()

    private val _reports = MutableStateFlow<List<Report>>(
        listOf(
            Report(1, 2, "Prime Corner Commercial Store", 4, "Nasrin Akter", "Incorrect price", "Owner quoted 25k instead of 22k when visited in person.")
        )
    )
    val reports: StateFlow<List<Report>> = _reports.asStateFlow()

    private val _activityLogs = MutableStateFlow<List<AdminActivityLog>>(
        listOf(
            AdminActivityLog(1, 1, "System Admin", "APPROVE_PROPERTY", "property", 1, "Approved listing #1 (Spacious 3-BHK Flat)"),
            AdminActivityLog(2, 1, "System Admin", "APPROVE_PROPERTY", "property", 2, "Approved listing #2 (Prime Commercial Store)"),
            AdminActivityLog(3, 1, "System Admin", "APPROVE_PROPERTY", "property", 3, "Approved listing #3 (Covered Car Parking)")
        )
    )
    val activityLogs: StateFlow<List<AdminActivityLog>> = _activityLogs.asStateFlow()

    private var nextPropertyId = 8
    private var nextInquiryId = 3
    private var nextReportId = 2
    private var nextLogId = 4

    // ---------------- AUTHENTICATION ----------------
    suspend fun login(email: String, pass: String): Result<User> {
        val user = _users.value.find { it.email.equals(email.trim(), ignoreCase = true) }
        return if (user != null) {
            if (user.status == "suspended") {
                Result.failure(Exception("This account has been suspended by the administrator."))
            } else {
                _currentUser.value = user
                Result.success(user)
            }
        } else {
            Result.failure(Exception("Invalid email or password."))
        }
    }

    suspend fun register(name: String, email: String, phone: String, pass: String): Result<User> {
        if (_users.value.any { it.email.equals(email.trim(), ignoreCase = true) }) {
            return Result.failure(Exception("Email already registered."))
        }
        val newUser = User(
            id = _users.value.maxOf { it.id } + 1,
            name = name.trim(),
            email = email.trim().lowercase(),
            phone = phone.trim(),
            role = "user", // Normal registration is strictly user
            status = "active"
        )
        _users.update { it + newUser }
        _currentUser.value = newUser
        return Result.success(newUser)
    }

    fun logout() {
        _currentUser.value = null
    }

    fun switchUser(user: User) {
        _currentUser.value = user
    }

    // ---------------- LISTING WORKFLOW ----------------
    suspend fun addProperty(
        category: PropertyCategory,
        title: String,
        description: String,
        rentMonthly: Double,
        address: String,
        latitude: Double,
        longitude: Double,
        bedrooms: Int = 0,
        bathrooms: Int = 0,
        floorAreaSqft: Int = 0,
        vehicleType: String? = null,
        capacity: Int = 1,
        isCovered: Boolean = true,
        houseRules: String? = null,
        commercialDetails: String? = null,
        facilities: List<String> = emptyList(),
        imageUrls: List<String> = emptyList()
    ): Result<Property> {
        val user = _currentUser.value ?: return Result.failure(Exception("Please log in first."))

        // MANDATORY MOGOLTOLI GEOFENCE CHECK
        if (!MogoltoliGeofence.isWithinMogoltoli(latitude, longitude)) {
            return Result.failure(
                Exception("Location outside Mogoltoli service boundary! Property must be located strictly in Mogoltoli, Cumilla (Lat: 23.4560 - 23.4680, Lon: 91.1800 - 91.1960).")
            )
        }

        val newProp = Property(
            id = nextPropertyId++,
            ownerId = user.id,
            ownerName = user.name,
            ownerPhone = user.phone,
            category = category,
            title = title,
            description = description,
            rentMonthly = rentMonthly,
            address = address,
            latitude = latitude,
            longitude = longitude,
            approvalStatus = ApprovalStatus.PENDING, // Must be Pending initially!
            availabilityStatus = AvailabilityStatus.AVAILABLE,
            bedrooms = bedrooms,
            bathrooms = bathrooms,
            floorAreaSqft = floorAreaSqft,
            vehicleType = vehicleType,
            capacity = capacity,
            isCovered = isCovered,
            houseRules = houseRules,
            commercialDetails = commercialDetails,
            facilities = facilities,
            imageUrls = imageUrls.ifEmpty {
                listOf(
                    when (category) {
                        PropertyCategory.HOUSE -> "https://images.unsplash.com/photo-1502672260266-1c1ef2d93688?w=800&q=80"
                        PropertyCategory.STORE -> "https://images.unsplash.com/photo-1555396273-367ea4eb4db5?w=800&q=80"
                        PropertyCategory.CAR_PARKING -> "https://images.unsplash.com/photo-1506521781263-d8422e82f27a?w=800&q=80"
                    }
                )
            }
        )

        _properties.update { listOf(newProp) + it }
        return Result.success(newProp)
    }

    suspend fun updateProperty(updated: Property): Result<Unit> {
        val user = _currentUser.value ?: return Result.failure(Exception("Please log in first."))
        if (!user.isAdmin && updated.ownerId != user.id) {
            return Result.failure(Exception("Unauthorized. You can only edit your own listings."))
        }

        if (!MogoltoliGeofence.isWithinMogoltoli(updated.latitude, updated.longitude)) {
            return Result.failure(Exception("Location must be inside Mogoltoli, Cumilla."))
        }

        // Material changes trigger Pending reapproval if updated by user
        val propToSave = if (!user.isAdmin) {
            updated.copy(approvalStatus = ApprovalStatus.PENDING)
        } else {
            updated
        }

        _properties.update { list ->
            list.map { if (it.id == updated.id) propToSave else it }
        }
        return Result.success(Unit)
    }

    suspend fun deleteProperty(propertyId: Int): Result<Unit> {
        val user = _currentUser.value ?: return Result.failure(Exception("Please log in first."))
        val prop = _properties.value.find { it.id == propertyId } ?: return Result.failure(Exception("Property not found."))
        if (!user.isAdmin && prop.ownerId != user.id) {
            return Result.failure(Exception("Unauthorized."))
        }

        _properties.update { list -> list.filterNot { it.id == propertyId } }
        return Result.success(Unit)
    }

    // ---------------- ADMIN ACTIONS ----------------
    suspend fun adminApprove(propertyId: Int, adminUser: User): Result<Unit> {
        if (!adminUser.isAdmin) return Result.failure(Exception("Admin role required."))
        _properties.update { list ->
            list.map {
                if (it.id == propertyId) it.copy(approvalStatus = ApprovalStatus.APPROVED, rejectionReason = null) else it
            }
        }
        addLog(adminUser, "APPROVE_PROPERTY", "property", propertyId, "Approved listing #$propertyId")
        return Result.success(Unit)
    }

    suspend fun adminReject(propertyId: Int, reason: String, adminUser: User): Result<Unit> {
        if (!adminUser.isAdmin) return Result.failure(Exception("Admin role required."))
        _properties.update { list ->
            list.map {
                if (it.id == propertyId) it.copy(approvalStatus = ApprovalStatus.REJECTED, rejectionReason = reason) else it
            }
        }
        addLog(adminUser, "REJECT_PROPERTY", "property", propertyId, "Rejected listing #$propertyId: $reason")
        return Result.success(Unit)
    }

    suspend fun updateAvailability(propertyId: Int, availability: AvailabilityStatus): Result<Unit> {
        _properties.update { list ->
            list.map { if (it.id == propertyId) it.copy(availabilityStatus = availability) else it }
        }
        return Result.success(Unit)
    }

    suspend fun toggleUserSuspension(userId: Int, adminUser: User): Result<String> {
        if (!adminUser.isAdmin) return Result.failure(Exception("Admin role required."))
        var newStatus = "active"
        _users.update { list ->
            list.map {
                if (it.id == userId && !it.isAdmin) {
                    newStatus = if (it.status == "active") "suspended" else "active"
                    it.copy(status = newStatus)
                } else it
            }
        }
        addLog(adminUser, "TOGGLE_USER_STATUS", "user", userId, "Changed user #$userId status to $newStatus")
        return Result.success(newStatus)
    }

    private fun addLog(admin: User, action: String, targetType: String, targetId: Int, details: String) {
        val log = AdminActivityLog(
            id = nextLogId++,
            adminId = admin.id,
            adminName = admin.name,
            action = action,
            targetType = targetType,
            targetId = targetId,
            details = details
        )
        _activityLogs.update { listOf(log) + it }
    }

    // ---------------- FAVORITES & INQUIRIES ----------------
    fun toggleFavorite(propertyId: Int) {
        _favorites.update { set ->
            if (set.contains(propertyId)) set - propertyId else set + propertyId
        }
    }

    fun isFavorite(propertyId: Int): Boolean = _favorites.value.contains(propertyId)

    suspend fun submitInquiry(propertyId: Int, propertyTitle: String, message: String): Result<Unit> {
        val user = _currentUser.value ?: return Result.failure(Exception("Please log in first."))
        val inquiry = Inquiry(
            id = nextInquiryId++,
            propertyId = propertyId,
            propertyTitle = propertyTitle,
            senderId = user.id,
            senderName = user.name,
            senderPhone = user.phone,
            message = message
        )
        _inquiries.update { listOf(inquiry) + it }
        return Result.success(Unit)
    }

    suspend fun submitReport(propertyId: Int, propertyTitle: String, reason: String, details: String): Result<Unit> {
        val user = _currentUser.value ?: return Result.failure(Exception("Please log in first."))
        val report = Report(
            id = nextReportId++,
            propertyId = propertyId,
            propertyTitle = propertyTitle,
            reporterId = user.id,
            reporterName = user.name,
            reason = reason,
            details = details
        )
        _reports.update { listOf(report) + it }
        return Result.success(Unit)
    }

    fun getDashboardStats(): DashboardStats {
        val props = _properties.value
        return DashboardStats(
            totalUsers = _users.value.count { !it.isAdmin },
            totalListings = props.size,
            pendingListings = props.count { it.approvalStatus == ApprovalStatus.PENDING },
            approvedListings = props.count { it.approvalStatus == ApprovalStatus.APPROVED },
            rejectedListings = props.count { it.approvalStatus == ApprovalStatus.REJECTED },
            rentedListings = props.count { it.availabilityStatus == AvailabilityStatus.RENTED || it.availabilityStatus == AvailabilityStatus.UNAVAILABLE }
        )
    }
}
