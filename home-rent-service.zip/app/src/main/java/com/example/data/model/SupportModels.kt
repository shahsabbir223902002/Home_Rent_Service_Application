package com.example.data.model

data class Inquiry(
    val id: Int,
    val propertyId: Int,
    val propertyTitle: String,
    val senderId: Int,
    val senderName: String,
    val senderPhone: String,
    val message: String,
    val timestamp: String = "Just now"
)

data class Report(
    val id: Int,
    val propertyId: Int,
    val propertyTitle: String,
    val reporterId: Int,
    val reporterName: String,
    val reason: String,
    val details: String,
    val status: String = "pending", // "pending", "reviewed", "resolved"
    val timestamp: String = "Recent"
)

data class AdminActivityLog(
    val id: Int,
    val adminId: Int,
    val adminName: String,
    val action: String,
    val targetType: String,
    val targetId: Int,
    val details: String,
    val timestamp: String = "Recent"
)

data class DashboardStats(
    val totalUsers: Int = 0,
    val totalListings: Int = 0,
    val pendingListings: Int = 0,
    val approvedListings: Int = 0,
    val rejectedListings: Int = 0,
    val rentedListings: Int = 0
)
