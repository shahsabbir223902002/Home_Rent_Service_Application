package com.example.data.util

object MogoltoliGeofence {
    const val MIN_LAT = 23.4560
    const val MAX_LAT = 23.4680
    const val MIN_LON = 91.1800
    const val MAX_LON = 91.1960

    const val CENTER_LAT = 23.4620
    const val CENTER_LON = 91.1860

    data class Landmark(
        val name: String,
        val lat: Double,
        val lon: Double,
        val type: String
    )

    val LANDMARKS = listOf(
        Landmark("Rajganj Road Entrance", 23.4612, 23.4612.let { 91.1830 }, "Junction"),
        Landmark("Mogoltoli Bazaar", 23.4635, 91.1878, "Market"),
        Landmark("Town Hall Link", 23.4580, 91.1845, "Landmark"),
        Landmark("Gomti River Link", 23.4670, 91.1890, "Riverfront"),
        Landmark("Chawkbazar Connector", 23.4660, 91.1855, "Commercial"),
        Landmark("Mogoltoli Shahi Mosque", 23.4645, 91.1840, "Mosque")
    )

    /**
     * Checks if given coordinates fall strictly within the Mogoltoli service area.
     */
    fun isWithinMogoltoli(lat: Double, lon: Double): Boolean {
        return lat in MIN_LAT..MAX_LAT && lon in MIN_LON..MAX_LON
    }

    /**
     * Clamps a coordinate point to stay within Mogoltoli boundary
     */
    fun clampToMogoltoli(lat: Double, lon: Double): Pair<Double, Double> {
        val clampedLat = lat.coerceIn(MIN_LAT + 0.0005, MAX_LAT - 0.0005)
        val clampedLon = lon.coerceIn(MIN_LON + 0.0005, MAX_LON - 0.0005)
        return Pair(clampedLat, clampedLon)
    }
}
