package com.example.data.model

data class User(
    val id: Int,
    val name: String,
    val email: String,
    val phone: String,
    val role: String, // "user" or "admin"
    val status: String = "active", // "active" or "suspended"
    val token: String = ""
) {
    val isAdmin: Boolean get() = role.equals("admin", ignoreCase = true)
}
