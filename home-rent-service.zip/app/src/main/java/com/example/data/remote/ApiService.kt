package com.example.data.remote

import com.squareup.moshi.Moshi
import com.squareup.moshi.kotlin.reflect.KotlinJsonAdapterFactory
import okhttp3.OkHttpClient
import okhttp3.logging.HttpLoggingInterceptor
import retrofit2.Response
import retrofit2.Retrofit
import retrofit2.converter.moshi.MoshiConverterFactory
import retrofit2.http.*
import java.util.concurrent.TimeUnit

data class ApiResponse<T>(
    val status: String,
    val message: String,
    val data: T? = null
)

interface ApiService {
    @POST("auth.php?action=login")
    suspend fun login(@Body body: Map<String, String>): Response<ApiResponse<Map<String, Any>>>

    @POST("auth.php?action=register")
    suspend fun register(@Body body: Map<String, String>): Response<ApiResponse<Map<String, Any>>>

    @GET("properties.php")
    suspend fun getProperties(
        @Query("category") category: String? = null,
        @Query("approval_status") status: String? = "Approved",
        @Query("availability_status") availability: String? = null,
        @Query("min_rent") minRent: Double? = null,
        @Query("max_rent") maxRent: Double? = null,
        @Query("owner_id") ownerId: Int? = null,
        @Query("search") search: String? = null
    ): Response<ApiResponse<List<Map<String, Any>>>>

    @POST("properties.php")
    suspend fun addProperty(@Body body: Map<String, Any>): Response<ApiResponse<Map<String, Any>>>

    @PUT("properties.php")
    suspend fun updateProperty(@Body body: Map<String, Any>): Response<ApiResponse<Map<String, Any>>>

    @DELETE("properties.php")
    suspend fun deleteProperty(
        @Query("id") id: Int,
        @Query("owner_id") ownerId: Int
    ): Response<ApiResponse<Map<String, Any>>>

    @GET("admin.php?action=stats")
    suspend fun getAdminStats(
        @Header("X-Admin-Id") adminId: Int
    ): Response<ApiResponse<Map<String, Any>>>

    @POST("admin.php?action=approve")
    suspend fun approveProperty(
        @Header("X-Admin-Id") adminId: Int,
        @Body body: Map<String, Any>
    ): Response<ApiResponse<Map<String, Any>>>

    @POST("admin.php?action=reject")
    suspend fun rejectProperty(
        @Header("X-Admin-Id") adminId: Int,
        @Body body: Map<String, Any>
    ): Response<ApiResponse<Map<String, Any>>>

    @POST("inquiries.php")
    suspend fun sendInquiry(@Body body: Map<String, Any>): Response<ApiResponse<Map<String, Any>>>

    @POST("favorites.php")
    suspend fun toggleFavorite(@Body body: Map<String, Any>): Response<ApiResponse<Map<String, Any>>>

    @POST("reports.php")
    suspend fun submitReport(@Body body: Map<String, Any>): Response<ApiResponse<Map<String, Any>>>
}

object ApiClient {
    // 10.0.2.2 is the Android Emulator alias to host machine localhost (e.g. XAMPP Apache)
    var currentBaseUrl: String = "http://10.0.2.2/homerent/api/"
        private set

    private val moshi = Moshi.Builder()
        .add(KotlinJsonAdapterFactory())
        .build()

    private val logging = HttpLoggingInterceptor().apply {
        level = HttpLoggingInterceptor.Level.BASIC
    }

    private val okHttpClient = OkHttpClient.Builder()
        .addInterceptor(logging)
        .connectTimeout(5, TimeUnit.SECONDS)
        .readTimeout(5, TimeUnit.SECONDS)
        .build()

    private var retrofit: Retrofit = buildRetrofit(currentBaseUrl)
    var service: ApiService = retrofit.create(ApiService::class.java)
        private set

    private fun buildRetrofit(url: String): Retrofit {
        val safeUrl = if (url.endsWith("/")) url else "$url/"
        return Retrofit.Builder()
            .baseUrl(safeUrl)
            .client(okHttpClient)
            .addConverterFactory(MoshiConverterFactory.create(moshi))
            .build()
    }

    fun updateBaseUrl(newUrl: String) {
        currentBaseUrl = newUrl
        retrofit = buildRetrofit(newUrl)
        service = retrofit.create(ApiService::class.java)
    }
}
