package com.example.data.model

enum class PropertyCategory(val id: String, val displayName: String) {
    HOUSE("house", "House Rental"),
    STORE("store", "Commercial Store"),
    CAR_PARKING("car_parking", "Car Parking");

    companion object {
        fun fromId(id: String): PropertyCategory =
            entries.find { it.id.equals(id, ignoreCase = true) } ?: HOUSE
    }
}

enum class ApprovalStatus(val label: String) {
    PENDING("Pending"),
    APPROVED("Approved"),
    REJECTED("Rejected")
}

enum class AvailabilityStatus(val label: String) {
    AVAILABLE("Available"),
    RENTED("Rented"),
    UNAVAILABLE("Unavailable")
}

data class Property(
    val id: Int,
    val ownerId: Int,
    val ownerName: String,
    val ownerPhone: String,
    val category: PropertyCategory,
    val title: String,
    val description: String,
    val rentMonthly: Double,
    val address: String,
    val latitude: Double,
    val longitude: Double,
    val approvalStatus: ApprovalStatus = ApprovalStatus.PENDING,
    val availabilityStatus: AvailabilityStatus = AvailabilityStatus.AVAILABLE,
    val rejectionReason: String? = null,
    // House attributes
    val bedrooms: Int = 0,
    val bathrooms: Int = 0,
    val houseRules: String? = null,
    // Store attributes
    val floorAreaSqft: Int = 0,
    val commercialDetails: String? = null,
    // Car parking attributes
    val vehicleType: String? = null,
    val capacity: Int = 1,
    val isCovered: Boolean = true,
    // Facilities list
    val facilities: List<String> = emptyList(),
    val imageUrls: List<String> = emptyList(),
    val createdAt: String = "Recent"
) {
    val formattedRent: String get() = "৳ ${String.format("%,.0f", rentMonthly)} / mo"
}
