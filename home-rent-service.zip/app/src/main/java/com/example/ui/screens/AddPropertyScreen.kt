package com.example.ui.screens

import androidx.activity.compose.BackHandler
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.layout.ExperimentalLayoutApi
import androidx.compose.foundation.layout.FlowRow
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.model.PropertyCategory
import com.example.data.util.MogoltoliGeofence
import com.example.ui.components.MogoltoliInteractiveMap
import com.example.ui.theme.*
import com.example.ui.viewmodel.MainViewModel
import com.example.ui.viewmodel.Screen

@OptIn(ExperimentalMaterial3Api::class, ExperimentalLayoutApi::class)
@Composable
fun AddPropertyScreen(
    viewModel: MainViewModel,
    modifier: Modifier = Modifier
) {
    BackHandler {
        viewModel.navigateBack()
    }

    var selectedCategory by remember { mutableStateOf(PropertyCategory.HOUSE) }
    var title by remember { mutableStateOf("") }
    var description by remember { mutableStateOf("") }
    var rentMonthlyStr by remember { mutableStateOf("") }
    var address by remember { mutableStateOf("Mogoltoli Road, Cumilla") }

    // Map Picker Coordinates (Default centered inside Mogoltoli)
    var pickedLat by remember { mutableDoubleStateOf(MogoltoliGeofence.CENTER_LAT) }
    var pickedLon by remember { mutableDoubleStateOf(MogoltoliGeofence.CENTER_LON) }

    // House Specific
    var bedroomsStr by remember { mutableStateOf("2") }
    var bathroomsStr by remember { mutableStateOf("2") }
    var houseRules by remember { mutableStateOf("Family only, no loud music after 10 PM") }

    // Store Specific
    var floorAreaStr by remember { mutableStateOf("350") }
    var commercialDetails by remember { mutableStateOf("Suitable for pharmacy, general store, or agency office") }

    // Car Parking Specific
    var vehicleType by remember { mutableStateOf("Sedan / SUV / Private Car") }
    var capacityStr by remember { mutableStateOf("1") }
    var isCovered by remember { mutableStateOf(true) }

    // Facilities
    val allFacilityOptions = listOf(
        "Lift", "Generator Backup", "Gas Line", "24/7 Security",
        "CCTV", "Balcony", "Water Supply", "Rolling Shutter",
        "Commercial Meter", "Prepaid Electric Meter", "Covered Roof"
    )
    var selectedFacilities by remember { mutableStateOf(setOf("Water Supply", "24/7 Security")) }

    var errorMessage by remember { mutableStateOf<String?>(null) }
    var isSubmitting by remember { mutableStateOf(false) }

    val isLocationValid = MogoltoliGeofence.isWithinMogoltoli(pickedLat, pickedLon)

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text("Add Rental Listing", fontWeight = FontWeight.Bold, fontSize = 18.sp) },
                navigationIcon = {
                    IconButton(onClick = { viewModel.navigateBack() }) {
                        Icon(Icons.Default.ArrowBack, contentDescription = "Back")
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(containerColor = MaterialTheme.colorScheme.surface)
            )
        }
    ) { innerPadding ->
        Column(
            modifier = modifier
                .fillMaxSize()
                .padding(innerPadding)
                .background(MaterialTheme.colorScheme.background)
                .verticalScroll(rememberScrollState())
                .padding(20.dp)
        ) {
            // Notice about initial status
            Surface(
                color = StatusPendingAmber.copy(alpha = 0.15f),
                shape = RoundedCornerShape(12.dp),
                modifier = Modifier.fillMaxWidth()
            ) {
                Row(
                    modifier = Modifier.padding(12.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Icon(Icons.Default.Info, contentDescription = null, tint = StatusPendingAmber)
                    Spacer(modifier = Modifier.width(10.dp))
                    Text(
                        "New submissions are saved with Pending status and become visible publicly once reviewed and approved by the admin.",
                        fontSize = 12.sp,
                        color = NeutralDark
                    )
                }
            }

            Spacer(modifier = Modifier.height(16.dp))

            // 1. Select Category
            Text("1. Select Property Category", fontWeight = FontWeight.Bold, fontSize = 15.sp)
            Spacer(modifier = Modifier.height(8.dp))
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                PropertyCategory.entries.forEach { cat ->
                    val isSelected = selectedCategory == cat
                    Surface(
                        modifier = Modifier
                            .weight(1f)
                            .clip(RoundedCornerShape(12.dp))
                            .border(
                                width = if (isSelected) 2.dp else 1.dp,
                                color = if (isSelected) BrandTealDark else SurfaceBorderLight,
                                shape = RoundedCornerShape(12.dp)
                            ),
                        color = if (isSelected) BrandMintLight else MaterialTheme.colorScheme.surface,
                        onClick = { selectedCategory = cat }
                    ) {
                        Column(
                            modifier = Modifier.padding(10.dp),
                            horizontalAlignment = Alignment.CenterHorizontally
                        ) {
                            Icon(
                                imageVector = when (cat) {
                                    PropertyCategory.HOUSE -> Icons.Default.Home
                                    PropertyCategory.STORE -> Icons.Default.Storefront
                                    PropertyCategory.CAR_PARKING -> Icons.Default.DirectionsCar
                                },
                                contentDescription = null,
                                tint = if (isSelected) BrandTealDark else NeutralMedium,
                                modifier = Modifier.size(24.dp)
                            )
                            Spacer(modifier = Modifier.height(4.dp))
                            Text(
                                text = cat.displayName,
                                fontSize = 11.sp,
                                fontWeight = FontWeight.Bold,
                                color = if (isSelected) BrandTealDark else NeutralDark
                            )
                        }
                    }
                }
            }

            Spacer(modifier = Modifier.height(20.dp))

            // 2. Core Details
            Text("2. Basic Information", fontWeight = FontWeight.Bold, fontSize = 15.sp)
            Spacer(modifier = Modifier.height(8.dp))

            OutlinedTextField(
                value = title,
                onValueChange = { title = it },
                label = { Text("Listing Title") },
                placeholder = { Text("e.g. Spacious 3-BHK Flat near Rajganj") },
                modifier = Modifier.fillMaxWidth().testTag("add_property_title_input"),
                singleLine = true
            )

            Spacer(modifier = Modifier.height(12.dp))

            OutlinedTextField(
                value = rentMonthlyStr,
                onValueChange = { rentMonthlyStr = it },
                label = { Text("Monthly Rent in Bangladeshi Taka (৳)") },
                placeholder = { Text("e.g. 15000") },
                keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                modifier = Modifier.fillMaxWidth().testTag("add_property_rent_input"),
                singleLine = true
            )

            Spacer(modifier = Modifier.height(12.dp))

            OutlinedTextField(
                value = address,
                onValueChange = { address = it },
                label = { Text("Street Address in Mogoltoli") },
                placeholder = { Text("e.g. Holding #14, Lane 2, Mogoltoli, Cumilla") },
                modifier = Modifier.fillMaxWidth().testTag("add_property_address_input"),
                singleLine = true
            )

            Spacer(modifier = Modifier.height(12.dp))

            OutlinedTextField(
                value = description,
                onValueChange = { description = it },
                label = { Text("Detailed Description") },
                modifier = Modifier
                    .fillMaxWidth()
                    .height(100.dp)
                    .testTag("add_property_desc_input")
            )

            Spacer(modifier = Modifier.height(20.dp))

            // 3. Category Specific Attributes
            Text("3. Category Details", fontWeight = FontWeight.Bold, fontSize = 15.sp)
            Spacer(modifier = Modifier.height(8.dp))

            when (selectedCategory) {
                PropertyCategory.HOUSE -> {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(10.dp)
                    ) {
                        OutlinedTextField(
                            value = bedroomsStr,
                            onValueChange = { bedroomsStr = it },
                            label = { Text("Bedrooms") },
                            keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                            modifier = Modifier.weight(1f)
                        )
                        OutlinedTextField(
                            value = bathroomsStr,
                            onValueChange = { bathroomsStr = it },
                            label = { Text("Bathrooms") },
                            keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                            modifier = Modifier.weight(1f)
                        )
                    }
                    Spacer(modifier = Modifier.height(10.dp))
                    OutlinedTextField(
                        value = houseRules,
                        onValueChange = { houseRules = it },
                        label = { Text("House Rules") },
                        modifier = Modifier.fillMaxWidth()
                    )
                }
                PropertyCategory.STORE -> {
                    OutlinedTextField(
                        value = floorAreaStr,
                        onValueChange = { floorAreaStr = it },
                        label = { Text("Floor Area (Square Feet)") },
                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                        modifier = Modifier.fillMaxWidth()
                    )
                    Spacer(modifier = Modifier.height(10.dp))
                    OutlinedTextField(
                        value = commercialDetails,
                        onValueChange = { commercialDetails = it },
                        label = { Text("Commercial Use & Terms") },
                        modifier = Modifier.fillMaxWidth()
                    )
                }
                PropertyCategory.CAR_PARKING -> {
                    OutlinedTextField(
                        value = vehicleType,
                        onValueChange = { vehicleType = it },
                        label = { Text("Supported Vehicle Type") },
                        modifier = Modifier.fillMaxWidth()
                    )
                    Spacer(modifier = Modifier.height(10.dp))
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(10.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        OutlinedTextField(
                            value = capacityStr,
                            onValueChange = { capacityStr = it },
                            label = { Text("Vehicle Capacity") },
                            keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                            modifier = Modifier.weight(1f)
                        )
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            modifier = Modifier.weight(1f)
                        ) {
                            Checkbox(checked = isCovered, onCheckedChange = { isCovered = it })
                            Text("Covered Roof", fontSize = 13.sp)
                        }
                    }
                }
            }

            Spacer(modifier = Modifier.height(20.dp))

            // 4. Facilities Selector
            Text("4. Facilities & Amenities", fontWeight = FontWeight.Bold, fontSize = 15.sp)
            Spacer(modifier = Modifier.height(8.dp))
            FlowRow(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(6.dp),
                verticalArrangement = Arrangement.spacedBy(6.dp)
            ) {
                allFacilityOptions.forEach { facility ->
                    val checked = selectedFacilities.contains(facility)
                    FilterChip(
                        selected = checked,
                        onClick = {
                            selectedFacilities = if (checked) selectedFacilities - facility else selectedFacilities + facility
                        },
                        label = { Text(facility, fontSize = 11.sp) }
                    )
                }
            }

            Spacer(modifier = Modifier.height(20.dp))

            // 5. Interactive Location Picker with Geofence Validation
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text("5. Pin Location on Mogoltoli Map", fontWeight = FontWeight.Bold, fontSize = 15.sp)
                Text("Tap map to position pin", fontSize = 11.sp, color = NeutralMedium)
            }
            Spacer(modifier = Modifier.height(8.dp))

            Card(
                modifier = Modifier
                    .fillMaxWidth()
                    .height(240.dp),
                shape = RoundedCornerShape(14.dp)
            ) {
                MogoltoliInteractiveMap(
                    isPickerMode = true,
                    pickedLocation = Pair(pickedLat, pickedLon),
                    onLocationPicked = { lat, lon ->
                        pickedLat = lat
                        pickedLon = lon
                    },
                    modifier = Modifier.fillMaxSize()
                )
            }

            Spacer(modifier = Modifier.height(8.dp))

            // Live Geofence Validation Banner
            Surface(
                shape = RoundedCornerShape(10.dp),
                color = if (isLocationValid) StatusApprovedGreen.copy(alpha = 0.15f) else StatusRejectedRed.copy(alpha = 0.15f),
                modifier = Modifier.fillMaxWidth()
            ) {
                Row(
                    modifier = Modifier.padding(10.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Icon(
                        imageVector = if (isLocationValid) Icons.Default.CheckCircle else Icons.Default.Error,
                        contentDescription = null,
                        tint = if (isLocationValid) StatusApprovedGreen else StatusRejectedRed,
                        modifier = Modifier.size(18.dp)
                    )
                    Spacer(modifier = Modifier.width(8.dp))
                    Column {
                        Text(
                            text = if (isLocationValid) "Location Verified: Inside Mogoltoli Service Area" else "Location Outside Allowed Mogoltoli Boundary!",
                            fontWeight = FontWeight.Bold,
                            fontSize = 12.sp,
                            color = if (isLocationValid) StatusApprovedGreen else StatusRejectedRed
                        )
                        Text(
                            text = "Lat: ${String.format("%.4f", pickedLat)}° N, Lon: ${String.format("%.4f", pickedLon)}° E",
                            fontSize = 11.sp,
                            color = NeutralDark
                        )
                    }
                }
            }

            errorMessage?.let {
                Spacer(modifier = Modifier.height(12.dp))
                Text(it, color = MaterialTheme.colorScheme.error, fontSize = 12.sp)
            }

            Spacer(modifier = Modifier.height(24.dp))

            // Submit Button
            Button(
                onClick = {
                    val rent = rentMonthlyStr.toDoubleOrNull() ?: 0.0
                    if (title.isBlank() || description.isBlank() || rent <= 0.0) {
                        errorMessage = "Please fill in title, description, and valid rent"
                        return@Button
                    }
                    if (!isLocationValid) {
                        errorMessage = "Location must be within Mogoltoli, Cumilla service boundary"
                        return@Button
                    }

                    isSubmitting = true
                    errorMessage = null

                    viewModel.addProperty(
                        category = selectedCategory,
                        title = title,
                        description = description,
                        rentMonthly = rent,
                        address = address,
                        latitude = pickedLat,
                        longitude = pickedLon,
                        bedrooms = bedroomsStr.toIntOrNull() ?: 0,
                        bathrooms = bathroomsStr.toIntOrNull() ?: 0,
                        floorAreaSqft = floorAreaStr.toIntOrNull() ?: 0,
                        vehicleType = vehicleType,
                        capacity = capacityStr.toIntOrNull() ?: 1,
                        isCovered = isCovered,
                        houseRules = houseRules,
                        commercialDetails = commercialDetails,
                        facilities = selectedFacilities.toList(),
                        onSuccess = {
                            isSubmitting = false
                            viewModel.navigateTo(Screen.MY_LISTINGS)
                        },
                        onError = { err ->
                            isSubmitting = false
                            errorMessage = err
                        }
                    )
                },
                enabled = !isSubmitting,
                modifier = Modifier
                    .fillMaxWidth()
                    .height(50.dp)
                    .testTag("submit_rental_button"),
                shape = RoundedCornerShape(12.dp),
                colors = ButtonDefaults.buttonColors(containerColor = BrandMint)
            ) {
                if (isSubmitting) {
                    CircularProgressIndicator(modifier = Modifier.size(24.dp), color = NeutralDark)
                } else {
                    Text(
                        "Submit Rental (Initial Status: Pending)",
                        color = NeutralDark,
                        fontWeight = FontWeight.Bold,
                        fontSize = 14.sp
                    )
                }
            }
            Spacer(modifier = Modifier.height(30.dp))
        }
    }
}
