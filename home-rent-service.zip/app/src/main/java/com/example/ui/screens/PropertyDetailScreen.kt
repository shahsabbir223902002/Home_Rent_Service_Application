package com.example.ui.screens

import android.content.Intent
import android.net.Uri
import androidx.activity.compose.BackHandler
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.layout.ExperimentalLayoutApi
import androidx.compose.foundation.layout.FlowRow
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material.icons.outlined.FavoriteBorder
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import coil.compose.AsyncImage
import com.example.data.model.ApprovalStatus
import com.example.data.model.PropertyCategory
import com.example.ui.components.MogoltoliInteractiveMap
import com.example.ui.theme.*
import com.example.ui.viewmodel.MainViewModel

@OptIn(ExperimentalMaterial3Api::class, ExperimentalLayoutApi::class)
@Composable
fun PropertyDetailScreen(
    viewModel: MainViewModel,
    modifier: Modifier = Modifier
) {
    BackHandler {
        viewModel.navigateBack()
    }

    val context = LocalContext.current
    val property by viewModel.selectedProperty.collectAsState()
    val favorites by viewModel.favorites.collectAsState()
    val currentUser by viewModel.currentUser.collectAsState()

    var showInquiryDialog by remember { mutableStateOf(false) }
    var inquiryMessage by remember { mutableStateOf("Hello, I am interested in this rental property in Mogoltoli. Is it currently available for viewing?") }

    var showReportDialog by remember { mutableStateOf(false) }
    var reportReason by remember { mutableStateOf("Incorrect pricing / terms") }
    var reportDetails by remember { mutableStateOf("") }

    if (property == null) {
        Box(modifier = Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
            Text("Property not found")
        }
        return
    }

    val prop = property!!
    val isFav = favorites.contains(prop.id)
    val isOwner = currentUser?.id == prop.ownerId

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text("Rental Details", fontSize = 18.sp, fontWeight = FontWeight.Bold) },
                navigationIcon = {
                    IconButton(onClick = { viewModel.navigateBack() }) {
                        Icon(Icons.Default.ArrowBack, contentDescription = "Back")
                    }
                },
                actions = {
                    IconButton(
                        onClick = { viewModel.toggleFavorite(prop.id) },
                        modifier = Modifier.testTag("detail_favorite_button")
                    ) {
                        Icon(
                            imageVector = if (isFav) Icons.Default.Favorite else Icons.Outlined.FavoriteBorder,
                            contentDescription = "Favorite",
                            tint = if (isFav) AccentCoral else MaterialTheme.colorScheme.onSurface
                        )
                    }
                    IconButton(
                        onClick = { showReportDialog = true },
                        modifier = Modifier.testTag("detail_report_button")
                    ) {
                        Icon(Icons.Default.Flag, contentDescription = "Report Listing", tint = NeutralMedium)
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(containerColor = MaterialTheme.colorScheme.surface)
            )
        },
        bottomBar = {
            Surface(
                modifier = Modifier.fillMaxWidth(),
                shadowElevation = 8.dp,
                color = MaterialTheme.colorScheme.surface
            ) {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(16.dp),
                    horizontalArrangement = Arrangement.spacedBy(12.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column(modifier = Modifier.weight(1f)) {
                        Text("Monthly Rent", fontSize = 11.sp, color = NeutralMedium)
                        Text(
                            text = prop.formattedRent,
                            fontSize = 18.sp,
                            fontWeight = FontWeight.ExtraBold,
                            color = BrandTealDark
                        )
                    }

                    OutlinedButton(
                        onClick = {
                            val intent = Intent(Intent.ACTION_DIAL).apply {
                                data = Uri.parse("tel:${prop.ownerPhone}")
                            }
                            context.startActivity(intent)
                        },
                        shape = RoundedCornerShape(12.dp),
                        modifier = Modifier
                            .height(48.dp)
                            .testTag("call_owner_button")
                    ) {
                        Icon(Icons.Default.Phone, contentDescription = null, modifier = Modifier.size(18.dp))
                        Spacer(modifier = Modifier.width(6.dp))
                        Text("Call Owner")
                    }

                    Button(
                        onClick = { showInquiryDialog = true },
                        shape = RoundedCornerShape(12.dp),
                        colors = ButtonDefaults.buttonColors(containerColor = BrandMint),
                        modifier = Modifier
                            .height(48.dp)
                            .testTag("send_inquiry_button")
                    ) {
                        Icon(Icons.Default.Chat, contentDescription = null, tint = NeutralDark, modifier = Modifier.size(18.dp))
                        Spacer(modifier = Modifier.width(6.dp))
                        Text("Inquire", color = NeutralDark, fontWeight = FontWeight.Bold)
                    }
                }
            }
        }
    ) { innerPadding ->
        Column(
            modifier = modifier
                .fillMaxSize()
                .padding(innerPadding)
                .verticalScroll(rememberScrollState())
                .background(MaterialTheme.colorScheme.background)
        ) {
            // Main Property Image
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .height(240.dp)
            ) {
                AsyncImage(
                    model = prop.imageUrls.firstOrNull() ?: "",
                    contentDescription = prop.title,
                    modifier = Modifier
                        .fillMaxSize()
                        .background(NeutralLight.copy(alpha = 0.2f)),
                    contentScale = ContentScale.Crop
                )

                Surface(
                    shape = RoundedCornerShape(8.dp),
                    color = when (prop.category) {
                        PropertyCategory.HOUSE -> CategoryHouseColor
                        PropertyCategory.STORE -> CategoryStoreColor
                        PropertyCategory.CAR_PARKING -> CategoryParkingColor
                    },
                    modifier = Modifier
                        .padding(16.dp)
                        .align(Alignment.TopStart)
                ) {
                    Text(
                        text = prop.category.displayName,
                        color = Color.White,
                        fontSize = 12.sp,
                        fontWeight = FontWeight.Bold,
                        modifier = Modifier.padding(horizontal = 10.dp, vertical = 6.dp)
                    )
                }

                Surface(
                    shape = RoundedCornerShape(8.dp),
                    color = when (prop.approvalStatus) {
                        ApprovalStatus.APPROVED -> StatusApprovedGreen
                        ApprovalStatus.PENDING -> StatusPendingAmber
                        ApprovalStatus.REJECTED -> StatusRejectedRed
                    },
                    modifier = Modifier
                        .padding(16.dp)
                        .align(Alignment.TopEnd)
                ) {
                    Text(
                        text = prop.approvalStatus.label,
                        color = Color.White,
                        fontSize = 12.sp,
                        fontWeight = FontWeight.Bold,
                        modifier = Modifier.padding(horizontal = 10.dp, vertical = 6.dp)
                    )
                }
            }

            // Body Details
            Column(modifier = Modifier.padding(20.dp)) {
                Text(
                    text = prop.title,
                    fontSize = 20.sp,
                    fontWeight = FontWeight.Bold,
                    color = MaterialTheme.colorScheme.onSurface
                )

                Spacer(modifier = Modifier.height(8.dp))

                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(Icons.Default.LocationOn, contentDescription = null, tint = BrandMint, modifier = Modifier.size(18.dp))
                    Spacer(modifier = Modifier.width(6.dp))
                    Text(
                        text = prop.address,
                        fontSize = 13.sp,
                        color = NeutralMedium,
                        fontWeight = FontWeight.Medium
                    )
                }

                Spacer(modifier = Modifier.height(16.dp))

                // Category Specific Attribute Chips
                Card(
                    shape = RoundedCornerShape(12.dp),
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(14.dp),
                        horizontalArrangement = Arrangement.SpaceAround
                    ) {
                        when (prop.category) {
                            PropertyCategory.HOUSE -> {
                                DetailSpecItem(Icons.Default.Bed, "${prop.bedrooms} Bedrooms")
                                DetailSpecItem(Icons.Default.Bathtub, "${prop.bathrooms} Bathrooms")
                                if (prop.floorAreaSqft > 0) {
                                    DetailSpecItem(Icons.Default.SquareFoot, "${prop.floorAreaSqft} sqft")
                                }
                            }
                            PropertyCategory.STORE -> {
                                DetailSpecItem(Icons.Default.SquareFoot, "${prop.floorAreaSqft} sqft Area")
                                DetailSpecItem(Icons.Default.Storefront, "Commercial Shop")
                                DetailSpecItem(Icons.Default.ElectricalServices, "Commercial Meter")
                            }
                            PropertyCategory.CAR_PARKING -> {
                                DetailSpecItem(Icons.Default.DirectionsCar, prop.vehicleType ?: "Any Vehicle")
                                DetailSpecItem(Icons.Default.Shield, if (prop.isCovered) "Covered Garage" else "Open Slot")
                                DetailSpecItem(Icons.Default.PinDrop, "Capacity: ${prop.capacity}")
                            }
                        }
                    }
                }

                Spacer(modifier = Modifier.height(20.dp))

                // Description
                Text("Description", fontWeight = FontWeight.Bold, fontSize = 16.sp)
                Spacer(modifier = Modifier.height(8.dp))
                Text(
                    text = prop.description,
                    fontSize = 14.sp,
                    color = NeutralDark,
                    lineHeight = 20.sp
                )

                // House rules / Commercial details if present
                if (!prop.houseRules.isNullOrBlank()) {
                    Spacer(modifier = Modifier.height(12.dp))
                    Surface(
                        color = NeutralLight.copy(alpha = 0.15f),
                        shape = RoundedCornerShape(8.dp),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Column(modifier = Modifier.padding(10.dp)) {
                            Text("House Rules:", fontWeight = FontWeight.Bold, fontSize = 12.sp, color = NeutralDark)
                            Text(prop.houseRules, fontSize = 12.sp, color = NeutralMedium)
                        }
                    }
                }

                if (!prop.commercialDetails.isNullOrBlank()) {
                    Spacer(modifier = Modifier.height(12.dp))
                    Surface(
                        color = NeutralLight.copy(alpha = 0.15f),
                        shape = RoundedCornerShape(8.dp),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Column(modifier = Modifier.padding(10.dp)) {
                            Text("Commercial Terms:", fontWeight = FontWeight.Bold, fontSize = 12.sp, color = NeutralDark)
                            Text(prop.commercialDetails, fontSize = 12.sp, color = NeutralMedium)
                        }
                    }
                }

                Spacer(modifier = Modifier.height(20.dp))

                // Facilities List
                if (prop.facilities.isNotEmpty()) {
                    Text("Facilities & Features", fontWeight = FontWeight.Bold, fontSize = 16.sp)
                    Spacer(modifier = Modifier.height(10.dp))
                    FlowRow(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(8.dp),
                        verticalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        prop.facilities.forEach { facility ->
                            Surface(
                                shape = RoundedCornerShape(8.dp),
                                color = BrandMintLight.copy(alpha = 0.6f),
                                border = CardDefaults.outlinedCardBorder()
                            ) {
                                Row(
                                    modifier = Modifier.padding(horizontal = 10.dp, vertical = 6.dp),
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    Icon(Icons.Default.Check, contentDescription = null, tint = BrandTealDark, modifier = Modifier.size(14.dp))
                                    Spacer(modifier = Modifier.width(6.dp))
                                    Text(facility, fontSize = 12.sp, fontWeight = FontWeight.SemiBold, color = BrandTealDark)
                                }
                            }
                        }
                    }
                    Spacer(modifier = Modifier.height(20.dp))
                }

                // Mogoltoli Map Location Preview
                Text("Location in Mogoltoli", fontWeight = FontWeight.Bold, fontSize = 16.sp)
                Spacer(modifier = Modifier.height(8.dp))
                Card(
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(180.dp),
                    shape = RoundedCornerShape(14.dp)
                ) {
                    MogoltoliInteractiveMap(
                        properties = listOf(prop),
                        selectedProperty = prop,
                        modifier = Modifier.fillMaxSize()
                    )
                }
                Spacer(modifier = Modifier.height(6.dp))
                Text(
                    text = "Coordinates: ${String.format("%.4f", prop.latitude)}° N, ${String.format("%.4f", prop.longitude)}° E (Verified Mogoltoli Area)",
                    fontSize = 11.sp,
                    color = NeutralMedium
                )

                Spacer(modifier = Modifier.height(20.dp))

                // Owner Info Card
                Text("Listed By", fontWeight = FontWeight.Bold, fontSize = 16.sp)
                Spacer(modifier = Modifier.height(8.dp))
                Card(
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(12.dp),
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)
                ) {
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(14.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Box(
                            modifier = Modifier
                                .size(44.dp)
                                .background(BrandTealDark, CircleShape),
                            contentAlignment = Alignment.Center
                        ) {
                            Text(
                                text = prop.ownerName.take(1).uppercase(),
                                color = Color.White,
                                fontWeight = FontWeight.Bold,
                                fontSize = 18.sp
                            )
                        }
                        Spacer(modifier = Modifier.width(12.dp))
                        Column(modifier = Modifier.weight(1f)) {
                            Text(prop.ownerName, fontWeight = FontWeight.Bold, fontSize = 14.sp)
                            Text(prop.ownerPhone, fontSize = 12.sp, color = NeutralMedium)
                        }
                        Surface(
                            shape = RoundedCornerShape(6.dp),
                            color = BrandMint.copy(alpha = 0.2f)
                        ) {
                            Text(
                                "Verified Owner",
                                color = BrandTealDark,
                                fontSize = 10.sp,
                                fontWeight = FontWeight.Bold,
                                modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
                            )
                        }
                    }
                }

                Spacer(modifier = Modifier.height(40.dp))
            }
        }
    }

    // Send Inquiry Modal Dialog
    if (showInquiryDialog) {
        AlertDialog(
            onDismissRequest = { showInquiryDialog = false },
            title = { Text("Contact Property Owner", fontWeight = FontWeight.Bold) },
            text = {
                Column {
                    Text(
                        "Send a message directly to ${prop.ownerName} regarding \"${prop.title}\".",
                        fontSize = 12.sp,
                        color = NeutralMedium
                    )
                    Spacer(modifier = Modifier.height(12.dp))
                    OutlinedTextField(
                        value = inquiryMessage,
                        onValueChange = { inquiryMessage = it },
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(120.dp)
                            .testTag("inquiry_message_input"),
                        label = { Text("Your Message") }
                    )
                }
            },
            confirmButton = {
                Button(
                    onClick = {
                        viewModel.submitInquiry(prop.id, prop.title, inquiryMessage) {
                            showInquiryDialog = false
                        }
                    },
                    modifier = Modifier.testTag("inquiry_submit_confirm")
                ) {
                    Text("Send Message")
                }
            },
            dismissButton = {
                TextButton(onClick = { showInquiryDialog = false }) {
                    Text("Cancel")
                }
            }
        )
    }

    // Report Listing Modal Dialog
    if (showReportDialog) {
        AlertDialog(
            onDismissRequest = { showReportDialog = false },
            title = { Text("Report Listing", fontWeight = FontWeight.Bold) },
            text = {
                Column {
                    Text(
                        "Help us maintain trustworthy listings in Mogoltoli by reporting suspicious or inaccurate information.",
                        fontSize = 12.sp,
                        color = NeutralMedium
                    )
                    Spacer(modifier = Modifier.height(12.dp))
                    Text("Reason for report:", fontWeight = FontWeight.SemiBold, fontSize = 12.sp)
                    Spacer(modifier = Modifier.height(6.dp))

                    val reasons = listOf("Incorrect pricing / terms", "Property does not exist / scam", "Inappropriate content", "Outside Mogoltoli")
                    reasons.forEach { r ->
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            RadioButton(selected = reportReason == r, onClick = { reportReason = r })
                            Text(r, fontSize = 13.sp)
                        }
                    }

                    Spacer(modifier = Modifier.height(8.dp))
                    OutlinedTextField(
                        value = reportDetails,
                        onValueChange = { reportDetails = it },
                        modifier = Modifier.fillMaxWidth(),
                        label = { Text("Additional details") },
                        placeholder = { Text("Provide details for admin investigation...") }
                    )
                }
            },
            confirmButton = {
                Button(
                    onClick = {
                        viewModel.submitReport(prop.id, prop.title, reportReason, reportDetails) {
                            showReportDialog = false
                        }
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = StatusRejectedRed)
                ) {
                    Text("Submit Report")
                }
            },
            dismissButton = {
                TextButton(onClick = { showReportDialog = false }) {
                    Text("Cancel")
                }
            }
        )
    }
}

@Composable
fun DetailSpecItem(icon: androidx.compose.ui.graphics.vector.ImageVector, text: String) {
    Column(horizontalAlignment = Alignment.CenterHorizontally) {
        Icon(icon, contentDescription = null, tint = BrandTealDark, modifier = Modifier.size(22.dp))
        Spacer(modifier = Modifier.height(4.dp))
        Text(text, fontSize = 12.sp, fontWeight = FontWeight.SemiBold, color = NeutralDark)
    }
}
