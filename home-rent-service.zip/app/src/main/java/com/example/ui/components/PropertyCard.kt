package com.example.ui.components

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material.icons.outlined.FavoriteBorder
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import coil.compose.AsyncImage
import com.example.data.model.ApprovalStatus
import com.example.data.model.AvailabilityStatus
import com.example.data.model.Property
import com.example.data.model.PropertyCategory
import com.example.ui.theme.*

@Composable
fun PropertyCard(
    property: Property,
    isFavorite: Boolean = false,
    onFavoriteToggle: () -> Unit = {},
    onClick: () -> Unit = {},
    showAdminControls: Boolean = false,
    showOwnerControls: Boolean = false,
    onApprove: () -> Unit = {},
    onReject: () -> Unit = {},
    onDelete: () -> Unit = {},
    onEdit: () -> Unit = {},
    modifier: Modifier = Modifier
) {
    Card(
        modifier = modifier
            .fillMaxWidth()
            .clickable(onClick = onClick)
            .testTag("property_card_${property.id}"),
        shape = RoundedCornerShape(16.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
        elevation = CardDefaults.cardElevation(defaultElevation = 2.dp)
    ) {
        Column {
            // Image with Category & Status Badges
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .height(180.dp)
            ) {
                AsyncImage(
                    model = property.imageUrls.firstOrNull() ?: "",
                    contentDescription = property.title,
                    modifier = Modifier
                        .fillMaxSize()
                        .background(NeutralLight.copy(alpha = 0.2f)),
                    contentScale = ContentScale.Crop
                )

                // Top Left: Category Badge
                Surface(
                    shape = RoundedCornerShape(8.dp),
                    color = when (property.category) {
                        PropertyCategory.HOUSE -> CategoryHouseColor
                        PropertyCategory.STORE -> CategoryStoreColor
                        PropertyCategory.CAR_PARKING -> CategoryParkingColor
                    },
                    modifier = Modifier
                        .padding(12.dp)
                        .align(Alignment.TopStart)
                ) {
                    Text(
                        text = property.category.displayName,
                        color = Color.White,
                        fontSize = 12.sp,
                        fontWeight = FontWeight.Bold,
                        modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp)
                    )
                }

                // Top Right: Favorite or Status Badge
                Row(
                    modifier = Modifier
                        .padding(12.dp)
                        .align(Alignment.TopEnd),
                    horizontalArrangement = Arrangement.spacedBy(6.dp)
                ) {
                    // Approval Status if not just approved
                    if (property.approvalStatus != ApprovalStatus.APPROVED || showAdminControls || showOwnerControls) {
                        Surface(
                            shape = RoundedCornerShape(8.dp),
                            color = when (property.approvalStatus) {
                                ApprovalStatus.APPROVED -> StatusApprovedGreen
                                ApprovalStatus.PENDING -> StatusPendingAmber
                                ApprovalStatus.REJECTED -> StatusRejectedRed
                            }
                        ) {
                            Text(
                                text = property.approvalStatus.label,
                                color = Color.White,
                                fontSize = 11.sp,
                                fontWeight = FontWeight.Bold,
                                modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp)
                            )
                        }
                    }

                    // Favorite Button (for users)
                    if (!showAdminControls) {
                        IconButton(
                            onClick = onFavoriteToggle,
                            modifier = Modifier
                                .size(36.dp)
                                .background(Color.Black.copy(alpha = 0.45f), CircleShape)
                                .testTag("favorite_button_${property.id}")
                        ) {
                            Icon(
                                imageVector = if (isFavorite) Icons.Default.Favorite else Icons.Outlined.FavoriteBorder,
                                contentDescription = "Favorite",
                                tint = if (isFavorite) AccentCoral else Color.White,
                                modifier = Modifier.size(20.dp)
                            )
                        }
                    }
                }

                // Bottom Left on Image: Rent Badge
                Surface(
                    shape = RoundedCornerShape(topEnd = 12.dp),
                    color = BrandTealDark.copy(alpha = 0.92f),
                    modifier = Modifier.align(Alignment.BottomStart)
                ) {
                    Text(
                        text = property.formattedRent,
                        color = Color.White,
                        fontSize = 15.sp,
                        fontWeight = FontWeight.ExtraBold,
                        modifier = Modifier.padding(horizontal = 12.dp, vertical = 6.dp)
                    )
                }
            }

            // Card Body
            Column(modifier = Modifier.padding(14.dp)) {
                Text(
                    text = property.title,
                    fontSize = 16.sp,
                    fontWeight = FontWeight.Bold,
                    color = MaterialTheme.colorScheme.onSurface,
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis
                )

                Spacer(modifier = Modifier.height(4.dp))

                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(
                        imageVector = Icons.Default.LocationOn,
                        contentDescription = null,
                        tint = BrandMint,
                        modifier = Modifier.size(14.dp)
                    )
                    Spacer(modifier = Modifier.width(4.dp))
                    Text(
                        text = property.address,
                        fontSize = 12.sp,
                        color = NeutralMedium,
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis
                    )
                }

                Spacer(modifier = Modifier.height(8.dp))

                // Key Specs Row
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(8.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    when (property.category) {
                        PropertyCategory.HOUSE -> {
                            SpecBadge(icon = Icons.Default.Bed, text = "${property.bedrooms} Beds")
                            SpecBadge(icon = Icons.Default.Bathtub, text = "${property.bathrooms} Baths")
                            if (property.floorAreaSqft > 0) {
                                SpecBadge(icon = Icons.Default.SquareFoot, text = "${property.floorAreaSqft} sqft")
                            }
                        }
                        PropertyCategory.STORE -> {
                            SpecBadge(icon = Icons.Default.Storefront, text = "${property.floorAreaSqft} sqft Area")
                            SpecBadge(icon = Icons.Default.Verified, text = "Commercial")
                        }
                        PropertyCategory.CAR_PARKING -> {
                            SpecBadge(icon = Icons.Default.DirectionsCar, text = property.vehicleType ?: "Vehicle")
                            SpecBadge(icon = Icons.Default.Shield, text = if (property.isCovered) "Covered" else "Open")
                        }
                    }
                }

                // Rejection Reason Notice (if rejected)
                if (property.approvalStatus == ApprovalStatus.REJECTED && !property.rejectionReason.isNullOrBlank()) {
                    Spacer(modifier = Modifier.height(8.dp))
                    Surface(
                        color = StatusRejectedRed.copy(alpha = 0.1f),
                        shape = RoundedCornerShape(8.dp),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Text(
                            text = "Admin Note: ${property.rejectionReason}",
                            color = StatusRejectedRed,
                            fontSize = 12.sp,
                            modifier = Modifier.padding(8.dp)
                        )
                    }
                }

                // Admin Action Buttons
                if (showAdminControls) {
                    Spacer(modifier = Modifier.height(10.dp))
                    HorizontalDivider(color = NeutralLight.copy(alpha = 0.3f))
                    Spacer(modifier = Modifier.height(8.dp))

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        if (property.approvalStatus == ApprovalStatus.PENDING) {
                            Button(
                                onClick = onApprove,
                                modifier = Modifier.weight(1f).height(38.dp),
                                colors = ButtonDefaults.buttonColors(containerColor = StatusApprovedGreen),
                                shape = RoundedCornerShape(8.dp)
                            ) {
                                Icon(Icons.Default.Check, contentDescription = null, modifier = Modifier.size(16.dp))
                                Spacer(modifier = Modifier.width(4.dp))
                                Text("Approve", fontSize = 12.sp)
                            }
                            OutlinedButton(
                                onClick = onReject,
                                modifier = Modifier.weight(1f).height(38.dp),
                                colors = ButtonDefaults.outlinedButtonColors(contentColor = StatusRejectedRed),
                                shape = RoundedCornerShape(8.dp)
                            ) {
                                Icon(Icons.Default.Close, contentDescription = null, modifier = Modifier.size(16.dp))
                                Spacer(modifier = Modifier.width(4.dp))
                                Text("Reject", fontSize = 12.sp)
                            }
                        }

                        IconButton(
                            onClick = onDelete,
                            modifier = Modifier.size(38.dp)
                        ) {
                            Icon(Icons.Default.Delete, contentDescription = "Delete Listing", tint = StatusRejectedRed)
                        }
                    }
                }

                // Owner Edit / Delete Controls
                if (showOwnerControls) {
                    Spacer(modifier = Modifier.height(10.dp))
                    HorizontalDivider(color = NeutralLight.copy(alpha = 0.3f))
                    Spacer(modifier = Modifier.height(8.dp))

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        OutlinedButton(
                            onClick = onEdit,
                            modifier = Modifier.weight(1f).height(36.dp),
                            shape = RoundedCornerShape(8.dp)
                        ) {
                            Icon(Icons.Default.Edit, contentDescription = null, modifier = Modifier.size(16.dp))
                            Spacer(modifier = Modifier.width(4.dp))
                            Text("Edit", fontSize = 12.sp)
                        }

                        IconButton(
                            onClick = onDelete,
                            modifier = Modifier.size(36.dp)
                        ) {
                            Icon(Icons.Default.Delete, contentDescription = "Delete", tint = StatusRejectedRed)
                        }
                    }
                }
            }
        }
    }
}

@Composable
fun SpecBadge(icon: androidx.compose.ui.graphics.vector.ImageVector, text: String) {
    Surface(
        color = NeutralLight.copy(alpha = 0.15f),
        shape = RoundedCornerShape(6.dp)
    ) {
        Row(
            modifier = Modifier.padding(horizontal = 6.dp, vertical = 3.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Icon(
                imageVector = icon,
                contentDescription = null,
                modifier = Modifier.size(12.dp),
                tint = NeutralDark
            )
            Spacer(modifier = Modifier.width(4.dp))
            Text(
                text = text,
                fontSize = 11.sp,
                fontWeight = FontWeight.Medium,
                color = NeutralDark
            )
        }
    }
}
