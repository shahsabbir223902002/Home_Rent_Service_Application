package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.model.ApprovalStatus
import com.example.data.model.Property
import com.example.data.model.PropertyCategory
import com.example.ui.components.FilterBottomSheet
import com.example.ui.components.PropertyCard
import com.example.ui.components.PropertyFilter
import com.example.ui.theme.*
import com.example.ui.viewmodel.MainViewModel
import com.example.ui.viewmodel.Screen

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun UserHomeScreen(
    viewModel: MainViewModel,
    modifier: Modifier = Modifier
) {
    val currentUser by viewModel.currentUser.collectAsState()
    val properties by viewModel.approvedProperties.collectAsState()
    val allProps by viewModel.allProperties.collectAsState()
    val favorites by viewModel.favorites.collectAsState()
    val filter by viewModel.filter.collectAsState()
    val searchQuery by viewModel.searchQuery.collectAsState()

    var showFilterSheet by remember { mutableStateOf(false) }

    val houseCount = allProps.count { it.category == PropertyCategory.HOUSE && it.approvalStatus == ApprovalStatus.APPROVED }
    val storeCount = allProps.count { it.category == PropertyCategory.STORE && it.approvalStatus == ApprovalStatus.APPROVED }
    val parkingCount = allProps.count { it.category == PropertyCategory.CAR_PARKING && it.approvalStatus == ApprovalStatus.APPROVED }

    Scaffold(
        floatingActionButton = {
            ExtendedFloatingActionButton(
                onClick = { viewModel.navigateTo(Screen.ADD_PROPERTY) },
                icon = { Icon(Icons.Default.Add, contentDescription = "Add Rental") },
                text = { Text("Post Rental", fontWeight = FontWeight.Bold) },
                containerColor = BrandMint,
                contentColor = NeutralDark,
                modifier = Modifier.testTag("post_rental_fab")
            )
        }
    ) { innerPadding ->
        LazyColumn(
            modifier = modifier
                .fillMaxSize()
                .padding(innerPadding)
                .background(MaterialTheme.colorScheme.background),
            contentPadding = PaddingValues(bottom = 96.dp)
        ) {
            // 1. Top Hero Section with Mogoltoli Branding
            item {
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .background(
                            Brush.verticalGradient(
                                colors = listOf(BrandTealDark, BrandTealMedium)
                            )
                        )
                        .padding(20.dp)
                ) {
                    Column {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Column {
                                Surface(
                                    shape = RoundedCornerShape(12.dp),
                                    color = BrandMint.copy(alpha = 0.2f)
                                ) {
                                    Row(
                                        modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp),
                                        verticalAlignment = Alignment.CenterVertically
                                    ) {
                                        Icon(
                                            Icons.Default.LocationOn,
                                            contentDescription = null,
                                            tint = BrandMint,
                                            modifier = Modifier.size(14.dp)
                                        )
                                        Spacer(modifier = Modifier.width(4.dp))
                                        Text(
                                            "Mogoltoli, Cumilla",
                                            color = BrandMint,
                                            fontSize = 11.sp,
                                            fontWeight = FontWeight.Bold
                                        )
                                    }
                                }
                                Spacer(modifier = Modifier.height(4.dp))
                                Text(
                                    text = "Home Rent Service",
                                    fontSize = 22.sp,
                                    fontWeight = FontWeight.ExtraBold,
                                    color = Color.White
                                )
                                Text(
                                    text = "Hello, ${currentUser?.name ?: "Guest"}",
                                    fontSize = 13.sp,
                                    color = Color.White.copy(alpha = 0.8f)
                                )
                            }

                            // Switch to Interactive Map Action
                            FilledTonalButton(
                                onClick = { viewModel.navigateTo(Screen.PROPERTY_MAP) },
                                colors = ButtonDefaults.filledTonalButtonColors(
                                    containerColor = BrandMint,
                                    contentColor = NeutralDark
                                ),
                                shape = RoundedCornerShape(12.dp),
                                modifier = Modifier.testTag("home_map_toggle_button")
                            ) {
                                Icon(Icons.Default.Map, contentDescription = null, modifier = Modifier.size(18.dp))
                                Spacer(modifier = Modifier.width(6.dp))
                                Text("Map View", fontSize = 12.sp, fontWeight = FontWeight.Bold)
                            }
                        }

                        Spacer(modifier = Modifier.height(16.dp))

                        // Search Bar & Filter Button
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(8.dp)
                        ) {
                            TextField(
                                value = searchQuery,
                                onValueChange = { viewModel.setSearchQuery(it) },
                                placeholder = { Text("Search flat, shop, parking in Mogoltoli...", fontSize = 13.sp) },
                                leadingIcon = { Icon(Icons.Default.Search, contentDescription = "Search", tint = BrandTealDark) },
                                trailingIcon = {
                                    if (searchQuery.isNotEmpty()) {
                                        IconButton(onClick = { viewModel.setSearchQuery("") }) {
                                            Icon(Icons.Default.Clear, contentDescription = "Clear search", tint = BrandTealDark)
                                        }
                                    }
                                },
                                modifier = Modifier
                                    .weight(1f)
                                    .testTag("home_search_input"),
                                shape = RoundedCornerShape(14.dp),
                                colors = TextFieldDefaults.colors(
                                    focusedContainerColor = Color.White,
                                    unfocusedContainerColor = Color.White,
                                    focusedIndicatorColor = Color.Transparent,
                                    unfocusedIndicatorColor = Color.Transparent
                                ),
                                singleLine = true
                            )

                            IconButton(
                                onClick = { showFilterSheet = true },
                                modifier = Modifier
                                    .size(52.dp)
                                    .background(BrandMint, RoundedCornerShape(14.dp))
                                    .testTag("home_filter_button")
                            ) {
                                Icon(Icons.Default.Tune, contentDescription = "Filters", tint = NeutralDark)
                            }
                        }
                    }
                }
            }

            // 2. Property Categories Quick Selector
            item {
                Column(modifier = Modifier.padding(20.dp)) {
                    Text(
                        text = "Rental Categories",
                        fontSize = 17.sp,
                        fontWeight = FontWeight.Bold,
                        color = MaterialTheme.colorScheme.onSurface
                    )
                    Spacer(modifier = Modifier.height(12.dp))

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(10.dp)
                    ) {
                        CategoryQuickCard(
                            title = "Houses",
                            count = "$houseCount Available",
                            icon = Icons.Default.Home,
                            color = CategoryHouseColor,
                            isSelected = filter.category == PropertyCategory.HOUSE,
                            onClick = {
                                viewModel.setFilter(
                                    filter.copy(category = if (filter.category == PropertyCategory.HOUSE) null else PropertyCategory.HOUSE)
                                )
                            },
                            modifier = Modifier.weight(1f)
                        )
                        CategoryQuickCard(
                            title = "Stores",
                            count = "$storeCount Available",
                            icon = Icons.Default.Storefront,
                            color = CategoryStoreColor,
                            isSelected = filter.category == PropertyCategory.STORE,
                            onClick = {
                                viewModel.setFilter(
                                    filter.copy(category = if (filter.category == PropertyCategory.STORE) null else PropertyCategory.STORE)
                                )
                            },
                            modifier = Modifier.weight(1f)
                        )
                        CategoryQuickCard(
                            title = "Parking",
                            count = "$parkingCount Slots",
                            icon = Icons.Default.DirectionsCar,
                            color = CategoryParkingColor,
                            isSelected = filter.category == PropertyCategory.CAR_PARKING,
                            onClick = {
                                viewModel.setFilter(
                                    filter.copy(category = if (filter.category == PropertyCategory.CAR_PARKING) null else PropertyCategory.CAR_PARKING)
                                )
                            },
                            modifier = Modifier.weight(1f)
                        )
                    }
                }
            }

            // 3. Mogoltoli Service Area Information Banner
            item {
                Surface(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(horizontal = 20.dp),
                    shape = RoundedCornerShape(16.dp),
                    color = BrandMintLight.copy(alpha = 0.5f),
                    border = CardDefaults.outlinedCardBorder()
                ) {
                    Row(
                        modifier = Modifier.padding(14.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Box(
                            modifier = Modifier
                                .size(40.dp)
                                .background(BrandTealDark, CircleShape),
                            contentAlignment = Alignment.Center
                        ) {
                            Icon(Icons.Default.CheckCircle, contentDescription = null, tint = BrandMint, modifier = Modifier.size(20.dp))
                        }
                        Spacer(modifier = Modifier.width(12.dp))
                        Column(modifier = Modifier.weight(1f)) {
                            Text(
                                "Exclusive Mogoltoli Coverage",
                                fontWeight = FontWeight.Bold,
                                fontSize = 13.sp,
                                color = BrandTealDark
                            )
                            Text(
                                "Properties are verified within Mogoltoli boundaries (Rajganj, Bazaar Road, Gomti Link).",
                                fontSize = 11.sp,
                                color = NeutralMedium
                            )
                        }
                    }
                }
            }

            // 4. Featured Listings Header
            item {
                Spacer(modifier = Modifier.height(16.dp))
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(horizontal = 20.dp),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        text = "Approved Listings in Mogoltoli (${properties.size})",
                        fontSize = 17.sp,
                        fontWeight = FontWeight.Bold,
                        color = MaterialTheme.colorScheme.onSurface
                    )
                    TextButton(onClick = { viewModel.navigateTo(Screen.PROPERTY_LIST) }) {
                        Text("See All", color = BrandTealDark, fontWeight = FontWeight.Bold)
                    }
                }
            }

            // 5. Property Listings Cards
            if (properties.isEmpty()) {
                item {
                    Column(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(40.dp),
                        horizontalAlignment = Alignment.CenterHorizontally
                    ) {
                        Icon(
                            Icons.Default.SearchOff,
                            contentDescription = null,
                            tint = NeutralLight,
                            modifier = Modifier.size(48.dp)
                        )
                        Spacer(modifier = Modifier.height(12.dp))
                        Text(
                            "No rental listings found",
                            fontWeight = FontWeight.Bold,
                            fontSize = 16.sp,
                            color = NeutralDark
                        )
                        Text(
                            "Try clearing your search query or adjusting your filters.",
                            fontSize = 12.sp,
                            color = NeutralMedium
                        )
                        Spacer(modifier = Modifier.height(12.dp))
                        OutlinedButton(onClick = { viewModel.clearFilter() }) {
                            Text("Clear Filters")
                        }
                    }
                }
            } else {
                items(properties) { prop ->
                    Box(modifier = Modifier.padding(horizontal = 20.dp, vertical = 8.dp)) {
                        PropertyCard(
                            property = prop,
                            isFavorite = favorites.contains(prop.id),
                            onFavoriteToggle = { viewModel.toggleFavorite(prop.id) },
                            onClick = { viewModel.openPropertyDetail(prop) }
                        )
                    }
                }
            }
        }
    }

    if (showFilterSheet) {
        FilterBottomSheet(
            initialFilter = filter,
            onApply = { viewModel.setFilter(it) },
            onDismiss = { showFilterSheet = false }
        )
    }
}

@Composable
fun CategoryQuickCard(
    title: String,
    count: String,
    icon: androidx.compose.ui.graphics.vector.ImageVector,
    color: Color,
    isSelected: Boolean,
    onClick: () -> Unit,
    modifier: Modifier = Modifier
) {
    Card(
        modifier = modifier
            .clickable(onClick = onClick)
            .testTag("category_card_${title.lowercase()}"),
        shape = RoundedCornerShape(14.dp),
        colors = CardDefaults.cardColors(
            containerColor = if (isSelected) color else MaterialTheme.colorScheme.surface
        ),
        elevation = CardDefaults.cardElevation(defaultElevation = if (isSelected) 4.dp else 1.dp)
    ) {
        Column(
            modifier = Modifier.padding(12.dp),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            Box(
                modifier = Modifier
                    .size(36.dp)
                    .background(
                        if (isSelected) Color.White.copy(alpha = 0.2f) else color.copy(alpha = 0.12f),
                        CircleShape
                    ),
                contentAlignment = Alignment.Center
            ) {
                Icon(
                    imageVector = icon,
                    contentDescription = null,
                    tint = if (isSelected) Color.White else color,
                    modifier = Modifier.size(20.dp)
                )
            }
            Spacer(modifier = Modifier.height(8.dp))
            Text(
                text = title,
                fontSize = 13.sp,
                fontWeight = FontWeight.Bold,
                color = if (isSelected) Color.White else NeutralDark
            )
            Text(
                text = count,
                fontSize = 10.sp,
                color = if (isSelected) Color.White.copy(alpha = 0.9f) else NeutralMedium
            )
        }
    }
}
