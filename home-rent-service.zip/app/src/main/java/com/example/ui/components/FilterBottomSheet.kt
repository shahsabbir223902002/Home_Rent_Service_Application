package com.example.ui.components

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Close
import androidx.compose.foundation.layout.ExperimentalLayoutApi
import androidx.compose.foundation.layout.FlowRow
import androidx.compose.foundation.layout.Row
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.model.AvailabilityStatus
import com.example.data.model.PropertyCategory
import com.example.ui.theme.BrandMint
import com.example.ui.theme.BrandTealDark

import androidx.compose.material3.*

data class PropertyFilter(
    val category: PropertyCategory? = null,
    val minRent: Double = 0.0,
    val maxRent: Double = 50000.0,
    val selectedFacilities: Set<String> = emptySet(),
    val availabilityStatus: AvailabilityStatus? = null
)

@OptIn(ExperimentalMaterial3Api::class, ExperimentalLayoutApi::class)
@Composable
fun FilterBottomSheet(
    initialFilter: PropertyFilter,
    onApply: (PropertyFilter) -> Unit,
    onDismiss: () -> Unit
) {
    var selectedCat by remember { mutableStateOf(initialFilter.category) }
    var rentRange by remember { mutableStateOf(initialFilter.minRent.toFloat()..initialFilter.maxRent.toFloat()) }
    var selectedFacilities by remember { mutableStateOf(initialFilter.selectedFacilities) }
    var availability by remember { mutableStateOf(initialFilter.availabilityStatus) }

    val commonFacilities = listOf(
        "Lift", "Generator Backup", "Gas Line", "24/7 Security", "CCTV",
        "Balcony", "Water Supply", "Rolling Shutter", "Commercial Meter",
        "Covered Roof", "Prepaid Electric Meter"
    )

    ModalBottomSheet(
        onDismissRequest = onDismiss,
        sheetState = rememberModalBottomSheetState(skipPartiallyExpanded = true),
        shape = RoundedCornerShape(topStart = 24.dp, topEnd = 24.dp)
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 20.dp, vertical = 12.dp)
                .verticalScroll(rememberScrollState())
        ) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = "Filter Mogoltoli Rentals",
                    fontSize = 18.sp,
                    fontWeight = FontWeight.Bold,
                    color = BrandTealDark
                )
                IconButton(onClick = onDismiss) {
                    Icon(Icons.Default.Close, contentDescription = "Close")
                }
            }

            Spacer(modifier = Modifier.height(16.dp))

            // 1. Property Category
            Text("Property Category", fontWeight = FontWeight.SemiBold, fontSize = 14.sp)
            Spacer(modifier = Modifier.height(8.dp))
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                FilterChip(
                    selected = selectedCat == null,
                    onClick = { selectedCat = null },
                    label = { Text("All") }
                )
                PropertyCategory.entries.forEach { cat ->
                    FilterChip(
                        selected = selectedCat == cat,
                        onClick = { selectedCat = if (selectedCat == cat) null else cat },
                        label = { Text(cat.displayName) }
                    )
                }
            }

            Spacer(modifier = Modifier.height(16.dp))

            // 2. Rent Range
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Text("Monthly Rent (BDT ৳)", fontWeight = FontWeight.SemiBold, fontSize = 14.sp)
                Text(
                    "৳ ${rentRange.start.toInt()} - ৳ ${rentRange.endInclusive.toInt()}",
                    fontWeight = FontWeight.Bold,
                    color = BrandTealDark,
                    fontSize = 13.sp
                )
            }
            RangeSlider(
                value = rentRange,
                onValueChange = { rentRange = it },
                valueRange = 0f..60000f,
                steps = 11,
                modifier = Modifier.testTag("rent_range_slider")
            )

            Spacer(modifier = Modifier.height(16.dp))

            // 3. Facilities
            Text("Facilities & Amenities", fontWeight = FontWeight.SemiBold, fontSize = 14.sp)
            Spacer(modifier = Modifier.height(8.dp))
            FlowRow(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(8.dp),
                verticalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                commonFacilities.forEach { facility ->
                    val isChecked = selectedFacilities.contains(facility)
                    FilterChip(
                        selected = isChecked,
                        onClick = {
                            selectedFacilities = if (isChecked) {
                                selectedFacilities - facility
                            } else {
                                selectedFacilities + facility
                            }
                        },
                        label = { Text(facility, fontSize = 12.sp) }
                    )
                }
            }

            Spacer(modifier = Modifier.height(16.dp))

            // 4. Availability
            Text("Availability", fontWeight = FontWeight.SemiBold, fontSize = 14.sp)
            Spacer(modifier = Modifier.height(8.dp))
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                FilterChip(
                    selected = availability == null,
                    onClick = { availability = null },
                    label = { Text("All") }
                )
                FilterChip(
                    selected = availability == AvailabilityStatus.AVAILABLE,
                    onClick = { availability = AvailabilityStatus.AVAILABLE },
                    label = { Text("Available Only") }
                )
                FilterChip(
                    selected = availability == AvailabilityStatus.RENTED,
                    onClick = { availability = AvailabilityStatus.RENTED },
                    label = { Text("Rented") }
                )
            }

            Spacer(modifier = Modifier.height(24.dp))

            // Action Buttons
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                OutlinedButton(
                    onClick = {
                        selectedCat = null
                        rentRange = 0f..50000f
                        selectedFacilities = emptySet()
                        availability = null
                    },
                    modifier = Modifier.weight(1f).height(48.dp),
                    shape = RoundedCornerShape(12.dp)
                ) {
                    Text("Reset")
                }

                Button(
                    onClick = {
                        onApply(
                            PropertyFilter(
                                category = selectedCat,
                                minRent = rentRange.start.toDouble(),
                                maxRent = rentRange.endInclusive.toDouble(),
                                selectedFacilities = selectedFacilities,
                                availabilityStatus = availability
                            )
                        )
                        onDismiss()
                    },
                    modifier = Modifier.weight(1f).height(48.dp).testTag("apply_filter_button"),
                    shape = RoundedCornerShape(12.dp)
                ) {
                    Text("Apply Filter")
                }
            }
            Spacer(modifier = Modifier.height(24.dp))
        }
    }
}
