package com.example.ui.screens

import androidx.activity.compose.BackHandler
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.ui.graphics.Color
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.model.ApprovalStatus
import com.example.data.model.AvailabilityStatus
import com.example.data.model.Property
import com.example.data.model.PropertyCategory
import com.example.ui.components.PropertyCard
import com.example.ui.theme.*
import com.example.ui.viewmodel.MainViewModel
import com.example.ui.viewmodel.Screen

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun AdminListingsScreen(
    viewModel: MainViewModel,
    modifier: Modifier = Modifier
) {
    BackHandler {
        viewModel.navigateTo(Screen.ADMIN_DASHBOARD)
    }

    val allProps by viewModel.allProperties.collectAsState()

    var selectedTab by remember { mutableIntStateOf(1) } // Default to Pending tab for quick approvals
    val tabs = listOf("All", "Pending", "Approved", "Rejected")

    var selectedCategoryFilter by remember { mutableStateOf<PropertyCategory?>(null) }
    var searchQuery by remember { mutableStateOf("") }

    // Dialog state for Rejection Reason
    var propertyToReject by remember { mutableStateOf<Property?>(null) }
    var rejectionReasonInput by remember { mutableStateOf("Inaccurate details or incomplete property documentation") }

    val filteredListings = remember(allProps, selectedTab, selectedCategoryFilter, searchQuery) {
        allProps.filter { prop ->
            val matchesTab = when (selectedTab) {
                1 -> prop.approvalStatus == ApprovalStatus.PENDING
                2 -> prop.approvalStatus == ApprovalStatus.APPROVED
                3 -> prop.approvalStatus == ApprovalStatus.REJECTED
                else -> true
            }
            val matchesCategory = selectedCategoryFilter == null || prop.category == selectedCategoryFilter
            val matchesQuery = searchQuery.isBlank() ||
                    prop.title.contains(searchQuery, ignoreCase = true) ||
                    prop.address.contains(searchQuery, ignoreCase = true) ||
                    prop.ownerName.contains(searchQuery, ignoreCase = true)

            matchesTab && matchesCategory && matchesQuery
        }
    }

    Scaffold(
        topBar = {
            TopAppBar(
                title = {
                    Column {
                        Text("Listing Management", fontWeight = FontWeight.Bold, fontSize = 18.sp)
                        Text("Admin Control • Mogoltoli, Cumilla", fontSize = 11.sp, color = NeutralMedium)
                    }
                },
                navigationIcon = {
                    IconButton(onClick = { viewModel.navigateTo(Screen.ADMIN_DASHBOARD) }) {
                        Icon(Icons.Default.ArrowBack, contentDescription = "Back")
                    }
                },
                actions = {
                    IconButton(onClick = { viewModel.navigateTo(Screen.ADMIN_MAP) }) {
                        Icon(Icons.Default.Map, contentDescription = "Admin Map", tint = BrandTealDark)
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(containerColor = MaterialTheme.colorScheme.surface)
            )
        }
    ) { innerPadding ->
        Column(
            modifier = modifier
                .fillMaxSize()
                .padding(innerPadding)
                .background(MaterialTheme.colorScheme.background)
        ) {
            // Search Input
            OutlinedTextField(
                value = searchQuery,
                onValueChange = { searchQuery = it },
                placeholder = { Text("Search by title, owner, or road...") },
                leadingIcon = { Icon(Icons.Default.Search, contentDescription = null) },
                trailingIcon = {
                    if (searchQuery.isNotEmpty()) {
                        IconButton(onClick = { searchQuery = "" }) {
                            Icon(Icons.Default.Clear, contentDescription = "Clear")
                        }
                    }
                },
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 16.dp, vertical = 6.dp)
                    .testTag("admin_listings_search"),
                shape = RoundedCornerShape(12.dp),
                singleLine = true
            )

            // Status Tabs
            PrimaryTabRow(
                selectedTabIndex = selectedTab,
                containerColor = MaterialTheme.colorScheme.surface
            ) {
                tabs.forEachIndexed { index, title ->
                    val count = when (index) {
                        1 -> allProps.count { it.approvalStatus == ApprovalStatus.PENDING }
                        2 -> allProps.count { it.approvalStatus == ApprovalStatus.APPROVED }
                        3 -> allProps.count { it.approvalStatus == ApprovalStatus.REJECTED }
                        else -> allProps.size
                    }
                    Tab(
                        selected = selectedTab == index,
                        onClick = { selectedTab = index },
                        text = {
                            Text(
                                "$title ($count)",
                                fontSize = 12.sp,
                                fontWeight = if (selectedTab == index) FontWeight.Bold else FontWeight.Normal,
                                color = if (index == 1 && count > 0) StatusPendingAmber else Color.Unspecified
                            )
                        }
                    )
                }
            }

            // Category Filter Row
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 16.dp, vertical = 6.dp),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                FilterChip(
                    selected = selectedCategoryFilter == null,
                    onClick = { selectedCategoryFilter = null },
                    label = { Text("All Categories", fontSize = 11.sp) }
                )
                PropertyCategory.entries.forEach { cat ->
                    FilterChip(
                        selected = selectedCategoryFilter == cat,
                        onClick = {
                            selectedCategoryFilter = if (selectedCategoryFilter == cat) null else cat
                        },
                        label = { Text(cat.displayName, fontSize = 11.sp) }
                    )
                }
            }

            if (filteredListings.isEmpty()) {
                Box(
                    modifier = Modifier.fillMaxSize(),
                    contentAlignment = Alignment.Center
                ) {
                    Column(horizontalAlignment = Alignment.CenterHorizontally) {
                        Icon(Icons.Default.CheckCircleOutline, contentDescription = null, modifier = Modifier.size(56.dp), tint = StatusApprovedGreen)
                        Spacer(modifier = Modifier.height(12.dp))
                        Text("No listings in this queue", fontWeight = FontWeight.Bold, color = NeutralDark)
                        Text("All submissions in this tab are reviewed or no matches", fontSize = 12.sp, color = NeutralMedium)
                    }
                }
            } else {
                LazyColumn(
                    modifier = Modifier.fillMaxSize(),
                    contentPadding = PaddingValues(16.dp),
                    verticalArrangement = Arrangement.spacedBy(16.dp)
                ) {
                    items(filteredListings) { prop ->
                        PropertyCard(
                            property = prop,
                            showAdminControls = true,
                            onApprove = { viewModel.adminApprove(prop.id) },
                            onReject = { propertyToReject = prop },
                            onDelete = { viewModel.deleteProperty(prop.id) },
                            onClick = { viewModel.openPropertyDetail(prop) }
                        )
                    }
                }
            }
        }
    }

    // Rejection Reason Modal Dialog
    if (propertyToReject != null) {
        val p = propertyToReject!!
        AlertDialog(
            onDismissRequest = { propertyToReject = null },
            title = { Text("Reject Listing #${p.id}", fontWeight = FontWeight.Bold) },
            text = {
                Column {
                    Text(
                        "Provide a clear reason for rejecting \"${p.title}\". The owner will see this note.",
                        fontSize = 12.sp,
                        color = NeutralMedium
                    )
                    Spacer(modifier = Modifier.height(12.dp))

                    val standardReasons = listOf(
                        "Inaccurate details or incomplete property documentation",
                        "Location outside verified Mogoltoli service area",
                        "Price seems unusually high or unrealistic",
                        "Photos are unclear or copyrighted"
                    )

                    standardReasons.forEach { reason ->
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            RadioButton(
                                selected = rejectionReasonInput == reason,
                                onClick = { rejectionReasonInput = reason }
                            )
                            Text(reason, fontSize = 12.sp)
                        }
                    }

                    Spacer(modifier = Modifier.height(8.dp))
                    OutlinedTextField(
                        value = rejectionReasonInput,
                        onValueChange = { rejectionReasonInput = it },
                        modifier = Modifier.fillMaxWidth(),
                        label = { Text("Custom Reason Note") }
                    )
                }
            },
            confirmButton = {
                Button(
                    onClick = {
                        viewModel.adminReject(p.id, rejectionReasonInput)
                        propertyToReject = null
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = StatusRejectedRed)
                ) {
                    Text("Confirm Rejection")
                }
            },
            dismissButton = {
                TextButton(onClick = { propertyToReject = null }) {
                    Text("Cancel")
                }
            }
        )
    }
}
