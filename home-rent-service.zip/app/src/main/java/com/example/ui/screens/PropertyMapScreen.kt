package com.example.ui.screens

import androidx.activity.compose.BackHandler
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.model.Property
import com.example.data.model.PropertyCategory
import com.example.ui.components.MogoltoliInteractiveMap
import com.example.ui.theme.*
import com.example.ui.viewmodel.MainViewModel
import com.example.ui.viewmodel.Screen

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun PropertyMapScreen(
    viewModel: MainViewModel,
    modifier: Modifier = Modifier
) {
    BackHandler {
        viewModel.navigateBack()
    }

    val properties by viewModel.approvedProperties.collectAsState()
    var selectedProperty by remember { mutableStateOf<Property?>(null) }
    val filter by viewModel.filter.collectAsState()

    Scaffold(
        topBar = {
            TopAppBar(
                title = {
                    Column {
                        Text("Mogoltoli Map Discovery", fontWeight = FontWeight.Bold, fontSize = 17.sp)
                        Text("Cumilla, Bangladesh • ${properties.size} markers", fontSize = 11.sp, color = NeutralMedium)
                    }
                },
                navigationIcon = {
                    IconButton(onClick = { viewModel.navigateBack() }) {
                        Icon(Icons.Default.ArrowBack, contentDescription = "Back")
                    }
                },
                actions = {
                    FilledTonalButton(
                        onClick = { viewModel.navigateTo(Screen.PROPERTY_LIST) },
                        colors = ButtonDefaults.filledTonalButtonColors(
                            containerColor = BrandMint,
                            contentColor = NeutralDark
                        ),
                        shape = RoundedCornerShape(10.dp),
                        contentPadding = PaddingValues(horizontal = 10.dp, vertical = 0.dp),
                        modifier = Modifier.padding(end = 8.dp).height(34.dp).testTag("map_list_view_button")
                    ) {
                        Icon(Icons.Default.List, contentDescription = null, modifier = Modifier.size(16.dp))
                        Spacer(modifier = Modifier.width(4.dp))
                        Text("List View", fontSize = 11.sp, fontWeight = FontWeight.Bold)
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(containerColor = MaterialTheme.colorScheme.surface)
            )
        }
    ) { innerPadding ->
        Box(
            modifier = modifier
                .fillMaxSize()
                .padding(innerPadding)
        ) {
            // Interactive Mogoltoli Canvas Map
            MogoltoliInteractiveMap(
                properties = properties,
                selectedProperty = selectedProperty,
                onPropertySelected = { prop ->
                    if (prop != null && selectedProperty?.id == prop.id) {
                        // Double click opens detail
                        viewModel.openPropertyDetail(prop)
                    } else {
                        selectedProperty = prop
                    }
                },
                isPickerMode = false,
                modifier = Modifier.fillMaxSize()
            )

            // Top Category Filter Pills
            Surface(
                modifier = Modifier
                    .align(Alignment.TopCenter)
                    .padding(top = 10.dp),
                shape = RoundedCornerShape(24.dp),
                color = MaterialTheme.colorScheme.surface.copy(alpha = 0.95f),
                shadowElevation = 4.dp
            ) {
                Row(
                    modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp),
                    horizontalArrangement = Arrangement.spacedBy(6.dp)
                ) {
                    FilterChip(
                        selected = filter.category == null,
                        onClick = { viewModel.setFilter(filter.copy(category = null)) },
                        label = { Text("All", fontSize = 11.sp) }
                    )
                    FilterChip(
                        selected = filter.category == PropertyCategory.HOUSE,
                        onClick = {
                            viewModel.setFilter(
                                filter.copy(category = if (filter.category == PropertyCategory.HOUSE) null else PropertyCategory.HOUSE)
                            )
                        },
                        label = { Text("Houses", fontSize = 11.sp) }
                    )
                    FilterChip(
                        selected = filter.category == PropertyCategory.STORE,
                        onClick = {
                            viewModel.setFilter(
                                filter.copy(category = if (filter.category == PropertyCategory.STORE) null else PropertyCategory.STORE)
                            )
                        },
                        label = { Text("Stores", fontSize = 11.sp) }
                    )
                    FilterChip(
                        selected = filter.category == PropertyCategory.CAR_PARKING,
                        onClick = {
                            viewModel.setFilter(
                                filter.copy(category = if (filter.category == PropertyCategory.CAR_PARKING) null else PropertyCategory.CAR_PARKING)
                            )
                        },
                        label = { Text("Parking", fontSize = 11.sp) }
                    )
                }
            }
        }
    }
}
