package com.example.ui.screens

import androidx.activity.compose.BackHandler
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.ui.theme.*
import com.example.ui.viewmodel.MainViewModel
import com.example.ui.viewmodel.Screen

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun AdminDashboardScreen(
    viewModel: MainViewModel,
    modifier: Modifier = Modifier
) {
    val stats by viewModel.dashboardStats.collectAsState()
    val currentUser by viewModel.currentUser.collectAsState()

    BackHandler {
        viewModel.navigateTo(Screen.USER_HOME)
    }

    Scaffold(
        topBar = {
            TopAppBar(
                title = {
                    Column {
                        Text("Admin Dashboard", fontWeight = FontWeight.Bold, fontSize = 18.sp)
                        Text("Home Rent Service • Mogoltoli, Cumilla", fontSize = 11.sp, color = NeutralMedium)
                    }
                },
                actions = {
                    FilledTonalButton(
                        onClick = { viewModel.navigateTo(Screen.USER_HOME) },
                        colors = ButtonDefaults.filledTonalButtonColors(
                            containerColor = BrandMintLight,
                            contentColor = BrandTealDark
                        ),
                        shape = RoundedCornerShape(8.dp),
                        contentPadding = PaddingValues(horizontal = 8.dp, vertical = 0.dp),
                        modifier = Modifier.padding(end = 8.dp).height(32.dp).testTag("admin_switch_to_user_button")
                    ) {
                        Icon(Icons.Default.Visibility, contentDescription = null, modifier = Modifier.size(14.dp))
                        Spacer(modifier = Modifier.width(4.dp))
                        Text("User Portal", fontSize = 11.sp, fontWeight = FontWeight.Bold)
                    }
                    IconButton(onClick = { viewModel.logout() }) {
                        Icon(Icons.Default.Logout, contentDescription = "Logout", tint = StatusRejectedRed)
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(containerColor = MaterialTheme.colorScheme.surface)
            )
        }
    ) { innerPadding ->
        Column(
            modifier = modifier
                .fillMaxSize()
                .padding(innerPadding)
                .background(MaterialTheme.colorScheme.background)
                .verticalScroll(rememberScrollState())
                .padding(16.dp)
        ) {
            // Admin Greeting Banner
            Surface(
                color = BrandTealDark,
                shape = RoundedCornerShape(16.dp),
                modifier = Modifier.fillMaxWidth()
            ) {
                Row(
                    modifier = Modifier.padding(16.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Box(
                        modifier = Modifier
                            .size(48.dp)
                            .background(BrandMint, CircleShape),
                        contentAlignment = Alignment.Center
                    ) {
                        Icon(Icons.Default.Shield, contentDescription = null, tint = BrandTealDark, modifier = Modifier.size(26.dp))
                    }
                    Spacer(modifier = Modifier.width(14.dp))
                    Column(modifier = Modifier.weight(1f)) {
                        Text(
                            text = "Admin: ${currentUser?.name ?: "Administrator"}",
                            color = Color.White,
                            fontWeight = FontWeight.Bold,
                            fontSize = 15.sp
                        )
                        Text(
                            text = "Server-side role verified • Mogoltoli moderation live",
                            color = BrandMintLight,
                            fontSize = 11.sp
                        )
                    }
                }
            }

            Spacer(modifier = Modifier.height(16.dp))

            // 6 Summary Metric Cards required by prompt
            Text("Overview Metrics", fontWeight = FontWeight.Bold, fontSize = 15.sp)
            Spacer(modifier = Modifier.height(10.dp))

            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                AdminStatCard(
                    title = "Total Users",
                    value = stats.totalUsers.toString(),
                    subtitle = "Registered renters & owners",
                    icon = Icons.Default.People,
                    color = BrandTealMedium,
                    onClick = { viewModel.navigateTo(Screen.ADMIN_USERS) },
                    modifier = Modifier.weight(1f)
                )
                AdminStatCard(
                    title = "Total Listings",
                    value = stats.totalListings.toString(),
                    subtitle = "All submitted rentals",
                    icon = Icons.Default.ListAlt,
                    color = BrandTealDark,
                    onClick = { viewModel.navigateTo(Screen.ADMIN_LISTINGS) },
                    modifier = Modifier.weight(1f)
                )
            }

            Spacer(modifier = Modifier.height(10.dp))

            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                AdminStatCard(
                    title = "Pending Approvals",
                    value = stats.pendingListings.toString(),
                    subtitle = "Action required",
                    icon = Icons.Default.HourglassTop,
                    color = StatusPendingAmber,
                    onClick = { viewModel.navigateTo(Screen.ADMIN_LISTINGS) },
                    modifier = Modifier.weight(1f)
                )
                AdminStatCard(
                    title = "Approved Listings",
                    value = stats.approvedListings.toString(),
                    subtitle = "Publicly visible on map",
                    icon = Icons.Default.CheckCircle,
                    color = StatusApprovedGreen,
                    onClick = { viewModel.navigateTo(Screen.ADMIN_LISTINGS) },
                    modifier = Modifier.weight(1f)
                )
            }

            Spacer(modifier = Modifier.height(10.dp))

            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                AdminStatCard(
                    title = "Rejected Listings",
                    value = stats.rejectedListings.toString(),
                    subtitle = "Declined with reason",
                    icon = Icons.Default.Cancel,
                    color = StatusRejectedRed,
                    onClick = { viewModel.navigateTo(Screen.ADMIN_LISTINGS) },
                    modifier = Modifier.weight(1f)
                )
                AdminStatCard(
                    title = "Rented / Unavailable",
                    value = stats.rentedListings.toString(),
                    subtitle = "Occupied properties",
                    icon = Icons.Default.Lock,
                    color = NeutralMedium,
                    onClick = { viewModel.navigateTo(Screen.ADMIN_LISTINGS) },
                    modifier = Modifier.weight(1f)
                )
            }

            Spacer(modifier = Modifier.height(20.dp))

            // Admin Modules Navigation Grid
            Text("Administrative Operations", fontWeight = FontWeight.Bold, fontSize = 15.sp)
            Spacer(modifier = Modifier.height(10.dp))

            AdminActionRow(
                icon = Icons.Default.Rule,
                title = "Pending Listings Queue",
                badge = "${stats.pendingListings} Pending",
                badgeColor = StatusPendingAmber,
                onClick = { viewModel.navigateTo(Screen.ADMIN_LISTINGS) }
            )

            AdminActionRow(
                icon = Icons.Default.Map,
                title = "Inspect Mogoltoli Map",
                badge = "View All Pins",
                badgeColor = BrandTealDark,
                onClick = { viewModel.navigateTo(Screen.ADMIN_MAP) }
            )

            AdminActionRow(
                icon = Icons.Default.ManageAccounts,
                title = "User Management",
                badge = "${stats.totalUsers} Users",
                badgeColor = BrandTealMedium,
                onClick = { viewModel.navigateTo(Screen.ADMIN_USERS) }
            )

            AdminActionRow(
                icon = Icons.Default.ReportProblem,
                title = "Reports & Complaints",
                badge = "Investigate",
                badgeColor = StatusRejectedRed,
                onClick = { viewModel.navigateTo(Screen.ADMIN_REPORTS) }
            )

            AdminActionRow(
                icon = Icons.Default.History,
                title = "Activity & Audit Logs",
                badge = "Logs",
                badgeColor = NeutralMedium,
                onClick = { viewModel.navigateTo(Screen.ADMIN_LOGS) }
            )

            AdminActionRow(
                icon = Icons.Default.Settings,
                title = "System & API Settings",
                badge = "XAMPP / MySQL",
                badgeColor = BrandMint,
                onClick = { viewModel.navigateTo(Screen.ADMIN_SETTINGS) }
            )

            Spacer(modifier = Modifier.height(30.dp))
        }
    }
}

@Composable
fun AdminStatCard(
    title: String,
    value: String,
    subtitle: String,
    icon: androidx.compose.ui.graphics.vector.ImageVector,
    color: Color,
    onClick: () -> Unit,
    modifier: Modifier = Modifier
) {
    Card(
        modifier = modifier.clickable(onClick = onClick),
        shape = RoundedCornerShape(14.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
        elevation = CardDefaults.cardElevation(defaultElevation = 2.dp)
    ) {
        Column(modifier = Modifier.padding(14.dp)) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Box(
                    modifier = Modifier
                        .size(36.dp)
                        .background(color.copy(alpha = 0.15f), RoundedCornerShape(8.dp)),
                    contentAlignment = Alignment.Center
                ) {
                    Icon(icon, contentDescription = null, tint = color, modifier = Modifier.size(20.dp))
                }
                Text(
                    text = value,
                    fontSize = 22.sp,
                    fontWeight = FontWeight.ExtraBold,
                    color = color
                )
            }
            Spacer(modifier = Modifier.height(8.dp))
            Text(title, fontWeight = FontWeight.Bold, fontSize = 13.sp, color = NeutralDark)
            Text(subtitle, fontSize = 10.sp, color = NeutralMedium)
        }
    }
}

@Composable
fun AdminActionRow(
    icon: androidx.compose.ui.graphics.vector.ImageVector,
    title: String,
    badge: String,
    badgeColor: Color,
    onClick: () -> Unit
) {
    Card(
        modifier = Modifier
            .fillMaxWidth()
            .padding(vertical = 4.dp),
        shape = RoundedCornerShape(12.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
        onClick = onClick
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(14.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Icon(icon, contentDescription = null, tint = BrandTealDark, modifier = Modifier.size(22.dp))
            Spacer(modifier = Modifier.width(12.dp))
            Text(title, fontWeight = FontWeight.SemiBold, fontSize = 14.sp, modifier = Modifier.weight(1f))
            Surface(
                shape = RoundedCornerShape(6.dp),
                color = badgeColor.copy(alpha = 0.15f)
            ) {
                Text(
                    text = badge,
                    color = badgeColor,
                    fontSize = 11.sp,
                    fontWeight = FontWeight.Bold,
                    modifier = Modifier.padding(horizontal = 8.dp, vertical = 2.dp)
                )
            }
            Spacer(modifier = Modifier.width(8.dp))
            Icon(Icons.Default.ChevronRight, contentDescription = null, tint = NeutralMedium)
        }
    }
}
