package com.example.ui.theme

import androidx.compose.ui.graphics.Color

// Primary Branding: Deep Teal & Forest Mint
val BrandTealDark = Color(0xFF0B3C49)
val BrandTealMedium = Color(0xFF145366)
val BrandTealLight = Color(0xFF2E798F)
val BrandMint = Color(0xFF2EC4B6)
val BrandMintLight = Color(0xFFCBF3F0)

// Accent & Status Colors
val AccentAmber = Color(0xFFE9C46A)
val AccentCoral = Color(0xFFE76F51)
val StatusApprovedGreen = Color(0xFF2A9D8F)
val StatusPendingAmber = Color(0xFFF4A261)
val StatusRejectedRed = Color(0xFFE63946)

// Neutral Palette
val NeutralDark = Color(0xFF1F2937)
val NeutralMedium = Color(0xFF4B5563)
val NeutralLight = Color(0xFF9CA3AF)
val SurfaceBgLight = Color(0xFFF8F9FA)
val SurfaceCardLight = Color(0xFFFFFFFF)
val SurfaceBorderLight = Color(0xFFE5E7EB)

// Category Accent Colors
val CategoryHouseColor = Color(0xFF1D4ED8)
val CategoryStoreColor = Color(0xFF047857)
val CategoryParkingColor = Color(0xFFD97706)
