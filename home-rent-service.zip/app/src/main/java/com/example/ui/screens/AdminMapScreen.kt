package com.example.ui.screens

import androidx.activity.compose.BackHandler
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.model.ApprovalStatus
import com.example.data.model.Property
import com.example.ui.components.MogoltoliInteractiveMap
import com.example.ui.theme.*
import com.example.ui.viewmodel.MainViewModel
import com.example.ui.viewmodel.Screen

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun AdminMapScreen(
    viewModel: MainViewModel,
    modifier: Modifier = Modifier
) {
    BackHandler {
        viewModel.navigateTo(Screen.ADMIN_DASHBOARD)
    }

    val allProperties by viewModel.allProperties.collectAsState()
    var selectedProperty by remember { mutableStateOf<Property?>(null) }

    Scaffold(
        topBar = {
            TopAppBar(
                title = {
                    Column {
                        Text("Admin Mogoltoli Map Inspector", fontWeight = FontWeight.Bold, fontSize = 17.sp)
                        Text("Inspecting all locations including Pending", fontSize = 11.sp, color = StatusPendingAmber)
                    }
                },
                navigationIcon = {
                    IconButton(onClick = { viewModel.navigateTo(Screen.ADMIN_DASHBOARD) }) {
                        Icon(Icons.Default.ArrowBack, contentDescription = "Back")
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(containerColor = MaterialTheme.colorScheme.surface)
            )
        }
    ) { innerPadding ->
        Box(
            modifier = modifier
                .fillMaxSize()
                .padding(innerPadding)
        ) {
            MogoltoliInteractiveMap(
                properties = allProperties,
                selectedProperty = selectedProperty,
                onPropertySelected = { selectedProperty = it },
                showAllStatuses = true, // Admin can see Pending, Rejected, and Approved
                modifier = Modifier.fillMaxSize()
            )

            // Admin Inspection Status Card if property selected
            selectedProperty?.let { prop ->
                Card(
                    modifier = Modifier
                        .align(Alignment.TopCenter)
                        .padding(16.dp)
                        .fillMaxWidth(),
                    shape = RoundedCornerShape(12.dp),
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                    elevation = CardDefaults.cardElevation(defaultElevation = 6.dp)
                ) {
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(12.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Column(modifier = Modifier.weight(1f)) {
                            Text(prop.title, fontWeight = FontWeight.Bold, fontSize = 13.sp, maxLines = 1)
                            Text("Owner: ${prop.ownerName} (${prop.ownerPhone})", fontSize = 11.sp, color = NeutralMedium)
                            Text("Coords: ${String.format("%.4f", prop.latitude)}, ${String.format("%.4f", prop.longitude)}", fontSize = 10.sp, color = BrandTealDark)
                        }

                        if (prop.approvalStatus == ApprovalStatus.PENDING) {
                            Button(
                                onClick = {
                                    viewModel.adminApprove(prop.id)
                                    selectedProperty = null
                                },
                                colors = ButtonDefaults.buttonColors(containerColor = StatusApprovedGreen),
                                modifier = Modifier.height(34.dp)
                            ) {
                                Text("Approve", fontSize = 11.sp)
                            }
                        } else {
                            Surface(
                                shape = RoundedCornerShape(6.dp),
                                color = if (prop.approvalStatus == ApprovalStatus.APPROVED) StatusApprovedGreen else StatusRejectedRed
                            ) {
                                Text(
                                    prop.approvalStatus.label,
                                    color = Color.White,
                                    fontSize = 11.sp,
                                    fontWeight = FontWeight.Bold,
                                    modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp)
                                )
                            }
                        }
                    }
                }
            }
        }
    }
}
