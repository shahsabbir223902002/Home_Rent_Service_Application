package com.example.ui.screens

import androidx.activity.compose.BackHandler
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.model.PropertyCategory
import com.example.ui.components.FilterBottomSheet
import com.example.ui.components.PropertyCard
import com.example.ui.theme.BrandTealDark
import com.example.ui.theme.NeutralDark
import com.example.ui.theme.NeutralMedium
import com.example.ui.viewmodel.MainViewModel
import com.example.ui.viewmodel.Screen

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun PropertyListScreen(
    viewModel: MainViewModel,
    modifier: Modifier = Modifier
) {
    BackHandler {
        viewModel.navigateBack()
    }

    val properties by viewModel.approvedProperties.collectAsState()
    val favorites by viewModel.favorites.collectAsState()
    val searchQuery by viewModel.searchQuery.collectAsState()
    val filter by viewModel.filter.collectAsState()

    var showFilterSheet by remember { mutableStateOf(false) }

    Scaffold(
        topBar = {
            TopAppBar(
                title = {
                    Column {
                        Text("Mogoltoli Rentals", fontWeight = FontWeight.Bold, fontSize = 18.sp)
                        Text("${properties.size} properties available", fontSize = 11.sp, color = NeutralMedium)
                    }
                },
                navigationIcon = {
                    IconButton(onClick = { viewModel.navigateBack() }) {
                        Icon(Icons.Default.ArrowBack, contentDescription = "Back")
                    }
                },
                actions = {
                    IconButton(
                        onClick = { viewModel.navigateTo(Screen.PROPERTY_MAP) },
                        modifier = Modifier.testTag("switch_to_map_button")
                    ) {
                        Icon(Icons.Default.Map, contentDescription = "Map View", tint = BrandTealDark)
                    }
                    IconButton(
                        onClick = { showFilterSheet = true },
                        modifier = Modifier.testTag("open_filter_button")
                    ) {
                        Icon(Icons.Default.Tune, contentDescription = "Filter", tint = BrandTealDark)
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(containerColor = MaterialTheme.colorScheme.surface)
            )
        }
    ) { innerPadding ->
        Column(
            modifier = modifier
                .fillMaxSize()
                .padding(innerPadding)
                .background(MaterialTheme.colorScheme.background)
        ) {
            // Search field
            OutlinedTextField(
                value = searchQuery,
                onValueChange = { viewModel.setSearchQuery(it) },
                placeholder = { Text("Search title, road, or area in Mogoltoli...") },
                leadingIcon = { Icon(Icons.Default.Search, contentDescription = null) },
                trailingIcon = {
                    if (searchQuery.isNotEmpty()) {
                        IconButton(onClick = { viewModel.setSearchQuery("") }) {
                            Icon(Icons.Default.Clear, contentDescription = "Clear")
                        }
                    }
                },
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 16.dp, vertical = 8.dp)
                    .testTag("search_list_input"),
                shape = RoundedCornerShape(12.dp),
                singleLine = true
            )

            // Category quick toggle chips
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 16.dp, vertical = 4.dp),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                FilterChip(
                    selected = filter.category == null,
                    onClick = { viewModel.setFilter(filter.copy(category = null)) },
                    label = { Text("All") }
                )
                PropertyCategory.entries.forEach { cat ->
                    FilterChip(
                        selected = filter.category == cat,
                        onClick = {
                            viewModel.setFilter(
                                filter.copy(category = if (filter.category == cat) null else cat)
                            )
                        },
                        label = { Text(cat.displayName) }
                    )
                }
            }

            Spacer(modifier = Modifier.height(4.dp))

            if (properties.isEmpty()) {
                Box(
                    modifier = Modifier.fillMaxSize(),
                    contentAlignment = Alignment.Center
                ) {
                    Column(horizontalAlignment = Alignment.CenterHorizontally) {
                        Icon(Icons.Default.SearchOff, contentDescription = null, modifier = Modifier.size(56.dp), tint = NeutralMedium)
                        Spacer(modifier = Modifier.height(12.dp))
                        Text("No properties match your criteria", fontWeight = FontWeight.Bold, color = NeutralDark)
                        Text("Try resetting filters or changing your search terms", fontSize = 12.sp, color = NeutralMedium)
                        Spacer(modifier = Modifier.height(16.dp))
                        Button(onClick = { viewModel.clearFilter() }) {
                            Text("Reset All Filters")
                        }
                    }
                }
            } else {
                LazyColumn(
                    modifier = Modifier.fillMaxSize(),
                    contentPadding = PaddingValues(start = 16.dp, end = 16.dp, top = 8.dp, bottom = 24.dp),
                    verticalArrangement = Arrangement.spacedBy(16.dp)
                ) {
                    items(properties) { prop ->
                        PropertyCard(
                            property = prop,
                            isFavorite = favorites.contains(prop.id),
                            onFavoriteToggle = { viewModel.toggleFavorite(prop.id) },
                            onClick = { viewModel.openPropertyDetail(prop) }
                        )
                    }
                }
            }
        }
    }

    if (showFilterSheet) {
        FilterBottomSheet(
            initialFilter = filter,
            onApply = { viewModel.setFilter(it) },
            onDismiss = { showFilterSheet = false }
        )
    }
}
