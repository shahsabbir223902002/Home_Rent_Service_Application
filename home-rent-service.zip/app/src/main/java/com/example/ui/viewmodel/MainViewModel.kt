package com.example.ui.viewmodel

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.example.data.model.*
import com.example.data.remote.ApiClient
import com.example.data.repository.HomeRentRepository
import com.example.data.util.MogoltoliGeofence
import com.example.ui.components.PropertyFilter
import kotlinx.coroutines.flow.*
import kotlinx.coroutines.launch

enum class Screen {
    SPLASH,
    LOGIN,
    REGISTER,
    // User Screens
    USER_HOME,
    PROPERTY_LIST,
    PROPERTY_MAP,
    PROPERTY_DETAIL,
    ADD_PROPERTY,
    MY_LISTINGS,
    FAVORITES,
    INQUIRIES,
    USER_PROFILE,
    // Admin Screens
    ADMIN_DASHBOARD,
    ADMIN_LISTINGS,
    ADMIN_MAP,
    ADMIN_USERS,
    ADMIN_REPORTS,
    ADMIN_LOGS,
    ADMIN_SETTINGS
}

class MainViewModel(
    private val repository: HomeRentRepository = HomeRentRepository()
) : ViewModel() {

    val currentUser = repository.currentUser
    val allProperties = repository.properties
    val users = repository.users
    val favorites = repository.favorites
    val inquiries = repository.inquiries
    val reports = repository.reports
    val activityLogs = repository.activityLogs

    // Navigation State
    private val _currentScreen = MutableStateFlow(Screen.USER_HOME)
    val currentScreen: StateFlow<Screen> = _currentScreen.asStateFlow()

    private val screenStack = mutableListOf<Screen>()

    // Selected Property for detail view
    private val _selectedProperty = MutableStateFlow<Property?>(null)
    val selectedProperty: StateFlow<Property?> = _selectedProperty.asStateFlow()

    // Search and Filter State
    private val _searchQuery = MutableStateFlow("")
    val searchQuery: StateFlow<String> = _searchQuery.asStateFlow()

    private val _filter = MutableStateFlow(PropertyFilter())
    val filter: StateFlow<PropertyFilter> = _filter.asStateFlow()

    // UI Snackbars / Alerts
    private val _userMessage = MutableStateFlow<String?>(null)
    val userMessage: StateFlow<String?> = _userMessage.asStateFlow()

    // Filtered Approved Properties for Public Users
    val approvedProperties: StateFlow<List<Property>> = combine(
        allProperties,
        _searchQuery,
        _filter
    ) { props, query, f ->
        props.filter { p ->
            // Only approved listings for regular users
            val isApproved = p.approvalStatus == ApprovalStatus.APPROVED
            val matchesCategory = f.category == null || p.category == f.category
            val matchesRent = p.rentMonthly in f.minRent..f.maxRent
            val matchesAvailability = f.availabilityStatus == null || p.availabilityStatus == f.availabilityStatus
            val matchesFacilities = f.selectedFacilities.isEmpty() || f.selectedFacilities.all { p.facilities.contains(it) }
            val matchesQuery = query.isBlank() ||
                    p.title.contains(query, ignoreCase = true) ||
                    p.address.contains(query, ignoreCase = true) ||
                    p.description.contains(query, ignoreCase = true)

            isApproved && matchesCategory && matchesRent && matchesAvailability && matchesFacilities && matchesQuery
        }
    }.stateIn(viewModelScope, SharingStarted.Eagerly, emptyList())

    // Admin Dashboard Stats
    val dashboardStats: StateFlow<DashboardStats> = allProperties.map {
        repository.getDashboardStats()
    }.stateIn(viewModelScope, SharingStarted.Eagerly, DashboardStats())

    fun navigateTo(screen: Screen) {
        if (_currentScreen.value != screen) {
            screenStack.add(_currentScreen.value)
            _currentScreen.value = screen
        }
    }

    fun navigateBack(): Boolean {
        if (screenStack.isNotEmpty()) {
            _currentScreen.value = screenStack.removeAt(screenStack.size - 1)
            return true
        }
        return false
    }

    fun openPropertyDetail(property: Property) {
        _selectedProperty.value = property
        navigateTo(Screen.PROPERTY_DETAIL)
    }

    fun setSearchQuery(query: String) {
        _searchQuery.value = query
    }

    fun setFilter(newFilter: PropertyFilter) {
        _filter.value = newFilter
    }

    fun clearFilter() {
        _filter.value = PropertyFilter()
        _searchQuery.value = ""
    }

    fun clearUserMessage() {
        _userMessage.value = null
    }

    fun showMessage(msg: String) {
        _userMessage.value = msg
    }

    // ---------------- AUTHENTICATION ----------------
    fun login(email: String, pass: String, onResult: (Boolean, String?) -> Unit) {
        viewModelScope.launch {
            val result = repository.login(email, pass)
            result.onSuccess { user ->
                if (user.isAdmin) {
                    _currentScreen.value = Screen.ADMIN_DASHBOARD
                } else {
                    _currentScreen.value = Screen.USER_HOME
                }
                onResult(true, null)
            }.onFailure { err ->
                onResult(false, err.message)
            }
        }
    }

    fun register(name: String, email: String, phone: String, pass: String, onResult: (Boolean, String?) -> Unit) {
        viewModelScope.launch {
            val result = repository.register(name, email, phone, pass)
            result.onSuccess {
                _currentScreen.value = Screen.USER_HOME
                onResult(true, null)
            }.onFailure { err ->
                onResult(false, err.message)
            }
        }
    }

    fun logout() {
        repository.logout()
        screenStack.clear()
        _currentScreen.value = Screen.LOGIN
    }

    fun switchUserQuick(user: User) {
        repository.switchUser(user)
        if (user.isAdmin) {
            _currentScreen.value = Screen.ADMIN_DASHBOARD
        } else {
            _currentScreen.value = Screen.USER_HOME
        }
    }

    // ---------------- PROPERTY ACTIONS ----------------
    fun addProperty(
        category: PropertyCategory,
        title: String,
        description: String,
        rentMonthly: Double,
        address: String,
        latitude: Double,
        longitude: Double,
        bedrooms: Int = 0,
        bathrooms: Int = 0,
        floorAreaSqft: Int = 0,
        vehicleType: String? = null,
        capacity: Int = 1,
        isCovered: Boolean = true,
        houseRules: String? = null,
        commercialDetails: String? = null,
        facilities: List<String> = emptyList(),
        onSuccess: () -> Unit,
        onError: (String) -> Unit
    ) {
        viewModelScope.launch {
            val result = repository.addProperty(
                category = category,
                title = title,
                description = description,
                rentMonthly = rentMonthly,
                address = address,
                latitude = latitude,
                longitude = longitude,
                bedrooms = bedrooms,
                bathrooms = bathrooms,
                floorAreaSqft = floorAreaSqft,
                vehicleType = vehicleType,
                capacity = capacity,
                isCovered = isCovered,
                houseRules = houseRules,
                commercialDetails = commercialDetails,
                facilities = facilities
            )
            result.onSuccess {
                showMessage("Rental submitted in Mogoltoli! Status is Pending approval.")
                onSuccess()
            }.onFailure { err ->
                onError(err.message ?: "Submission failed.")
            }
        }
    }

    fun updateProperty(property: Property, onSuccess: () -> Unit, onError: (String) -> Unit) {
        viewModelScope.launch {
            val result = repository.updateProperty(property)
            result.onSuccess {
                showMessage("Property updated successfully.")
                onSuccess()
            }.onFailure { err ->
                onError(err.message ?: "Update failed.")
            }
        }
    }

    fun deleteProperty(propertyId: Int) {
        viewModelScope.launch {
            repository.deleteProperty(propertyId)
            showMessage("Listing deleted.")
        }
    }

    // ---------------- ADMIN ACTIONS ----------------
    fun adminApprove(propertyId: Int) {
        val admin = currentUser.value ?: return
        viewModelScope.launch {
            repository.adminApprove(propertyId, admin)
            showMessage("Listing #$propertyId approved!")
        }
    }

    fun adminReject(propertyId: Int, reason: String) {
        val admin = currentUser.value ?: return
        viewModelScope.launch {
            repository.adminReject(propertyId, reason, admin)
            showMessage("Listing #$propertyId rejected.")
        }
    }

    fun updateAvailability(propertyId: Int, status: AvailabilityStatus) {
        viewModelScope.launch {
            repository.updateAvailability(propertyId, status)
            showMessage("Availability set to ${status.label}")
        }
    }

    fun toggleUserSuspension(userId: Int) {
        val admin = currentUser.value ?: return
        viewModelScope.launch {
            val result = repository.toggleUserSuspension(userId, admin)
            result.onSuccess { newStatus ->
                showMessage("User status updated to $newStatus.")
            }
        }
    }

    // ---------------- FAVORITES & INQUIRIES ----------------
    fun toggleFavorite(propertyId: Int) {
        repository.toggleFavorite(propertyId)
    }

    fun isFavorite(propertyId: Int): Boolean = repository.isFavorite(propertyId)

    fun submitInquiry(propertyId: Int, propertyTitle: String, message: String, onSuccess: () -> Unit) {
        viewModelScope.launch {
            val res = repository.submitInquiry(propertyId, propertyTitle, message)
            res.onSuccess {
                showMessage("Inquiry sent to property owner!")
                onSuccess()
            }.onFailure { err ->
                showMessage(err.message ?: "Failed to send inquiry.")
            }
        }
    }

    fun submitReport(propertyId: Int, propertyTitle: String, reason: String, details: String, onSuccess: () -> Unit) {
        viewModelScope.launch {
            val res = repository.submitReport(propertyId, propertyTitle, reason, details)
            res.onSuccess {
                showMessage("Report submitted. Admin will review this listing.")
                onSuccess()
            }.onFailure { err ->
                showMessage(err.message ?: "Failed to submit report.")
            }
        }
    }

    fun updateApiUrl(newUrl: String) {
        ApiClient.updateBaseUrl(newUrl)
        showMessage("Server URL updated to $newUrl")
    }
}
