package com.example.ui.theme

import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color

private val DarkColorScheme = darkColorScheme(
    primary = BrandMint,
    onPrimary = BrandTealDark,
    primaryContainer = BrandTealMedium,
    onPrimaryContainer = BrandMintLight,
    secondary = AccentAmber,
    onSecondary = NeutralDark,
    tertiary = AccentCoral,
    background = Color(0xFF111827),
    surface = Color(0xFF1F2937),
    onBackground = Color(0xFFF3F4F6),
    onSurface = Color(0xFFF3F4F6),
    outline = Color(0xFF374151)
)

private val LightColorScheme = lightColorScheme(
    primary = BrandTealDark,
    onPrimary = Color.White,
    primaryContainer = BrandMintLight,
    onPrimaryContainer = BrandTealDark,
    secondary = BrandMint,
    onSecondary = Color.White,
    tertiary = AccentCoral,
    background = SurfaceBgLight,
    surface = SurfaceCardLight,
    onBackground = NeutralDark,
    onSurface = NeutralDark,
    outline = SurfaceBorderLight
)

@Composable
fun MyApplicationTheme(
    darkTheme: Boolean = isSystemInDarkTheme(),
    dynamicColor: Boolean = false, // Use our brand palette consistently
    content: @Composable () -> Unit,
) {
    val colorScheme = if (darkTheme) DarkColorScheme else LightColorScheme

    MaterialTheme(
        colorScheme = colorScheme,
        typography = Typography,
        content = content
    )
}
