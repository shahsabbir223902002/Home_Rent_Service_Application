package com.example.ui.screens

import androidx.activity.compose.BackHandler
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.model.ApprovalStatus
import com.example.data.model.AvailabilityStatus
import com.example.data.model.Property
import com.example.ui.components.PropertyCard
import com.example.ui.theme.BrandMint
import com.example.ui.theme.NeutralDark
import com.example.ui.theme.NeutralMedium
import com.example.ui.viewmodel.MainViewModel
import com.example.ui.viewmodel.Screen

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun MyListingsScreen(
    viewModel: MainViewModel,
    modifier: Modifier = Modifier
) {
    BackHandler {
        viewModel.navigateBack()
    }

    val currentUser by viewModel.currentUser.collectAsState()
    val allProps by viewModel.allProperties.collectAsState()

    val myListings = remember(allProps, currentUser) {
        val uid = currentUser?.id ?: 0
        allProps.filter { it.ownerId == uid }
    }

    var selectedTab by remember { mutableIntStateOf(0) }
    val tabs = listOf("All", "Pending", "Approved", "Rejected")

    val filteredListings = remember(myListings, selectedTab) {
        when (selectedTab) {
            1 -> myListings.filter { it.approvalStatus == ApprovalStatus.PENDING }
            2 -> myListings.filter { it.approvalStatus == ApprovalStatus.APPROVED }
            3 -> myListings.filter { it.approvalStatus == ApprovalStatus.REJECTED }
            else -> myListings
        }
    }

    var propertyToEdit by remember { mutableStateOf<Property?>(null) }
    var showEditDialog by remember { mutableStateOf(false) }

    Scaffold(
        topBar = {
            TopAppBar(
                title = {
                    Column {
                        Text("My Rental Listings", fontWeight = FontWeight.Bold, fontSize = 18.sp)
                        Text("${myListings.size} properties submitted", fontSize = 11.sp, color = NeutralMedium)
                    }
                },
                navigationIcon = {
                    IconButton(onClick = { viewModel.navigateBack() }) {
                        Icon(Icons.Default.ArrowBack, contentDescription = "Back")
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(containerColor = MaterialTheme.colorScheme.surface)
            )
        },
        floatingActionButton = {
            FloatingActionButton(
                onClick = { viewModel.navigateTo(Screen.ADD_PROPERTY) },
                containerColor = BrandMint,
                contentColor = NeutralDark,
                modifier = Modifier.testTag("add_listing_fab")
            ) {
                Icon(Icons.Default.Add, contentDescription = "Add Rental")
            }
        }
    ) { innerPadding ->
        Column(
            modifier = modifier
                .fillMaxSize()
                .padding(innerPadding)
                .background(MaterialTheme.colorScheme.background)
        ) {
            // Status Tabs
            PrimaryTabRow(
                selectedTabIndex = selectedTab,
                containerColor = MaterialTheme.colorScheme.surface
            ) {
                tabs.forEachIndexed { index, title ->
                    val count = when (index) {
                        1 -> myListings.count { it.approvalStatus == ApprovalStatus.PENDING }
                        2 -> myListings.count { it.approvalStatus == ApprovalStatus.APPROVED }
                        3 -> myListings.count { it.approvalStatus == ApprovalStatus.REJECTED }
                        else -> myListings.size
                    }
                    Tab(
                        selected = selectedTab == index,
                        onClick = { selectedTab = index },
                        text = {
                            Text(
                                "$title ($count)",
                                fontSize = 12.sp,
                                fontWeight = if (selectedTab == index) FontWeight.Bold else FontWeight.Normal
                            )
                        }
                    )
                }
            }

            if (filteredListings.isEmpty()) {
                Box(
                    modifier = Modifier.fillMaxSize(),
                    contentAlignment = Alignment.Center
                ) {
                    Column(horizontalAlignment = Alignment.CenterHorizontally) {
                        Icon(Icons.Default.Inventory2, contentDescription = null, modifier = Modifier.size(56.dp), tint = NeutralMedium)
                        Spacer(modifier = Modifier.height(12.dp))
                        Text("No listings in this category", fontWeight = FontWeight.Bold, color = NeutralDark)
                        Text("Post a house, store, or parking space in Mogoltoli", fontSize = 12.sp, color = NeutralMedium)
                        Spacer(modifier = Modifier.height(16.dp))
                        Button(onClick = { viewModel.navigateTo(Screen.ADD_PROPERTY) }) {
                            Text("Post New Rental")
                        }
                    }
                }
            } else {
                LazyColumn(
                    modifier = Modifier.fillMaxSize(),
                    contentPadding = PaddingValues(16.dp),
                    verticalArrangement = Arrangement.spacedBy(16.dp)
                ) {
                    items(filteredListings) { prop ->
                        PropertyCard(
                            property = prop,
                            showOwnerControls = true,
                            onClick = { viewModel.openPropertyDetail(prop) },
                            onDelete = { viewModel.deleteProperty(prop.id) },
                            onEdit = {
                                propertyToEdit = prop
                                showEditDialog = true
                            }
                        )
                    }
                }
            }
        }
    }

    // Quick Edit Dialog
    if (showEditDialog && propertyToEdit != null) {
        val p = propertyToEdit!!
        var editTitle by remember { mutableStateOf(p.title) }
        var editRent by remember { mutableStateOf(p.rentMonthly.toInt().toString()) }
        var editDesc by remember { mutableStateOf(p.description) }
        var editAvail by remember { mutableStateOf(p.availabilityStatus) }

        AlertDialog(
            onDismissRequest = { showEditDialog = false },
            title = { Text("Edit Listing #${p.id}", fontWeight = FontWeight.Bold) },
            text = {
                Column {
                    Text("Note: Material changes will submit the listing for admin reapproval.", fontSize = 11.sp, color = NeutralMedium)
                    Spacer(modifier = Modifier.height(10.dp))
                    OutlinedTextField(
                        value = editTitle,
                        onValueChange = { editTitle = it },
                        label = { Text("Title") },
                        modifier = Modifier.fillMaxWidth()
                    )
                    Spacer(modifier = Modifier.height(8.dp))
                    OutlinedTextField(
                        value = editRent,
                        onValueChange = { editRent = it },
                        label = { Text("Rent (৳)") },
                        modifier = Modifier.fillMaxWidth()
                    )
                    Spacer(modifier = Modifier.height(8.dp))
                    OutlinedTextField(
                        value = editDesc,
                        onValueChange = { editDesc = it },
                        label = { Text("Description") },
                        modifier = Modifier.fillMaxWidth()
                    )
                    Spacer(modifier = Modifier.height(8.dp))
                    Text("Availability:", fontSize = 12.sp, fontWeight = FontWeight.SemiBold)
                    Row {
                        AvailabilityStatus.entries.forEach { st ->
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                RadioButton(selected = editAvail == st, onClick = { editAvail = st })
                                Text(st.label, fontSize = 12.sp)
                            }
                        }
                    }
                }
            },
            confirmButton = {
                Button(
                    onClick = {
                        val newRent = editRent.toDoubleOrNull() ?: p.rentMonthly
                        viewModel.updateProperty(
                            p.copy(
                                title = editTitle,
                                rentMonthly = newRent,
                                description = editDesc,
                                availabilityStatus = editAvail
                            ),
                            onSuccess = { showEditDialog = false },
                            onError = { /* show error */ }
                        )
                    }
                ) {
                    Text("Save Changes")
                }
            },
            dismissButton = {
                TextButton(onClick = { showEditDialog = false }) {
                    Text("Cancel")
                }
            }
        )
    }
}
