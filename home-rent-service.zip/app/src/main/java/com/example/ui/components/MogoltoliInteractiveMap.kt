package com.example.ui.components

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.slideInVertically
import androidx.compose.animation.slideOutVertically
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.gestures.detectTransformGestures
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.PathEffect
import androidx.compose.ui.graphics.drawscope.DrawScope
import androidx.compose.ui.graphics.drawscope.Fill
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.TextMeasurer
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.drawText
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.rememberTextMeasurer
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import coil.compose.AsyncImage
import com.example.data.model.ApprovalStatus
import com.example.data.model.Property
import com.example.data.model.PropertyCategory
import com.example.data.util.MogoltoliGeofence
import com.example.ui.theme.*

@Composable
fun MogoltoliInteractiveMap(
    modifier: Modifier = Modifier,
    properties: List<Property> = emptyList(),
    selectedProperty: Property? = null,
    onPropertySelected: (Property?) -> Unit = {},
    isPickerMode: Boolean = false,
    pickedLocation: Pair<Double, Double>? = null,
    onLocationPicked: (Double, Double) -> Unit = { _, _ -> },
    showAllStatuses: Boolean = false // Admin can see Pending, Rejected
) {
    var scale by remember { mutableFloatStateOf(1f) }
    var offset by remember { mutableStateOf(Offset.Zero) }
    val textMeasurer = rememberTextMeasurer()

    // Bounding Box Coordinates for Mogoltoli
    val minLat = MogoltoliGeofence.MIN_LAT
    val maxLat = MogoltoliGeofence.MAX_LAT
    val minLon = MogoltoliGeofence.MIN_LON
    val maxLon = MogoltoliGeofence.MAX_LON

    Box(
        modifier = modifier
            .fillMaxSize()
            .background(Color(0xFFE5ECE9)) // Warm map ground tone
            .clip(RoundedCornerShape(0.dp))
            .pointerInput(Unit) {
                detectTransformGestures { _, pan, zoom, _ ->
                    scale = (scale * zoom).coerceIn(0.8f, 3.5f)
                    offset = Offset(
                        x = (offset.x + pan.x).coerceIn(-400f * scale, 400f * scale),
                        y = (offset.y + pan.y).coerceIn(-400f * scale, 400f * scale)
                    )
                }
            }
            .pointerInput(isPickerMode, properties, scale, offset) {
                detectTapGestures { tapOffset ->
                    val w = size.width.toFloat()
                    val h = size.height.toFloat()

                    if (isPickerMode) {
                        // Invert screen tap to Lat/Lon
                        val normX = ((tapOffset.x - offset.x) / scale - w * 0.1f) / (w * 0.8f)
                        val normY = ((tapOffset.y - offset.y) / scale - h * 0.1f) / (h * 0.8f)

                        val pickedLon = minLon + normX * (maxLon - minLon)
                        val pickedLat = maxLat - normY * (maxLat - minLat)

                        onLocationPicked(pickedLat, pickedLon)
                    } else {
                        // Check if tapped near any property pin
                        var hitProperty: Property? = null
                        for (prop in properties) {
                            if (!showAllStatuses && prop.approvalStatus != ApprovalStatus.APPROVED) continue

                            val normX = (prop.longitude - minLon) / (maxLon - minLon)
                            val normY = (maxLat - prop.latitude) / (maxLat - minLat)

                            val pinX = (w * 0.1f + normX * w * 0.8f) * scale + offset.x
                            val pinY = (h * 0.1f + normY * h * 0.8f) * scale + offset.y

                            val dx = tapOffset.x - pinX
                            val dy = tapOffset.y - (pinY - 20f * scale)
                            if (dx * dx + dy * dy <= (32f * scale) * (32f * scale)) {
                                hitProperty = prop
                                break
                            }
                        }
                        onPropertySelected(hitProperty)
                    }
                }
            }
    ) {
        Canvas(modifier = Modifier.fillMaxSize()) {
            val canvasW = size.width
            val canvasH = size.height

            // Coordinate conversion helper
            fun toScreenOffset(lat: Double, lon: Double): Offset {
                val normX = (lon - minLon) / (maxLon - minLon)
                val normY = (maxLat - lat) / (maxLat - minLat)
                val x = (canvasW * 0.1f + normX.toFloat() * canvasW * 0.8f) * scale + offset.x
                val y = (canvasH * 0.1f + normY.toFloat() * canvasH * 0.8f) * scale + offset.y
                return Offset(x, y)
            }

            // 1. Draw Mogoltoli Boundary Area (Tinted fill)
            val pTopLeft = toScreenOffset(maxLat, minLon)
            val pTopRight = toScreenOffset(maxLat, maxLon)
            val pBottomRight = toScreenOffset(minLat, maxLon)
            val pBottomLeft = toScreenOffset(minLat, minLon)

            val boundaryPath = Path().apply {
                moveTo(pTopLeft.x, pTopLeft.y)
                lineTo(pTopRight.x, pTopRight.y)
                lineTo(pBottomRight.x, pBottomRight.y)
                lineTo(pBottomLeft.x, pBottomLeft.y)
                close()
            }

            drawPath(
                path = boundaryPath,
                color = Color(0xFFF3FAF7), // Inside Mogoltoli clean surface
                style = Fill
            )

            drawPath(
                path = boundaryPath,
                color = BrandTealLight.copy(alpha = 0.6f),
                style = Stroke(
                    width = 3.dp.toPx(),
                    pathEffect = PathEffect.dashPathEffect(floatArrayOf(15f, 10f), 0f)
                )
            )

            // 2. Draw Gomti River (North boundary ribbon)
            val riverPath = Path().apply {
                val r1 = toScreenOffset(23.4678, 91.1800)
                val r2 = toScreenOffset(23.4682, 91.1860)
                val r3 = toScreenOffset(23.4675, 91.1960)
                moveTo(r1.x, r1.y)
                quadraticTo(r2.x, r2.y, r3.x, r3.y)
            }
            drawPath(
                path = riverPath,
                color = Color(0xFF90CAF9),
                style = Stroke(width = 16.dp.toPx() * scale)
            )

            // 3. Draw Mogoltoli Roads & Avenues
            // Mogoltoli Main Road (North-South central spine)
            val mainRoadStart = toScreenOffset(23.4670, 91.1865)
            val mainRoadEnd = toScreenOffset(23.4565, 91.1850)
            drawLine(
                color = Color(0xFFFFFFFF),
                start = mainRoadStart,
                end = mainRoadEnd,
                strokeWidth = 10.dp.toPx() * scale
            )
            drawLine(
                color = Color(0xFFD1D5DB),
                start = mainRoadStart,
                end = mainRoadEnd,
                strokeWidth = 1.5.dp.toPx() * scale
            )

            // Rajganj Crossing Road (East-West)
            val rajganjStart = toScreenOffset(23.4615, 91.1802)
            val rajganjEnd = toScreenOffset(23.4625, 91.1950)
            drawLine(
                color = Color(0xFFFFFFFF),
                start = rajganjStart,
                end = rajganjEnd,
                strokeWidth = 8.dp.toPx() * scale
            )

            // Town Hall Link Road (South East-West)
            val townHallStart = toScreenOffset(23.4580, 91.1810)
            val townHallEnd = toScreenOffset(23.4575, 91.1930)
            drawLine(
                color = Color(0xFFFFFFFF),
                start = townHallStart,
                end = townHallEnd,
                strokeWidth = 7.dp.toPx() * scale
            )

            // Chawkbazar Connector (North East)
            val chawkStart = toScreenOffset(23.4655, 91.1820)
            val chawkEnd = toScreenOffset(23.4665, 91.1920)
            drawLine(
                color = Color(0xFFFFFFFF),
                start = chawkStart,
                end = chawkEnd,
                strokeWidth = 7.dp.toPx() * scale
            )

            // Inner Residential Alleys
            val alley1Start = toScreenOffset(23.4640, 91.1830)
            val alley1End = toScreenOffset(23.4640, 91.1895)
            drawLine(color = Color(0xFFFAFAFA), start = alley1Start, end = alley1End, strokeWidth = 5.dp.toPx() * scale)

            val alley2Start = toScreenOffset(23.4595, 91.1840)
            val alley2End = toScreenOffset(23.4595, 91.1910)
            drawLine(color = Color(0xFFFAFAFA), start = alley2Start, end = alley2End, strokeWidth = 5.dp.toPx() * scale)

            // 4. Draw Landmark Labels
            if (scale >= 1.0f) {
                drawText(
                    textMeasurer = textMeasurer,
                    text = "Gomti River Link",
                    topLeft = toScreenOffset(23.4680, 91.1860),
                    style = TextStyle(color = Color(0xFF1E3A8A), fontSize = (10 * scale).sp, fontWeight = FontWeight.Bold)
                )
                drawText(
                    textMeasurer = textMeasurer,
                    text = "Mogoltoli Bazaar",
                    topLeft = toScreenOffset(23.4636, 91.1878),
                    style = TextStyle(color = BrandTealDark, fontSize = (9 * scale).sp, fontWeight = FontWeight.SemiBold)
                )
                drawText(
                    textMeasurer = textMeasurer,
                    text = "Rajganj Road",
                    topLeft = toScreenOffset(23.4616, 91.1815),
                    style = TextStyle(color = NeutralMedium, fontSize = (9 * scale).sp, fontWeight = FontWeight.Normal)
                )
                drawText(
                    textMeasurer = textMeasurer,
                    text = "Town Hall Link",
                    topLeft = toScreenOffset(23.4578, 91.1835),
                    style = TextStyle(color = NeutralMedium, fontSize = (9 * scale).sp, fontWeight = FontWeight.Normal)
                )
            }

            // 5. Draw Property Markers (or Location Picker Pin)
            if (!isPickerMode) {
                for (prop in properties) {
                    if (!showAllStatuses && prop.approvalStatus != ApprovalStatus.APPROVED) continue

                    val pinPos = toScreenOffset(prop.latitude, prop.longitude)
                    val isSelected = selectedProperty?.id == prop.id

                    val pinColor = when (prop.approvalStatus) {
                        ApprovalStatus.PENDING -> StatusPendingAmber
                        ApprovalStatus.REJECTED -> StatusRejectedRed
                        ApprovalStatus.APPROVED -> when (prop.category) {
                            PropertyCategory.HOUSE -> CategoryHouseColor
                            PropertyCategory.STORE -> CategoryStoreColor
                            PropertyCategory.CAR_PARKING -> CategoryParkingColor
                        }
                    }

                    drawPropertyPin(
                        pinPos = pinPos,
                        color = pinColor,
                        isSelected = isSelected,
                        scale = scale,
                        category = prop.category,
                        isPending = prop.approvalStatus == ApprovalStatus.PENDING
                    )
                }
            } else {
                // Draw Picked Pin in Location Picker Mode
                pickedLocation?.let { (lat, lon) ->
                    val pinPos = toScreenOffset(lat, lon)
                    val isInside = MogoltoliGeofence.isWithinMogoltoli(lat, lon)
                    val color = if (isInside) StatusApprovedGreen else StatusRejectedRed

                    // Outer pulse
                    drawCircle(
                        color = color.copy(alpha = 0.25f),
                        radius = 28f * scale,
                        center = pinPos
                    )
                    // Pin stem
                    drawLine(
                        color = color,
                        start = pinPos,
                        end = Offset(pinPos.x, pinPos.y - 30f * scale),
                        strokeWidth = 4.dp.toPx()
                    )
                    // Pin head
                    drawCircle(
                        color = color,
                        radius = 12f * scale,
                        center = Offset(pinPos.x, pinPos.y - 30f * scale)
                    )
                    drawCircle(
                        color = Color.White,
                        radius = 5f * scale,
                        center = Offset(pinPos.x, pinPos.y - 30f * scale)
                    )
                }
            }
        }

        // Map Watermark & Mogoltoli Service Boundary Label
        Surface(
            modifier = Modifier
                .align(Alignment.TopStart)
                .padding(12.dp),
            shape = RoundedCornerShape(20.dp),
            color = BrandTealDark.copy(alpha = 0.9f),
            shadowElevation = 4.dp
        ) {
            Row(
                modifier = Modifier.padding(horizontal = 12.dp, vertical = 6.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Icon(
                    imageVector = Icons.Default.LocationOn,
                    contentDescription = null,
                    tint = BrandMint,
                    modifier = Modifier.size(16.dp)
                )
                Spacer(modifier = Modifier.width(6.dp))
                Text(
                    text = "Mogoltoli Service Area • Cumilla",
                    color = Color.White,
                    fontSize = 12.sp,
                    fontWeight = FontWeight.Bold
                )
            }
        }

        // Zoom Controls
        Column(
            modifier = Modifier
                .align(Alignment.TopEnd)
                .padding(12.dp),
            verticalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            FloatingActionButton(
                onClick = { scale = (scale + 0.3f).coerceAtMost(3.5f) },
                modifier = Modifier.size(40.dp).testTag("zoom_in_button"),
                containerColor = MaterialTheme.colorScheme.surface,
                contentColor = MaterialTheme.colorScheme.primary
            ) {
                Icon(Icons.Default.Add, contentDescription = "Zoom In", modifier = Modifier.size(20.dp))
            }
            FloatingActionButton(
                onClick = { scale = (scale - 0.3f).coerceAtLeast(0.8f) },
                modifier = Modifier.size(40.dp).testTag("zoom_out_button"),
                containerColor = MaterialTheme.colorScheme.surface,
                contentColor = MaterialTheme.colorScheme.primary
            ) {
                Icon(Icons.Default.Remove, contentDescription = "Zoom Out", modifier = Modifier.size(20.dp))
            }
            FloatingActionButton(
                onClick = {
                    scale = 1.0f
                    offset = Offset.Zero
                },
                modifier = Modifier.size(40.dp).testTag("reset_map_button"),
                containerColor = MaterialTheme.colorScheme.surface,
                contentColor = MaterialTheme.colorScheme.primary
            ) {
                Icon(Icons.Default.MyLocation, contentDescription = "Center Mogoltoli", modifier = Modifier.size(18.dp))
            }
        }

        // Map Category Legend (bottom start)
        if (!isPickerMode && selectedProperty == null) {
            Surface(
                modifier = Modifier
                    .align(Alignment.BottomStart)
                    .padding(12.dp),
                shape = RoundedCornerShape(12.dp),
                color = MaterialTheme.colorScheme.surface.copy(alpha = 0.95f),
                shadowElevation = 3.dp
            ) {
                Row(
                    modifier = Modifier.padding(horizontal = 10.dp, vertical = 6.dp),
                    horizontalArrangement = Arrangement.spacedBy(10.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    LegendItem(color = CategoryHouseColor, label = "House")
                    LegendItem(color = CategoryStoreColor, label = "Store")
                    LegendItem(color = CategoryParkingColor, label = "Parking")
                    if (showAllStatuses) {
                        LegendItem(color = StatusPendingAmber, label = "Pending")
                    }
                }
            }
        }

        // Selected Property Info Card Popup
        AnimatedVisibility(
            visible = selectedProperty != null,
            modifier = Modifier
                .align(Alignment.BottomCenter)
                .fillMaxWidth()
                .padding(12.dp),
            enter = slideInVertically { it } + fadeIn(),
            exit = slideOutVertically { it } + fadeOut()
        ) {
            selectedProperty?.let { prop ->
                PropertyMapPreviewCard(
                    property = prop,
                    onClose = { onPropertySelected(null) },
                    onViewDetails = { onPropertySelected(prop) }
                )
            }
        }
    }
}

private fun DrawScope.drawPropertyPin(
    pinPos: Offset,
    color: Color,
    isSelected: Boolean,
    scale: Float,
    category: PropertyCategory,
    isPending: Boolean
) {
    val baseRadius = if (isSelected) 18f * scale else 13f * scale

    // Selection Halo
    if (isSelected) {
        drawCircle(
            color = color.copy(alpha = 0.35f),
            radius = baseRadius + 14f * scale,
            center = Offset(pinPos.x, pinPos.y - 18f * scale)
        )
    }

    // Shadow at base
    drawOval(
        color = Color(0x33000000),
        topLeft = Offset(pinPos.x - 8f * scale, pinPos.y - 3f * scale),
        size = Size(16f * scale, 6f * scale)
    )

    // Teardrop Pin Path
    val pinPath = Path().apply {
        val cy = pinPos.y - 20f * scale
        moveTo(pinPos.x, pinPos.y)
        lineTo(pinPos.x - 10f * scale, cy + 5f * scale)
        arcTo(
            rect = androidx.compose.ui.geometry.Rect(
                center = Offset(pinPos.x, cy),
                radius = baseRadius
            ),
            startAngleDegrees = 135f,
            sweepAngleDegrees = 270f,
            forceMoveTo = false
        )
        lineTo(pinPos.x, pinPos.y)
        close()
    }

    drawPath(path = pinPath, color = color, style = Fill)
    drawPath(path = pinPath, color = Color.White, style = Stroke(width = 2.dp.toPx()))

    // Inner White Circle with Category Initials
    val centerCircle = Offset(pinPos.x, pinPos.y - 20f * scale)
    drawCircle(
        color = Color.White,
        radius = baseRadius * 0.55f,
        center = centerCircle
    )

    // Pending Indicator Dot
    if (isPending) {
        drawCircle(
            color = StatusPendingAmber,
            radius = 4f * scale,
            center = Offset(centerCircle.x + 8f * scale, centerCircle.y - 8f * scale)
        )
    }
}

@Composable
private fun LegendItem(color: Color, label: String) {
    Row(verticalAlignment = Alignment.CenterVertically) {
        Box(
            modifier = Modifier
                .size(10.dp)
                .background(color, CircleShape)
        )
        Spacer(modifier = Modifier.width(4.dp))
        Text(text = label, fontSize = 11.sp, color = NeutralDark, fontWeight = FontWeight.Medium)
    }
}

@Composable
fun PropertyMapPreviewCard(
    property: Property,
    onClose: () -> Unit,
    onViewDetails: () -> Unit
) {
    Card(
        modifier = Modifier
            .fillMaxWidth()
            .testTag("map_property_card"),
        shape = RoundedCornerShape(16.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
        elevation = CardDefaults.cardElevation(defaultElevation = 8.dp)
    ) {
        Row(
            modifier = Modifier
                .padding(12.dp)
                .fillMaxWidth(),
            verticalAlignment = Alignment.CenterVertically
        ) {
            AsyncImage(
                model = property.imageUrls.firstOrNull() ?: "",
                contentDescription = property.title,
                modifier = Modifier
                    .size(80.dp)
                    .clip(RoundedCornerShape(12.dp))
                    .background(NeutralLight.copy(alpha = 0.2f)),
                contentScale = ContentScale.Crop
            )

            Spacer(modifier = Modifier.width(12.dp))

            Column(modifier = Modifier.weight(1f)) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Surface(
                        shape = RoundedCornerShape(6.dp),
                        color = when (property.category) {
                            PropertyCategory.HOUSE -> CategoryHouseColor.copy(alpha = 0.15f)
                            PropertyCategory.STORE -> CategoryStoreColor.copy(alpha = 0.15f)
                            PropertyCategory.CAR_PARKING -> CategoryParkingColor.copy(alpha = 0.15f)
                        }
                    ) {
                        Text(
                            text = property.category.displayName,
                            color = when (property.category) {
                                PropertyCategory.HOUSE -> CategoryHouseColor
                                PropertyCategory.STORE -> CategoryStoreColor
                                PropertyCategory.CAR_PARKING -> CategoryParkingColor
                            },
                            fontSize = 11.sp,
                            fontWeight = FontWeight.Bold,
                            modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
                        )
                    }

                    IconButton(onClick = onClose, modifier = Modifier.size(24.dp)) {
                        Icon(Icons.Default.Close, contentDescription = "Close preview", modifier = Modifier.size(16.dp))
                    }
                }

                Spacer(modifier = Modifier.height(4.dp))

                Text(
                    text = property.title,
                    fontWeight = FontWeight.Bold,
                    fontSize = 14.sp,
                    maxLines = 1,
                    color = MaterialTheme.colorScheme.onSurface
                )

                Text(
                    text = property.address,
                    fontSize = 11.sp,
                    color = NeutralMedium,
                    maxLines = 1
                )

                Spacer(modifier = Modifier.height(4.dp))

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        text = property.formattedRent,
                        fontWeight = FontWeight.ExtraBold,
                        fontSize = 14.sp,
                        color = MaterialTheme.colorScheme.primary
                    )

                    Button(
                        onClick = onViewDetails,
                        modifier = Modifier
                            .height(32.dp)
                            .testTag("preview_details_button"),
                        contentPadding = PaddingValues(horizontal = 12.dp, vertical = 0.dp),
                        shape = RoundedCornerShape(8.dp)
                    ) {
                        Text("View Details", fontSize = 11.sp)
                    }
                }
            }
        }
    }
}
