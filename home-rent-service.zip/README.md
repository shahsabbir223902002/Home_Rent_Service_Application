# Home Rent Service — Mogoltoli, Cumilla, Bangladesh

A complete Android application built with **Kotlin** and **Jetpack Compose (Material 3)** for finding and publishing rental information exclusively within **Mogoltoli, Cumilla, Bangladesh**.

---

## 1. System Architecture & Features

The system is organized into two distinct, role-secured interfaces:

### A. User Interface
- **User Registration & Login**: Account management with secure password hashing and role enforcement.
- **Home Dashboard**: Quick statistics, featured rentals, and category breakdown.
- **Rental Categories**:
  - **House Rental**: Monthly rent in BDT (৳), bedrooms, bathrooms, floor area, house rules, and amenities.
  - **Commercial Store Rental**: Commercial floor area (sq ft), commercial power meter, shutter, road width, and business suitability.
  - **Car Parking Space Rental**: Vehicle compatibility (Sedan/SUV, Microbus, Motorcycle), capacity, and covered vs open garage.
- **Search & Multi-Filters**: Filter by category, rent range (৳), facilities, and availability.
- **Interactive Mogoltoli Map**: Interactive map restricted to the Mogoltoli service area showing properties with color-coded category markers, custom halos, and bottom preview cards.
- **Add Rental Information**:
  - Category-specific form fields.
  - **Interactive Map Location Picker** with real-time geofence validation.
  - Submissions are initially marked as `Pending` and require admin review before becoming publicly visible.
- **My Listings**: Manage submissions across All, Pending, Approved, and Rejected statuses. View admin rejection notes and edit/delete listings.
- **Favorites & Inquiries**: Save shortlisted properties and send direct messages to property owners.
- **Owner Contact**: 1-tap phone dialing intent and inquiry messaging.
- **Report Listing**: Community moderation tool to flag suspicious or inaccurate listings.

### B. Admin Interface
- **Role-Protected Access**: Dedicated login with server-side role verification.
- **Admin Dashboard**: Summary metrics for:
  - Total registered users
  - Total rental listings
  - Pending listings awaiting approval
  - Approved listings
  - Rejected listings
  - Unavailable / Rented properties
- **Listing Approval Queue**: Approve listings or reject with custom feedback notes.
- **Admin Map Inspector**: View all listings on the Mogoltoli map, including Pending (amber) pins.
- **User Management**: View user accounts and toggle active / suspended status.
- **Reports & Moderation**: Review user complaints and take down problematic listings.
- **Audit & Activity Logs**: Chronological log of administrative approvals, rejections, and actions.
- **System Settings**: Configure backend XAMPP REST API endpoint and inspect Mogoltoli boundary coordinates.

---

## 2. Mogoltoli, Cumilla Service Boundary

Property discovery and listing creation are strictly geofenced to the Mogoltoli neighborhood in Cumilla Sadar:
- **Latitude Range**: `23.4560` to `23.4680` N
- **Longitude Range**: `91.1800` to `91.1960` E
- **Center**: `23.4620`, `91.1860` (Mogoltoli Road, near Rajganj & Town Hall Link)

Listings with coordinates outside this boundary are rejected at both client and backend levels.

---

## 3. Demo Credentials (1-Tap in App)

| Role | Email | Password | Access Level |
| :--- | :--- | :--- | :--- |
| **Administrator** | `admin@homerent.com` | `admin123` | Full Admin Portal & Moderation |
| **User (Owner/Renter)** | `rahim@example.com` | `user123` | User Portal, Post & Edit Rentals |
| **User (Owner/Renter)** | `tanvir@example.com` | `user123` | User Portal, Post & Edit Rentals |

---

## 4. Backend Setup (XAMPP & MySQL)

The PHP REST API and MySQL schema are located in the `/backend/` directory:
- `backend/database.sql`: Full database schema and sample Mogoltoli properties.
- `backend/config/db.php`: Database connection settings.
- `backend/config/geofence.php`: Mogoltoli boundary verification logic.
- `backend/api/`: REST endpoints for authentication, properties, admin actions, inquiries, favorites, and reports.

To set up locally:
1. Start Apache and MySQL in XAMPP.
2. Import `backend/database.sql` in phpMyAdmin (`http://localhost/phpmyadmin`).
3. Copy `backend/` to `C:\xampp\htdocs\homerent\`.
4. In the Android app, the backend endpoint is configured to `http://10.0.2.2/homerent/api/` (the Android emulator loopback to host XAMPP).
